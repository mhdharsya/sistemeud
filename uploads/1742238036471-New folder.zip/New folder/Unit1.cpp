//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit3.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
int a,x,p,i,n;
int ambil[10];
int gudang, gudang1, input, kentang, proses, pesanan, diproses;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Button1Click(TObject *Sender)
{
     //kodingan isi gudang
     gudang = StrToInt (Edit1->Text);           //stok gudang 10 kg
     Edit1->Text = gudang;    //banyak stok  gudang dicantumkan pada Edit1
     ShowMessage("Stok Dipenuhkan");    //menmpilkan pesan "Stok Dipenuhkan"
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
        //kodingan antrian
        input = StrToInt (Edit2->Text);


        if (gudang - input < 0)
        {
                ShowMessage("Stok Gudang Tidak Cukup!");
                Edit2->SetFocus();
                Edit2->Clear();
         }
        else if (kentang + input > 5000)
        {
                ShowMessage ("Max kentang dalam baskom 3kg!");
                Edit2->SetFocus();
                Edit2->Clear();
        }

        else
        {
        kentang = kentang + input;
        Edit3->Text = kentang;

        gudang = gudang - input;
        Edit1->Text = gudang;
        Edit2->SetFocus();

        ambil[x]=input;
        ListBox1->Items->Clear();
        Edit2->Clear();


        for ( p=0; p<=x; p++)
        {
        if(ambil[p] == 0){
        
        }
        else{
        ListBox1->Items->Add(ambil[p]);
        }
        }
        x++;
        }

        if (kentang >= 5000)
        {
                Button2->Enabled=False;
        }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button3Click(TObject *Sender)
{
        proses = StrToInt (Edit4->Text) * 100;
        Edit5->Text=proses;
        Button3->Enabled=False;
        Edit4->Enabled=False;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button4Click(TObject *Sender)
{
        //kodingan proses pengambilan kentang dari antrian
        pesanan = StrToInt (Edit5->Text);

        if (pesanan > kentang || kentang - pesanan < 0)
                {
                ShowMessage ("Kentang Tidak Cukup!");
                }
        else
        {
         diproses = diproses + pesanan;
         Edit6->Text = diproses;

         kentang = kentang-pesanan;
         Edit3->Text = kentang;

         {
                while (pesanan >= ambil [0])
                {
                        pesanan = pesanan - ambil [0];
                        int i=1;
                        ListBox1->Clear();

                        while (i<p)
                {
                        ambil [i-1] = ambil[i];
                        i = i+1;
                        ListBox1->Clear();
                }
                p= p-1;
                }

                if (pesanan < ambil[0])
                {
                ambil[0] = ambil[0] - pesanan;
                ListBox1->Clear();
                }
        
                int i=0;
                while (i < p)
                {
                        ListBox1->Items->Add(ambil[i]);
                        i=i+1;
                }
        }
        }
        Button4->Enabled=False;
        Edit5->Enabled=False;
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Button6Click(TObject *Sender)
{
        for ( p=0; p<=10; p++)
        {
        ambil[p] = NULL;
        }

        

        Edit1->Clear();
        Edit2->Clear();
        Edit3->Clear();
        Edit4->Clear();
        Edit5->Clear();
        Edit6->Clear();
        ListBox1->Clear();
        Edit4->Enabled=True;
        Edit5->Enabled=True;
        Button2->Enabled=True;
        Button3->Enabled=True;
        Button4->Enabled=True;

        p= 0;
        x=0;
        kentang = 0;

}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button5Click(TObject *Sender)
{
        Edit4->Clear();
        Edit5->Clear();
        Edit6->Clear();
        Edit4->Enabled=True;
        Edit5->Enabled=True;
        Button2->Enabled=True;
        Button3->Enabled=True;
        Button4->Enabled=True;

}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button7Click(TObject *Sender)
{
Form1->Hide();
Form3->Show();
}
//---------------------------------------------------------------------------


