var express = require("express");
var brcypt = require("bcryptjs");
var router = express.Router();
const { Op, where } = require("sequelize");
// var Anggota = require("../models/Anggota");
const { Anggota, Buku, Admin, Kategori_Buku, TA, Peminjaman } = require("../models"); // Import melalui models
const bcrypt = require("bcrypt");

/* GET home page. */
router.get("/", function (req, res, next) {
  res.redirect("/auth");
  // res.render("index", { title: "Express", layout: "layouts/nosidebar" });
});

router.post("/login", async (req, res, next) => {
  let email_anggota = req.body.email_anggota;
  let password_anggota = req.body.password_anggota; //plain text

  let anggota = await Anggota.findOne({
    where: {
      email_anggota,
    },
  });

  if (!anggota) {
    let admin = await Admin.findOne({
      where: {
        email_admin: email_anggota,
      },
    });

    if (!admin) {
      return res.redirect("/");
    } else {
      if (brcypt.compareSync(password_anggota, admin.password_admin)) {
        req.session.id_admin = admin.id_admin;
        req.session.nama_admin = admin.nama_admin;
        req.session.email_admin = admin.email_admin;
        req.session.no_hp_admin = admin.no_hp_admin;
        req.session.role_admin = admin.role_admin;

        res.cookie("sessionId", req.sessionID);
        res.redirect(`/home`);
      } else {
        console.log("Password salah");
        res.redirect("/auth");
      }
    }
  } else {
    if (brcypt.compareSync(password_anggota, anggota.password_anggota)) {
      req.session.id_anggota = anggota.id_anggota; // Simpan id anggota ke session
      req.session.nama_anggota = anggota.nama_anggota;
      req.session.email_anggota = anggota.email_anggota;
      req.session.no_hp_anggota = anggota.no_hp_anggota;
      req.session.role_anggota = anggota.role_anggota;

      res.cookie("sessionId", req.sessionID);
      res.redirect(`/user/dashborad`);
    } else {
      console.log("Password salah");
      res.redirect("/auth");
    }
  }
});

// Route untuk register anggota baru
router.post("/user/register", async (req, res) => {
  const { id_anggota, nama_anggota, alamat_anggota, no_hp_anggota, email_anggota, password_anggota } = req.body;

  let role_anggota = "Mahasiswa";
  if (!id_anggota || !nama_anggota || !alamat_anggota || !no_hp_anggota || !email_anggota || !password_anggota || !role_anggota) {
    return res.render("error", { message: "Data tidak lengkap!" });
  } else {
    const hashedPassword = await bcrypt.hash(password_anggota, 10);

    // Simpan data ke database
    const newAnggota = await Anggota.create({
      id_anggota,
      nama_anggota,
      alamat_anggota,
      no_hp_anggota,
      email_anggota,
      password_anggota: hashedPassword,
      role_anggota,
    });

    res.redirect("/");
  }
});

module.exports = router;

router.post("/user/register", async (req, res, next) => {});

router.get("/auth", function (req, res, next) {
  res.render("auth/login", { layout: "layouts/kosong" });
});
router.get("/user/profile", async function (req, res, next) {
  let id_anggota = req.session.id_anggota;
  let anggota = await Anggota.findOne({ where: { id_anggota } });

  console.log(anggota);
  res.render("User/profile", { layout: "layouts/nosidebar", anggota });
});
router.get("/user/registrasi", function (req, res, next) {
  res.render("auth/registrasi", { layout: "layouts/kosong" });
});
router.get("/user/dashborad", async function (req, res, next) {
  let id_anggota = req.query.anggota || req.session.id_anggota; // Ambil dari query atau session
  if (!id_anggota) {
    return res.redirect("/auth"); // Redirect jika tidak ada id anggota
  }

  let data = await Kategori_Buku.findAll();
  let datab = await Buku.findAll();
  let KatBuku = await Kategori_Buku.findAll({
    where: {
      jenis_kategori: "Buku",
    },
  });
  let anggota = await Anggota.findOne({ where: { id_anggota } });

  console.log(anggota);
  res.render("User/dashboard", { layout: "layouts/nosidebar", data, datab, KatBuku, anggota });
});

router.get("/user/pinjam", async function (req, res, next) {
  let id_anggota = req.query.anggota || req.session.id_anggota; // Ambil dari query atau session
  if (!id_anggota) {
    return res.redirect("/auth"); // Redirect jika tidak ada id anggota
  }

  let data = await Kategori_Buku.findAll();
  let datab = await Buku.findAll();
  let KatBuku = await Kategori_Buku.findAll({
    where: {
      jenis_kategori: "Buku",
    },
  });
  let anggota = await Anggota.findOne({ where: { id_anggota } });

  res.render("User/pinjam", { layout: "layouts/nosidebar", data, datab, KatBuku, anggota });
});

router.post("/ajukan", async function (req, res) {
  const { tanggal_pengajuan, durasi_peminjaman, judul_buku } = req.body;
  let ajuin = "diajukan";
  let id_anggota = req.query.anggota || req.session.id_anggota;

  console.log("Judul Buku:", judul_buku);

  if (!judul_buku) {
    // Jika data tidak lengkap, render halaman error atau kembali ke halaman awal
    return res.render("error", { message: "Data tidak lengkap!" });
  }

  let kode_buku;
  try {
    // Cari data buku berdasarkan judul
    const buku = await Buku.findOne({
      where: { judul_buku: judul_buku },
    });

    if (!buku) {
      return res.status(404).json({ message: "Buku tidak ditemukan!" });
    }

    if (buku.stok_buku < 1) {
      return res.status(400).json({ message: "Stok buku tidak tersedia" });
    }

    // Kurangi stok buku
    buku.stok_buku -= 1;
    await buku.save();

    kode_buku = buku.kode_buku;
  } catch (error) {
    console.error("Error saat mencari buku:", error);
    return res.status(500).send("Terjadi kesalahan saat mencari buku.");
  }

  try {
    // Konversi tanggal_pengajuan ke objek Date
    const pengajuanDate = new Date(tanggal_pengajuan);

    // Hitung tanggal jatuh tempo
    const dueDate = new Date(pengajuanDate);
    dueDate.setDate(pengajuanDate.getDate() + parseInt(durasi_peminjaman));

    // Simpan data ke database
    const newPeminjaman = await Peminjaman.create({
      id_anggota: id_anggota,
      kode_buku: kode_buku,
      tanggal_pengajuan: pengajuanDate,
      durasi_peminjaman: durasi_peminjaman,
      tanggal_jatuh_tempo: dueDate,
      judul_buku: judul_buku,
      status: ajuin,
    });

    console.log("Data berhasil disimpan:", newPeminjaman);

    // Redirect ke dashboard dengan parameter id_anggota
    res.redirect(`/user/dashborad?anggota=${id_anggota}`);
  } catch (error) {
    console.error("Error saat menyimpan data peminjaman:", error);
    res.status(500).send("Terjadi kesalahan saat menyimpan data.");
  }
});

router.get("/user/riwayat", async function (req, res, next) {
  // Ambil id_anggota dari query atau dari session
  let id_anggota = req.query.anggota || req.session.id_anggota;

  // Jika id_anggota tidak tersedia, redirect ke halaman login
  if (!id_anggota) {
    return res.redirect("/auth");
  }

  // Ambil data anggota
  let anggota = await Anggota.findOne({ where: { id_anggota } });
  if (!anggota) {
    return res.status(404).send("Data anggota tidak ditemukan.");
  }

  try {
    // Ambil data peminjaman berdasarkan id_anggota
    let type = await Peminjaman.findAll({
      where: {
        id_anggota,
        status: {
          [Op.or]: ["dipinjam", "terlambat", "diajukan", "ditolak"], // Pengecekan status
        },
      },
    });

    // Ambil judul buku untuk setiap peminjaman
    for (let i = 0; i < type.length; i++) {
      const kodeBuku = type[i].kode_buku;
      const buku = await Buku.findOne({
        where: { kode_buku: kodeBuku },
      });

      // Tambahkan judul_buku ke objek type
      type[i].judul_buku = buku.judul_buku;
    }

    let typeb = await Peminjaman.findAll({
      where: {
        id_anggota,
        status: "dikembalikan",
      },
    });

    // Ambil judul buku untuk setiap peminjaman
    for (let i = 0; i < typeb.length; i++) {
      const kodeBuku = typeb[i].kode_buku;
      const buku = await Buku.findOne({
        where: { kode_buku: kodeBuku },
      });

      // Tambahkan judul_buku ke objek typeb
      typeb[i].judul_buku = buku.judul_buku;
    }

    // Render halaman riwayat dengan data anggota dan peminjaman
    res.render("User/riwayat", { layout: "layouts/nosidebar", anggota, type, typeb });
  } catch (error) {
    console.error("Error saat mengambil data peminjaman:", error);
    res.status(500).send("Terjadi kesalahan saat mengambil data peminjaman.");
  }
});

router.get("/home", async function (req, res, next) {
  let nama_admin = req.session.nama_admin;

  let data = await Anggota.findAll();
  let datab = await Buku.findAll();

  let y;
  for (let i = 0; i < 1; i++) {
    namanya = data.nama_anggota;
    bukunya = datab.judul_buku;
  }
  res.render("home", {data, datab});
});

router.get("/Lihatbuku", async function (req, res, next) {
  let data = await Kategori_Buku.findAll();
  let datab = await Buku.findAll();
  data.baru = datab.judul_buku;
  let KatBuku = await Kategori_Buku.findAll({
    where: {
      jenis_kategori: "Buku",
    },
  });

  res.render("Buku/Lihat", { data: data, datab, KatBuku });
});

router.post("/cari1", async function (req, res, next) {
  const { all } = req.body;
  try {
    const datab = await Buku.findAll({
      where: {
        [Op.or]: [{ judul_buku: { [Op.like]: `%${all}%` } }, { penulis: { [Op.like]: `%${all}%` } }, { tahun_terbit: { [Op.like]: `%${all}%` } }],
      },
    });

    res.render("Buku/Lihat", { datab });
  } catch (error) {
    console.error("Error searching outgoing docs (All-in-One):", error);
    res.status(500).send("Internal Server Error");
  }
});
router.post("/cari2", async function (req, res, next) {
  const { all } = req.body;
  try {
    const datat = await TA.findAll({
      where: {
        [Op.or]: [{ judul_ta: { [Op.like]: `%${all}%` } }, { penulis: { [Op.like]: `%${all}%` } }, { tahun_terbit: { [Op.like]: `%${all}%` } }],
      },
    });

    res.render("TA/Lihat", { datat });
  } catch (error) {
    console.error("Error searching outgoing docs (All-in-One):", error);
    res.status(500).send("Internal Server Error");
  }
});

router.get("/Tambahbuku", async function (req, res, next) {
  let KatBuku = await Kategori_Buku.findAll({
    where: {
      jenis_kategori: "Buku",
    },
  });
  res.render("Buku/tambah", { KatBuku });
});

router.post("/Tambahbuku", async function (req, res) {
  const { judul_buku, penulis, pengarang, tahun_terbit, jumlah_halaman, stok_buku, id_kategori } = req.body;

  const newDoc = await Buku.create({
    judul_buku: judul_buku,
    penulis: penulis,
    pengarang: pengarang,
    tahun_terbit: tahun_terbit,
    jumlah_halaman,
    stok_buku: stok_buku,
    id_kategori: id_kategori,
  });
  res.redirect("Lihatbuku");
});

router.get("/LihatTA", async function (req, res, next) {
  let datat = await TA.findAll();
  let KatTA = await Kategori_Buku.findAll({
    where: {
      jenis_kategori: "TA",
    },
  });

  res.render("TA/Lihat", { KatTA, datat });
});

router.get("/TambahTA", async function (req, res, next) {
  let datat = await TA.findAll();
  let KatTA = await Kategori_Buku.findAll({
    where: {
      jenis_kategori: "TA",
    },
  });
  res.render("TA/tambah", { datat, KatTA });
});

router.post("/TambahTA", async function (req, res) {
  const { judul_ta, penulis, pembimbing, tahun_terbit, jumlah_halaman, kategori } = req.body;

  const newTA = await TA.create({
    judul_ta: judul_ta,
    penulis: penulis,
    pembimbing: pembimbing,
    tahun_terbit: tahun_terbit,
    jumlah_halaman,
    kategori: kategori,
  });
  console.log("data di newTA : " + newTA + ":::::");
  res.redirect("LihatTA");
});

router.get("/pengajuan", async function (req, res, next) {
  try {
    // Ambil data peminjaman berdasarkan status "diajukan"
    let type = await Peminjaman.findAll({
      where: { status: "diajukan" },
    });

    // Ambil judul buku dan nama anggota untuk setiap peminjaman
    for (let i = 0; i < type.length; i++) {
      const kodeBuku = type[i].kode_buku;
      const buku = await Buku.findOne({
        where: { kode_buku: kodeBuku },
      });

      // Tambahkan judul_buku ke objek type jika buku ditemukan
      type[i].judul_buku = buku ? buku.judul_buku : "Tidak ditemukan";

      const namaAnggota = type[i].id_anggota;
      const anggota = await Anggota.findOne({
        where: { id_anggota: namaAnggota },
      });

      // Tambahkan nama_anggota ke objek type jika anggota ditemukan
      type[i].nama_anggota = anggota ? anggota.nama_anggota : "Tidak ditemukan";
    }

    // Ambil data peminjaman berdasarkan status "dipinjam"
    let typeb = await Peminjaman.findAll({
      where: { status: "dipinjam" },
    });

    // Ambil judul buku dan nama anggota untuk setiap peminjaman
    for (let i = 0; i < typeb.length; i++) {
      const kodeBuku = typeb[i].kode_buku;
      const buku = await Buku.findOne({
        where: { kode_buku: kodeBuku },
      });

      // Tambahkan judul_buku ke objek typeb jika buku ditemukan
      typeb[i].judul_buku = buku ? buku.judul_buku : "Tidak ditemukan";

      const namaAnggota = typeb[i].id_anggota;
      const anggota = await Anggota.findOne({
        where: { id_anggota: namaAnggota },
      });

      // Tambahkan nama_anggota ke objek typeb jika anggota ditemukan
      typeb[i].nama_anggota = anggota ? anggota.nama_anggota : "Tidak ditemukan";
    }

    // Render halaman riwayat dengan data anggota dan peminjaman
    res.render("pengembalian/peminjaman", { type, typeb });
  } catch (error) {
    console.error("Error saat mengambil data peminjaman:", error);
    res.status(500).send("Terjadi kesalahan saat mengambil data peminjaman.");
  }
});

router.post("/pengajuan/update-status", async function (req, res, next) {
  try {
    // Ambil ID peminjaman dan aksi dari body request
    const id_peminjaman = req.body.id_peminjaman;
    const action = req.body.action;

    // Validasi input
    if (!id_peminjaman || !action) {
      return res.status(400).send("ID peminjaman atau aksi tidak valid.");
    }

    // Tentukan status berdasarkan aksi
    let newStatus;
    if (action === "confirm") {
      newStatus = "dipinjam";
    } else if (action === "reject") {
      newStatus = "ditolak";
    } else {
      return res.status(400).send("Aksi tidak valid.");
    }

    let id_admin = req.session.id_admin;
    // Perbarui status di database
    const updated = await Peminjaman.update({ status: newStatus, id_admin }, { where: { id_peminjaman } });

    res.redirect("/pengajuan"); // Redirect kembali ke halaman pengajuan
  } catch (error) {
    console.error("Error saat memperbarui status peminjaman:", error);
    res.status(500).send("Terjadi kesalahan saat memperbarui status.");
  }
});

router.get("/riwayat", async function (req, res, next) {
  try {
    // Ambil data peminjaman berdasarkan id_anggota
    let type = await Peminjaman.findAll({
      where: {
        status: {
          [Op.or]: ["dikembalikan", "ditolak"], // Pengecekan status
        },
      },
    });

    // Ambil judul buku untuk setiap peminjaman
    for (let i = 0; i < type.length; i++) {
      const kodeBuku = type[i].kode_buku;
      const buku = await Buku.findOne({
        where: { kode_buku: kodeBuku },
      });

      // Tambahkan judul_buku ke objek type
      type[i].judul_buku = buku.judul_buku;

      const namaAnggota = type[i].id_anggota;
      const anggota = await Anggota.findOne({
        where: { id_anggota: namaAnggota },
      });

      // Tambahkan judul_buku ke objek type
      type[i].nama_anggota = anggota.nama_anggota;
    }

    // Render halaman riwayat dengan data anggota dan peminjaman
    res.render("pengembalian/riwayat", { type });
  } catch (error) {
    console.error("Error saat mengambil data peminjaman:", error);
    res.status(500).send("Terjadi kesalahan saat mengambil data peminjaman.");
  }
});

router.post("/pengembalian/update-status", async function (req, res, next) {
  try {
    // Ambil ID peminjaman dan aksi dari body request
    const id_peminjaman = req.body.id_peminjaman;
    const action = req.body.action;

    // Validasi input
    if (!id_peminjaman || !action) {
      return res.status(400).send("ID peminjaman atau aksi tidak valid.");
    }

    const pengembalianDate = new Date();
    // Tentukan status berdasarkan aksi
    let newStatus;
    let dendanya = 0;
    if (action === "confirm") {
      newStatus = "dikembalikan";
      tanggal_pengembalian = pengembalianDate;
      // Perbarui status di database
      const updated = await Peminjaman.update({ tanggal_pengembalian }, { where: { id_peminjaman } });
    } else if (action === "late") {
      newStatus = "terlambat";
      let type = await Peminjaman.findOne({
        where: { id_peminjaman },
      });

      let tanggal_jatuh_tempo1 = type.tanggal_jatuh_tempo;
      let tanggal_jatuh_tempo = new Date(tanggal_jatuh_tempo1);
      const pengajuanDate = new Date();

      // Hitung tanggal jatuh tempo
      const dueDate = new Date(pengajuanDate);
      const durasi_peminjaman = pengajuanDate.getDate() - tanggal_jatuh_tempo.getDate();

      if (durasi_peminjaman < 0) {
        dendanya = durasi_peminjaman * -5000;
      } else {
        return res.status(400).send("Buku masih dalam masa peminjaman");
      }
      console.log("++++++++++++++++++++" + pengajuanDate.getDate() + "+++" + tanggal_jatuh_tempo.getDate());
      console.log(dendanya);
    } else {
      return res.status(400).send("Aksi tidak valid.");
    }
    // Perbarui status di database
    const updated = await Peminjaman.update({ status: newStatus, denda: dendanya }, { where: { id_peminjaman } });

    if (updated[0] === 0) {
      return res.status(404).send("Peminjaman tidak ditemukan.");
    }

    res.redirect("/pengajuan"); // Redirect kembali ke halaman pengajuan
  } catch (error) {
    console.error("Error saat memperbarui status peminjaman:", error);
    res.status(500).send("Terjadi kesalahan saat memperbarui status.");
  }
});

router.post("/Bayardenda", async function (req, res, next) {
  try {
    // Ambil ID peminjaman dan aksi dari body request
    const id_peminjaman = req.body.id_peminjaman;
    const action = req.body.action;

    // Validasi input
    if (!id_peminjaman || !action) {
      return res.status(400).send("ID peminjaman atau aksi tidak valid.");
    }

    // Tentukan status berdasarkan aksi
    let newStatus;
    if (action === "confirm") {
      newStatus = "dikembalikan";
    } else {
      return res.status(400).send("Aksi tidak valid.");
    }

    // Perbarui status di database
    const updated = await Peminjaman.update({ status: newStatus }, { where: { id_peminjaman } });

    if (updated[0] === 0) {
      return res.status(404).send("Peminjaman tidak ditemukan.");
    }

    res.redirect("/denda"); // Redirect kembali ke halaman pengajuan
  } catch (error) {
    console.error("Error saat memperbarui status peminjaman:", error);
    res.status(500).send("Terjadi kesalahan saat memperbarui status.");
  }
});
router.post("/user/reservasi", async function (req, res, next) {
  try {
    const kode_buku = req.body.kode_buku;
    const action = req.body.action;
    const bukus = await Buku.findOne({
      where: { kode_buku: kode_buku },
    });
    if (!bukus) {
      return res.status(404).json({ message: "Buku tidak ditemukan!" });
    }
    if (bukus.stok_buku > 1) {
      return res.status(400).json({ message: "Buku masih bisa dipinjam" });
    }
    // Tentukan status berdasarkan aksi
    let newStatus;
    if (action === "confirm") {
      res.redirect("/user/reservasi");
    }
  } catch (error) {
    console.error("Error saat memperbarui status peminjaman:", error);
    res.status(500).send("Terjadi kesalahan saat memperbarui status.");
  }
});

router.get("/denda", async function (req, res, next) {
  try {
    // Ambil data peminjaman berdasarkan id_anggota
    let type = await Peminjaman.findAll({
      where: { status: "terlambat" },
    });

    // Ambil judul buku untuk setiap peminjaman
    for (let i = 0; i < type.length; i++) {
      const kodeBuku = type[i].kode_buku;
      const buku = await Buku.findOne({
        where: { kode_buku: kodeBuku },
      });

      // Tambahkan judul_buku ke objek type
      type[i].judul_buku = buku.judul_buku;

      const namaAnggota = type[i].id_anggota;
      const anggota = await Anggota.findOne({
        where: { id_anggota: namaAnggota },
      });

      let tanggal_jatuh_tempo1 = type[i].tanggal_jatuh_tempo;
      let tanggal_jatuh_tempo = new Date(tanggal_jatuh_tempo1);
      const pengajuanDate = new Date();

      // Hitung tanggal jatuh tempo
      const dueDate = new Date(pengajuanDate);
      const durasi_peminjaman = pengajuanDate.getDate() - tanggal_jatuh_tempo.getDate();

      let dendanya = 0;
      if (durasi_peminjaman < 0) {
        dendanya = durasi_peminjaman * -5000;
      }
      console.log("++++++++++++++++++++" + pengajuanDate.getDate() + "+++" + tanggal_jatuh_tempo.getDate());
      console.log(dendanya);
      // Tambahkan judul_buku ke objek type
      type[i].nama_anggota = anggota.nama_anggota;
    }

    // Render halaman riwayat dengan data anggota dan peminjaman
    res.render("denda/denda", { type });
  } catch (error) {
    console.error("Error saat mengambil data peminjaman:", error);
    res.status(500).send("Terjadi kesalahan saat mengambil data peminjaman.");
  }
});

router.get("/reservasi", function (req, res, next) {
  res.render("reservasi/list");
});

router.get("/user/reservasi", async function (req, res, next) {
  let id_anggota = req.query.anggota || req.session.id_anggota;
  let data = await Kategori_Buku.findAll();
  let datab = await Buku.findAll();
  let KatBuku = await Kategori_Buku.findAll({
    where: {
      jenis_kategori: "Buku",
    },
  });

  res.render("User/reservasi", { layout: "layouts/nosidebar", data, datab, KatBuku });
});

router.get("/TambahKategori", function (req, res, next) {
  res.render("TambahKategori/TambahKategori");
});

router.post("/TambahKategori", async function (req, res) {
  const { nama_kategori, jenis_kategori } = req.body;

  const newKat = await Kategori_Buku.create({
    nama_kategori,
    jenis_kategori,
  });
  console.log("data di newKat : " + newKat + ":::::");
  res.redirect("TambahKategori");
});

module.exports = router;
