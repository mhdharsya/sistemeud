"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable("bukus", {
      kode_buku: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      judul_buku: {
        type: Sequelize.STRING,
      },
      penulis: {
        type: Sequelize.STRING,
      },
      pengarang: {
        type: Sequelize.STRING,
      },
      tahun_terbit: {
        type: Sequelize.INTEGER,
      },
      jumlah_halaman: {
        type: Sequelize.INTEGER,
      },
      stok_buku: {
        type: Sequelize.INTEGER,
      },
      id_kategori: {
        type: Sequelize.INTEGER,
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable("bukus");
  },
};
