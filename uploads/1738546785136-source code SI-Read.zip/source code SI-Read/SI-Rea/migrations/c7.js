"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable("tas", {
      kode_ta: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      judul_ta: {
        type: Sequelize.STRING,
      },
      penulis: {
        type: Sequelize.STRING,
      },
      pembimbing: {
        type: Sequelize.STRING,
      },
      tahun_terbit: {
        type: Sequelize.INTEGER,
      },
      jumlah_halaman: {
        type: Sequelize.INTEGER,
      },
      kategori: {
        type: Sequelize.INTEGER,
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable("tas");
  },
};
