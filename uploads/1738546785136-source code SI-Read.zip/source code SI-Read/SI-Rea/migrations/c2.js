"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable("anggotas", {
      id_anggota: {
        allowNull: false,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      nama_anggota: {
        type: Sequelize.STRING,
      },
      alamat_anggota: {
        type: Sequelize.STRING,
      },
      no_hp_anggota: {
        type: Sequelize.STRING,
      },
      email_anggota: {
        type: Sequelize.STRING,
      },
      password_anggota: {
        type: Sequelize.STRING,
      },
      role_anggota: {
        type: Sequelize.STRING,
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable("anggotas");
  },
};
