const bcrypt = require("bcrypt");
("use strict");

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert(
      "Anggotas",
      [
        {
          id_anggota: "2031",
          email_anggota: "agif@student.unand.ac.id",
          nama_anggota: "agif",
          no_hp_anggota: "0812121212",
          alamat_anggota: "jiung",
          password_anggota: await bcrypt.hash("agif", 10),
          role_anggota: "Mhs",
          created_at: new Date(),
          updated_at: new Date(),
        },
      ],
      {}
    );
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete("Anggotas", null, {});
  },
};
