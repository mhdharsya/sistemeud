const bcrypt = require('bcrypt');
'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
   
     await queryInterface.bulkInsert('Admins', [{
        email_admin: 'FTI@student.unand.ac.id',
        nama_admin: 'FTI',
        no_hp_admin: '081213141516',
        alamat_admin: "pauh",
        password_admin: await bcrypt.hash('FTI',10),
        role_admin:'Pengelola',
        created_at: new Date(),
        updated_at: new Date(),
      }  
   ],{});
     
  },

  async down (queryInterface, Sequelize) {
     await queryInterface.bulkDelete('Admins', null, {});
  }
};
