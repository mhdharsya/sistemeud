"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Kategori_Buku extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  Kategori_Buku.init(
    {
      id_kategori: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true, // Jika menggunakan auto increment
      },
      nama_kategori: DataTypes.STRING,
      jenis_kategori: DataTypes.STRING,
    },
    {
      sequelize,
      tableName: "kategori_bukus",
      modelName: "Kategori_Buku",
      updatedAt: "updated_at",
      createdAt: "created_at",
    }
  );
  return Kategori_Buku;
};
