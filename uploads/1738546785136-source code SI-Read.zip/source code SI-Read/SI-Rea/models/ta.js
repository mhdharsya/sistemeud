"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class TA extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  TA.init(
    {
      kode_ta: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true, // Jika menggunakan auto increment
      },
      judul_ta: DataTypes.STRING,
      penulis: DataTypes.STRING,
      pembimbing: DataTypes.STRING,
      tahun_terbit: DataTypes.INTEGER, 
      jumlah_halaman: DataTypes.INTEGER, 
      kategori: DataTypes.INTEGER, 
    },
    {
      sequelize,
      tableName: "tas",
      modelName: "TA",
      updatedAt: "updated_at",
      createdAt: "created_at",
    }
  );
  return TA;
};
