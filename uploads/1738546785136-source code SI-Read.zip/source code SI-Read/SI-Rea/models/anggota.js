"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Anggota extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  Anggota.init(
    {
      id_anggota: {
        type: DataTypes.INTEGER,
        primaryKey: true,
      },
      nama_anggota: DataTypes.STRING,
      alamat_anggota: DataTypes.STRING,
      no_hp_anggota: DataTypes.STRING,
      email_anggota: DataTypes.STRING, 
      password_anggota: DataTypes.STRING,
      role_anggota: DataTypes.STRING, 
    },
    {
      sequelize,
      tableName: "anggotas",
      modelName: "Anggota",
      updatedAt: "updated_at",
      createdAt: "created_at",
      // timestamps: true,
    }
  );
  return Anggota;
};
