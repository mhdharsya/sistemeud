"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Buku extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  Buku.init(
    {
      kode_buku: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true, // Jika menggunakan auto increment
      },

      judul_buku: DataTypes.STRING,
      penulis: DataTypes.STRING,
      pengarang: DataTypes.STRING,
      tahun_terbit: DataTypes.INTEGER, 
      jumlah_halaman: DataTypes.INTEGER, 
      stok_buku: DataTypes.INTEGER,
      id_kategori: DataTypes.INTEGER, 
    },
    {
      sequelize,
      tableName: "bukus",
      modelName: "Buku",
      updatedAt: "updated_at",
      createdAt: "created_at",
    }
  );
  return Buku;
};
