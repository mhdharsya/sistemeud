"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Admin extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  Admin.init(
    {
      id_admin: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true, // Jika menggunakan auto increment
      },
      nama_admin: DataTypes.STRING,
      alamat_admin: DataTypes.STRING,
      no_hp_admin: DataTypes.STRING,
      email_admin: DataTypes.STRING, 
      password_admin: DataTypes.STRING,
      role_admin: DataTypes.STRING, 
    },
    {
      sequelize,
      tableName: "admins",
      modelName: "Admin",
      updatedAt: "updated_at",
      createdAt: "created_at",
    }
  );
  return Admin;
};
