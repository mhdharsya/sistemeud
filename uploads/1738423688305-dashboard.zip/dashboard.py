import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import seaborn as sns
from io import StringIO

def load_dataset():
    st.title("1. Input Dataset ke Sistem")
    
    uploaded_files = {
        'medals': st.file_uploader("Upload medals dataset (CSV)", type=['csv']),
        'athletes': st.file_uploader("Upload athletes dataset (CSV)", type=['csv']),
        'results': st.file_uploader("Upload results dataset (CSV)", type=['csv']),
        'hosts': st.file_uploader("Upload hosts dataset (CSV)", type=['csv'])
    }
    
    dataframes = {}
    if any(uploaded_files.values()):
        st.header("Preview Data")
        for key, file in uploaded_files.items():
            if file is not None:
                try:
                    df = pd.read_csv(file)
                    dataframes[key] = df
                    
                    st.subheader(f"{key.capitalize()} Dataset")
                    col1, col2 = st.columns(2)
                    with col1:
                        st.write("Top 5 Rows:")
                        st.dataframe(df.head())
                    with col2:
                        st.write("Bottom 5 Rows:")
                        st.dataframe(df.tail())
                    
                    st.write(f"Shape: {df.shape}")
                    
                except Exception as e:
                    st.error(f"Error loading {key} dataset: {e}")
    
    return dataframes

def detailed_eda(dataframes):
    st.title("2. Preprocess Data di Sistem")
    
    processed_dfs = {}
    
    for name, df in dataframes.items():
        st.header(f"Analysis of {name.capitalize()} Dataset")
        
        # Basic Information
        st.subheader("Basic Information")
        col1, col2 = st.columns(2)
        with col1:
            st.write("Dataset Shape:", df.shape)
            st.write("Datatypes:")
            st.write(df.dtypes)
        with col2:
            st.write("Memory Usage:", df.memory_usage().sum() / 1024**2, "MB")
            st.write("Number of Duplicates:", df.duplicated().sum())
        
        # Missing Values Analysis
        st.subheader("Missing Values Analysis")
        missing = pd.DataFrame({
            'Column': df.columns,
            'Missing Values': df.isnull().sum(),
            'Missing Percentage': (df.isnull().sum() / len(df) * 100).round(2)
        })
        st.dataframe(missing[missing['Missing Values'] > 0])
        
        # Handling Missing Values
        if missing['Missing Values'].sum() > 0:
            st.write("Handling Missing Values:")
            
            for column in df.columns[df.isnull().any()]:
                st.write(f"\nColumn: {column}")
                
                # Show unique values and their counts
                st.write("Value Distribution:")
                st.write(df[column].value_counts().head())
                
                # Suggest handling method based on missing percentage and data type
                missing_pct = (df[column].isnull().sum() / len(df)) * 100
                
                if missing_pct < 5:  # Low missing percentage
                    if df[column].dtype in ['int64', 'float64']:
                        df[column].fillna(df[column].mean(), inplace=True)
                        st.write("Action: Filled with mean value (low missing percentage)")
                    else:
                        df[column].fillna(df[column].mode()[0], inplace=True)
                        st.write("Action: Filled with mode value (low missing percentage)")
                else:  # High missing percentage
                    if column in ['athlete_full_name', 'country_name', 'medal_type']:
                        # Critical columns - keep null
                        st.write("Action: Kept null values (critical column)")
                    else:
                        df[column].fillna('Unknown', inplace=True)
                        st.write("Action: Filled with 'Unknown' (high missing percentage)")
        
        # Statistical Summary
        if df.select_dtypes(include=[np.number]).columns.any():
            st.subheader("Statistical Summary")
            st.write(df.describe())
        
        # Save processed dataframe
        processed_dfs[name] = df
    
    return processed_dfs

def check_column_names(df):
    """Helper function to find country and athlete related columns"""
    country_columns = [col for col in df.columns if 'country' in col.lower() or 'noc' in col.lower()]
    athlete_columns = [col for col in df.columns if 'athlete' in col.lower()]
    return {
        'country_columns': country_columns,
        'athlete_columns': athlete_columns
    }

def perform_analysis(dataframes):
    st.title("3. Analisis Data di Sistem")
    
    if 'medals' in dataframes:
        medals_df = dataframes['medals'].copy()
        
        st.header("Clustering Analysis of Olympic Medal Performance")
        
        # Prepare data for clustering
        # Calculate medal counts for each country separately
        gold_counts = medals_df[medals_df['medal_type'] == 'GOLD'].groupby('country_name').size()
        silver_counts = medals_df[medals_df['medal_type'] == 'SILVER'].groupby('country_name').size()
        bronze_counts = medals_df[medals_df['medal_type'] == 'BRONZE'].groupby('country_name').size()
        
        # Combine the counts into a single dataframe
        country_medals = pd.DataFrame({
            'gold_count': gold_counts,
            'silver_count': silver_counts,
            'bronze_count': bronze_counts
        }).fillna(0)
        
        # Reset index to make country a column
        country_medals = country_medals.reset_index()
        
        # Calculate total medals
        country_medals['total_medals'] = country_medals[['gold_count', 'silver_count', 'bronze_count']].sum(axis=1)
        
        # Remove countries with no medals
        country_medals = country_medals[country_medals['total_medals'] > 0]
        
        # Normalize the features
        features = ['gold_count', 'silver_count', 'bronze_count']
        X = country_medals[features]
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # Perform clustering
        n_clusters = st.slider("Number of Clusters", 2, 10, 5)
        kmeans = KMeans(n_clusters=n_clusters, random_state=42)
        country_medals['Cluster'] = kmeans.fit_predict(X_scaled)
        
        # Visualize clusters
        st.subheader("3D Visualization of Country Clusters")
        fig = px.scatter_3d(
            country_medals,
            x='gold_count',
            y='silver_count',
            z='bronze_count',
            color='Cluster',
            hover_data=['country_name', 'total_medals'],
            title='Country Clusters based on Medal Performance',
            labels={
                'gold_count': 'Gold Medals',
                'silver_count': 'Silver Medals',
                'bronze_count': 'Bronze Medals'
            }
        )
        st.plotly_chart(fig)
        
        # Analyze clusters
        st.subheader("Cluster Analysis")
        for i in range(n_clusters):
            cluster_data = country_medals[country_medals['Cluster'] == i]
            
            st.write(f"\nCluster {i}")
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("Top 5 Countries in Cluster:")
                st.dataframe(
                    cluster_data.nlargest(5, 'total_medals')[
                        ['country_name', 'gold_count', 'silver_count', 'bronze_count', 'total_medals']
                    ]
                )
            
            with col2:
                st.write("Cluster Statistics:")
                st.write(f"Number of Countries: {len(cluster_data)}")
                st.write(f"Average Total Medals: {cluster_data['total_medals'].mean():.2f}")
                st.write(f"Average Gold Medals: {cluster_data['gold_count'].mean():.2f}")
        
        # Add cluster characteristics visualization
        st.subheader("Cluster Characteristics")
        cluster_means = country_medals.groupby('Cluster')[features].mean()
        
        fig = go.Figure()
        for medal in features:
            fig.add_trace(go.Bar(
                name=medal.replace('_count', '').capitalize(),
                x=cluster_means.index,
                y=cluster_means[medal],
                text=cluster_means[medal].round(1),
                textposition='auto',
            ))
        
        fig.update_layout(
            barmode='group',
            title='Average Medal Counts per Cluster',
            xaxis_title='Cluster',
            yaxis_title='Average Number of Medals'
        )
        st.plotly_chart(fig)

def create_visualization(dataframes):
    st.title("4. Visualisasi Data di Sistem")
    
    if 'medals' not in dataframes or 'hosts' not in dataframes:
        st.warning("Please upload medals and hosts datasets for visualization.")
        return
    
    medals_df = dataframes['medals'].copy()
    hosts_df = dataframes['hosts'].copy()
    
    # Menggabungkan informasi season dari hosts ke medals berdasarkan slug_game
    if 'slug_game' in medals_df.columns and 'game_slug' in hosts_df.columns:
        medals_df = pd.merge(
            medals_df,
            hosts_df[['game_slug', 'game_season']],
            left_on='slug_game',
            right_on='game_slug',
            how='left'
        )
    else:
        st.error("Required columns not found in datasets.")
        return
    
    # Initialize widget key
    widget_key = st.session_state.get('widget_key', 0)
    
    # Initialize default values
    DEFAULTS = {
        'season': 'All',
        'country': 'All',
        'discipline': 'All',
        'athlete': 'All'
    }
    
    # Initialize session state for filters and keys
    if 'filters' not in st.session_state:
        st.session_state.filters = DEFAULTS.copy()
    
    # Create filters in sidebar
    st.sidebar.header("FILTERS")
    
    # Season filter (Summer/Winter)
    seasons = ['All'] + sorted(hosts_df['game_season'].unique().tolist())
    season = st.sidebar.selectbox(
        "Select Season",
        seasons,
        index=seasons.index(st.session_state.filters['season']),
        key=f'season_select_{widget_key}'
    )
    st.session_state.filters['season'] = season
    
    # Year range slider
    year_min = int(hosts_df['game_year'].min())
    year_max = int(hosts_df['game_year'].max())
    year_range = st.sidebar.slider(
        "Select Years",
        min_value=year_min,
        max_value=year_max,
        value=(year_min, year_max) if not 'year_range' in st.session_state.filters else st.session_state.filters['year_range'],
        key=f'year_slider_{widget_key}'
    )
    st.session_state.filters['year_range'] = year_range
    
    # Country filter
    countries = ['All'] + sorted(medals_df['country_name'].dropna().unique().tolist())
    country = st.sidebar.selectbox(
        "Select Country",
        countries,
        index=countries.index(st.session_state.filters['country']),
        key=f'country_select_{widget_key}'
    )
    st.session_state.filters['country'] = country
    
    # Discipline filter
    disciplines = ['All'] + sorted(medals_df['discipline_title'].dropna().unique().tolist())
    discipline = st.sidebar.selectbox(
        "Select Discipline",
        disciplines,
        index=disciplines.index(st.session_state.filters['discipline']),
        key=f'discipline_select_{widget_key}'
    )
    st.session_state.filters['discipline'] = discipline
    
    # Athlete filter
    athletes = ['All'] + sorted(medals_df['athlete_full_name'].dropna().unique().tolist())
    athlete = st.sidebar.selectbox(
        "Select Athlete",
        athletes,
        index=athletes.index(st.session_state.filters['athlete']),
        key=f'athlete_select_{widget_key}'
    )
    st.session_state.filters['athlete'] = athlete
    
    # Apply filters
    filtered_df = medals_df.copy()

    # Reset filters button
    reset_clicked = st.sidebar.button("Reset Filters", key='reset_button')
    if reset_clicked:
        st.session_state.filters = DEFAULTS.copy()
        if 'year' in filtered_df.columns:
            st.session_state.filters['year_range'] = (year_min, year_max)
        st.session_state.widget_key = st.session_state.get('widget_key', 0) + 1
        st.experimental_rerun()
    
    # Apply filters
    filtered_df = medals_df.copy()
    
    # Apply season filter
    if season != 'All':
        filtered_df = filtered_df[filtered_df['game_season'] == season]
    
    # Apply year filter
    filtered_df = pd.merge(
        filtered_df,
        hosts_df[['game_slug', 'game_year']],
        left_on='slug_game',
        right_on='game_slug',
        how='left'
    )
    
    filtered_df = filtered_df[
        (filtered_df['game_year'] >= year_range[0]) &
        (filtered_df['game_year'] <= year_range[1])
    ]
    
    # Apply other filters
    if country != 'All':
        filtered_df = filtered_df[filtered_df['country_name'] == country]
    if discipline != 'All':
        filtered_df = filtered_df[filtered_df['discipline_title'] == discipline]
    if athlete != 'All':
        filtered_df = filtered_df[filtered_df['athlete_full_name'] == athlete]
    
    # Display key metrics
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Athletes", len(filtered_df['athlete_full_name'].unique()))
    with col2:
        st.metric("Disciplines", len(filtered_df['discipline_title'].unique()))
    with col3:
        st.metric("Events", len(filtered_df['event_title'].unique()))
    
    # World Map Visualization
    st.subheader("Medal Distribution World Map")
    country_total_medals = filtered_df.groupby('country_name')['medal_type'].count().reset_index()
    country_total_medals.columns = ['country', 'total_medals']
    
    fig = px.choropleth(
        country_total_medals,
        locations='country',
        locationmode='country names',
        color='total_medals',
        hover_name='country',
        color_continuous_scale='Viridis',
        title=f'Total Medals by Country {f"({season})" if season != "All" else ""}'
    )
    
    fig.update_layout(
        height=600,
        title_x=0.5,
        geo=dict(
            showframe=False,
            showcoastlines=True,
            projection_type='equirectangular'
        )
    )
    st.plotly_chart(fig)
    
    # Total Medals by Country (Horizontal Stacked Bar)
    st.subheader("Total Medals by Country")
    country_medals = filtered_df.groupby('country_name')['medal_type'].value_counts().unstack(fill_value=0)
    country_medals['Total'] = country_medals.sum(axis=1)
    country_medals = country_medals.sort_values('Total', ascending=True).tail(30)
    
    fig = go.Figure()
    for medal_type in ['GOLD', 'SILVER', 'BRONZE']:
        if medal_type in country_medals.columns:
            fig.add_trace(go.Bar(
                y=country_medals.index,
                x=country_medals[medal_type],
                name=medal_type,
                orientation='h',
                text=country_medals[medal_type],
                textposition='auto',
                marker_color={'GOLD': '#FFD700', 'SILVER': '#C0C0C0', 'BRONZE': '#CD7F32'}[medal_type]
            ))
    
    annotations = []
    for i, row in enumerate(country_medals.itertuples()):
        annotations.append(dict(
            x=row.Total,
            y=row.Index,
            text=f'Total: {row.Total}',
            showarrow=False,
            xanchor='left',
            xshift=10
        ))
    
    fig.update_layout(
        barmode='stack',
        title=f'Medal Distribution by Country {f"({season})" if season != "All" else ""}',
        xaxis_title='Number of Medals',
        yaxis_title='Country',
        height=800,
        showlegend=True,
        yaxis={'categoryorder':'total ascending'},
        annotations=annotations
    )
    st.plotly_chart(fig)
    
    # Medal Count by Discipline
    st.subheader("Medal Count by Discipline")
    discipline_medals = filtered_df.groupby('discipline_title')['medal_type'].value_counts().unstack(fill_value=0)
    discipline_medals['Total'] = discipline_medals.sum(axis=1)
    discipline_medals = discipline_medals.sort_values('Total', ascending=False).head(20)
    
    fig = go.Figure()
    for medal_type in ['GOLD', 'SILVER', 'BRONZE']:
        if medal_type in discipline_medals.columns:
            fig.add_trace(go.Bar(
                x=discipline_medals.index,
                y=discipline_medals[medal_type],
                name=medal_type,
                text=discipline_medals[medal_type],
                textposition='auto',
                marker_color={'GOLD': '#FFD700', 'SILVER': '#C0C0C0', 'BRONZE': '#CD7F32'}[medal_type]
            ))
    
    annotations = []
    for i, (idx, row) in enumerate(discipline_medals.iterrows()):
        annotations.append(dict(
            x=idx,
            y=row['Total'],
            text=f'Total: {row["Total"]}',
            showarrow=False,
            yshift=10
        ))
    
    fig.update_layout(
        barmode='group',
        title=f'Top 20 Disciplines by Medal Count {f"({season})" if season != "All" else ""}',
        xaxis_title='Discipline',
        yaxis_title='Number of Medals',
        height=600,
        showlegend=True,
        xaxis_tickangle=45,
        annotations=annotations
    )
    st.plotly_chart(fig)
    
    # Gender and Medal Type Distribution
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Gender Distribution")
        gender_counts = filtered_df['event_gender'].value_counts()
        fig = px.pie(
            values=gender_counts.values,
            names=gender_counts.index,
            title=f'Events by Gender {f"({season})" if season != "All" else ""}'
        )
        fig.update_traces(
            textposition='inside',
            textinfo='label+value+percent'
        )
        st.plotly_chart(fig)
    
    with col2:
        st.subheader("Medal Type Distribution")
        medal_counts = filtered_df['medal_type'].value_counts()
        fig = px.pie(
            values=medal_counts.values,
            names=medal_counts.index,
            title=f'Distribution of Medal Types {f"({season})" if season != "All" else ""}',
            color_discrete_map={'GOLD': '#FFD700', 'SILVER': '#C0C0C0', 'BRONZE': '#CD7F32'}
        )
        fig.update_traces(
            textposition='inside',
            textinfo='label+value+percent'
        )
        st.plotly_chart(fig)
    
    # Top Athletes
    st.subheader("Top Athletes by Medal Count")
    athlete_medals = filtered_df.groupby('athlete_full_name')['medal_type'].value_counts().unstack(fill_value=0)
    athlete_medals['Total'] = athlete_medals.sum(axis=1)
    athlete_medals = athlete_medals.sort_values('Total', ascending=True).tail(15)
    
    fig = go.Figure()
    for medal_type in ['GOLD', 'SILVER', 'BRONZE']:
        if medal_type in athlete_medals.columns:
            fig.add_trace(go.Bar(
                y=athlete_medals.index,
                x=athlete_medals[medal_type],
                name=medal_type,
                orientation='h',
                text=athlete_medals[medal_type],
                textposition='auto',
                marker_color={'GOLD': '#FFD700', 'SILVER': '#C0C0C0', 'BRONZE': '#CD7F32'}[medal_type]
            ))
    
    annotations = []
    for i, row in enumerate(athlete_medals.itertuples()):
        annotations.append(dict(
            x=row.Total,
            y=row.Index,
            text=f'Total: {row.Total}',
            showarrow=False,
            xanchor='left',
            xshift=10
        ))
    
    fig.update_layout(
        barmode='stack',
        title=f'Top 15 Athletes by Medal Count {f"({season})" if season != "All" else ""}',
        xaxis_title='Number of Medals',
        yaxis_title='Athlete',
        height=600,
        showlegend=True,
        annotations=annotations
    )
    st.plotly_chart(fig)

def main():
    st.set_page_config(layout="wide")
    
    # Navigation
    pages = {
        "1. Input Dataset": load_dataset,
        "2. Preprocess Data": detailed_eda,
        "3. Analisis Data": perform_analysis,
        "4. Visualisasi Data": create_visualization
    }
    
    page = st.sidebar.radio("Navigation", list(pages.keys()))
    
    # Initialize session state for data persistence
    if 'data' not in st.session_state:
        st.session_state.data = None
    
    # Load data if not already loaded
    if page == "1. Input Dataset":
        st.session_state.data = load_dataset()
    
    # Process data if available
    if st.session_state.data:
        if page == "2. Preprocess Data":
            st.session_state.processed_data = detailed_eda(st.session_state.data)
        elif page == "3. Analisis Data":
            perform_analysis(st.session_state.processed_data if 'processed_data' in st.session_state else st.session_state.data)
        elif page == "4. Visualisasi Data":
            create_visualization(st.session_state.processed_data if 'processed_data' in st.session_state else st.session_state.data)
    else:
        if page != "1. Input Dataset":
            st.warning("Please upload datasets first.")

if __name__ == "__main__":
    main()