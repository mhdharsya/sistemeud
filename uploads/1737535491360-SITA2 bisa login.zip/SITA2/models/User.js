const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');
const bcrypt = require('bcryptjs');

const User = sequelize.define('User', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  username: {
    type: DataTypes.STRING(50),
    allowNull: false,
    unique: true,
    validate: {
      notEmpty: true
    }
  },
  password: {
    type: DataTypes.STRING(255),
    allowNull: false,
    validate: {
      notEmpty: true
    }
  },
  role: {
    type: DataTypes.ENUM('dosen', 'mahasiswa'),
    allowNull: false
  },
  name: {
    type: DataTypes.STRING(100),
    allowNull: false,
    validate: {
      notEmpty: true
    }
  },
  nim: {
    type: DataTypes.STRING(20),
    unique: true,
    allowNull: true // null for lecturers
  },
  profile_photo: {
    type: DataTypes.STRING(255),
    allowNull: true
  }
}, {
  tableName: 'users',
  timestamps: true,
  underscored: true,
  // hooks: {
  //   beforeCreate: async (user) => {
  //     if (user.password) {
  //       user.password = await bcrypt.hash(user.password, 10);
  //     }
  //   },
  //   beforeUpdate: async (user) => {
  //     if (user.changed('password')) {
  //       user.password = await bcrypt.hash(user.password, 10);
  //     }
  //   }
  // }
  hooks: {
    beforeCreate: async (user) => {
      if (user.password) {
        const hash = await bcrypt.hash(user.password, 10);
        console.log('Password asli:', user.password);
        console.log('Hash yang dibuat:', hash);
        user.password = hash;
      }
    }
  }
});

// Instance method to check password
// User.prototype.checkPassword = async function(password) {
//   return bcrypt.compare(password, this.password);
// };

User.prototype.checkPassword = async function(password) {
  try {
    console.log('=== Debug Login ===');
    console.log('Username:', this.username);
    console.log('Role:', this.role);
    console.log('Password input:', password);
    console.log('Password hash di DB:', this.password);
    
    const isValid = await bcrypt.compare(password, this.password);
    console.log('Hasil verifikasi:', isValid);
    console.log('==================');
    return isValid;
  } catch (error) {
    console.error('Error:', error);
    return false;
  }
};
// User.prototype.checkPassword = async function(password) {
//   console.log('Password yang diinput:', password);
//   console.log('Password hash yang tersimpan:', this.password);
//   const isValid = await bcrypt.compare(password, this.password);
//   console.log('Hasil perbandingan:', isValid);
//   return isValid;
// };

// async function checkPassword(user, password) {
//   return bcrypt.compare(password, user.password);
// }

module.exports = User;