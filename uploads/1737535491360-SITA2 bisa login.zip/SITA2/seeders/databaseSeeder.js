const bcrypt = require('bcryptjs');
const { sequelize } = require('../config/database');
const { User, Thesis, Seminar, Defense, Logbook } = require('../models');

const seedDatabase = async () => {
  try {
    // Sync database
    await sequelize.sync({ force: true }); // This will drop all tables and recreate them

    // // Create dosen
    // const dosen = await User.create({
    //   username: 'dosen1',
    //   password: await bcrypt.hash('password123', 10),
    //   role: 'dosen',
    //   name: 'Dr. Budi Santoso',
    //   profile_photo: null
    // });

    // // Create mahasiswa
    // const mahasiswa1 = await User.create({
    //   username: 'mahasiswa1',
    //   password: await bcrypt.hash('password123', 10),
    //   role: 'mahasiswa',
    //   name: 'John Doe',
    //   nim: '12345678',
    //   profile_photo: null
    // });

    // const mahasiswa2 = await User.create({
    //   username: 'mahasiswa2',
    //   password: await bcrypt.hash('password123', 10),
    //   role: 'mahasiswa',
    //   name: 'Jane Smith',
    //   nim: '87654321',
    //   profile_photo: null
    // });

    // const dosen2 = await User.create({
    //   username: 'dosen2',
    //   password: await bcrypt.hash('semogabisa', 10),
    //   role: 'dosen',
    //   name: 'gipa',
    //   profile_photo: null
    // });

    const dosen = await User.create({
      username: 'dosen1',
      password: 'password123',  // pastikan ini sama persis
      role: 'dosen',
      name: 'Dr. Budi Santoso',
      profile_photo: null
    });

    const mahasiswa1 = await User.create({
      username: 'mahasiswa1',
        password: 'password123',
        role: 'mahasiswa',
        name: 'John Doe',
        nim: '12345678',
        profile_photo: null
    });

    const mahasiswa2 = await User.create({
      username: 'mahasiswa2',
      password: 'password123',
      role: 'mahasiswa',
      name: 'Jane Smith',
      nim: '87654321',
      profile_photo: null
    });

    // Create thesis submissions
    const thesis1 = await Thesis.create({
      student_id: mahasiswa1.id,
      title: 'Implementasi Machine Learning dalam Prediksi Cuaca',
      research_object: 'Data cuaca historis Indonesia',
      methodology: 'Metode penelitian kuantitatif dengan pendekatan machine learning',
      attachment_file: 'thesis/sample_thesis_1.pdf',
      status: 'pending'
    });

    const thesis2 = await Thesis.create({
      student_id: mahasiswa2.id,
      title: 'Analisis Keamanan Jaringan IoT',
      research_object: 'Perangkat IoT rumah pintar',
      methodology: 'Penelitian eksperimental dengan pendekatan blackbox testing',
      attachment_file: 'thesis/sample_thesis_2.pdf',
      status: 'approved'
    });

    // Create seminar submission
    const seminar = await Seminar.create({
      thesis_id: thesis2.id,
      student_id: mahasiswa2.id,
      seminar_date: new Date('2024-01-15'),
      status: 'pending'
    });

    // Create defense submission
    const defense = await Defense.create({
      seminar_id: seminar.id,
      student_id: mahasiswa2.id,
      defense_date: null,
      status: 'pending'
    });

    // Create logbook entries
    await Logbook.create({
      student_id: mahasiswa2.id,
      date: new Date('2024-01-01'),
      activity: 'Diskusi metodologi penelitian dengan dosen pembimbing',
      is_locked: false
    });

    await Logbook.create({
      student_id: mahasiswa2.id,
      date: new Date('2024-01-08'),
      activity: 'Pengumpulan data dan analisis awal',
      is_locked: false
    });

    console.log('Database seeded successfully!');
    console.log('\nTest Account Credentials:');
    console.log('Dosen:');
    console.log('Username: dosen1');
    console.log('Password: password123');
    console.log('\nMahasiswa:');
    console.log('Username: mahasiswa1');
    console.log('Password: password123');

  } catch (error) {
    console.error('Error seeding database:', error);
  }
};

// Run seeder
seedDatabase();