<?php
/**
 *
 * @project     CWC2
 * @revision    $Id: chameleon.php,v 1.93 2007/09/06 14:26:33 jlacroix Exp $
 * @purpose     Main Chameleon class definition
 * @author      DM Solutions Group (sfournier@dmsolutions.ca)
 * @copyright
 * <b>Copyright (c) 2002-2005 DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/// Chameleon core class.
/**
 * Chameleon application base class.
 *
 * This class defines the base behavior of Chameleon. Every Chameleon
 * application should be a class that derives from the Chameleon class.
 *
 * The class manages all form variables and makes sure to pass them to
 * all widgets for their own use.
 *
 * By default, the class will try to load a template using file system
 * througt CWCLoadTemplate method. So, if for instance you need to load
 * a template from something else than the file system (for instance, a
 * database), you'll have to overwrite CWCLoadTemplate method in your
 * application class definition.
 *
 * A map file is needed by Chameleon to work (should change some day). The
 * map file have to be specified as the second parameter of method CWCInitialize.
 * For now, map file should be on local file system. If you want to et your
 * map file somewhere else (database for instance), you'll have to take care
 * of it before calling CWCInitialize so it can be loaded from your local file
 * system.
 *
 * All session variables are set by CWCInitializeSession method. If for any reason
 * you need to sets some custom session variables, you'll need to overwrite this
 * methos in your application class definition. Please take note that session
 * variables seted in that method is only done once (first page load).
 *
 * The Chameleon core class can be configured to provide basic or custom user
 * authentication.  Basic (or built-in) authentication is provided by the core
 * through a member variable of the Chameleon class, moAuthenticator.  This
 * variable is null by default and this indicates no authentication is performed.
 * To have Chameleon perform default (built in) authentication, this member
 * variable is assigned an object which implements two methods:
 *
 * isAuthenticated(): returns true or false if the current connection is
 * authenticated
 *
 * authenticate($user,$password): authenticates a user
 *
 * A basic authentication class is provided in Authenticator.php.  This
 * takes a pointer to an abstract database class constructed from one of
 * the adb-supported databases.
 *
 * Custom authentication can be provided by implementing a new class which
 * provides the same API as Authenticator or by overriding the CWCAuthenticate
 * method in the Chameleon class.
 *
 * The Authenticator is designed to be flexible and can be connected to any
 * backend adb database, and supports user-defined tables and fields.  It
 * runs an SQL query against the database for the current user and md5()
 * of the password looking for a match.
 *
 * If this is not sufficient, you can override the CWCAuthenticate() method
 * in your Chameleon application class.  This method is responsible for
 * providing authentication and can be set up to do anything you wish.
 * CWCAuthenticate is called as the first step of CWCExecute.
 */
class Chameleon
{
    /// Form variables manager object
    /**
     * This is an object that hold all form variable passed via the GET or
     * POST method. See HttpFormVars class.
     */
    var $moHttpFormVars;
    /// PHP form variables ARRAY
    var $HTTP_FORM_VARS1;

    /// Configuration manager object
    var $moContext;

    /// Current language used
    var $mszCurrentLanguage;
    /// List of templates for every languages.
    var $maszTemplates = array();
    /// List for resource files for every language
    var $maszResourceFiles;

    /// Current template name
    var $mszTemplateName = "";
    /// Current template content
    var $mszTemplate = "";

    /// Current mapfile
    var $mszMapFile;

    /// Wrapper map session object (Can be ReadOnly or Writable)
    /**
     * This hold the Map object from PHP/Mapscript in an attribute.
     * See map_session.php for more details.
     */
    var $moMapSession = "";

    /// Current State for MapSession object
    var $mszCurrentState = "";

    // Global Multiligual object resource manager
    var $moGlobalMLT;

    /// Chameleon UI manager
    var $moUI;

    /// Chameleon error manager
    var $moErrorManager;
    /// Chameleon Log object
    var $moLogFile;

    /// Absolute path to chameleon
    var $mszCoreWebPath;

    /// Template name to display if a non fatal error occure.
    var $mszInvalidSessionTmpl = "";

    /// Boolean value to know if the session loaded correctly.
    var $mbSessionOK = true;

    /// an array of paths to search when locating files
    var $maszSkinSearchPath = array( 'skins/default' );

    /// globally configured form index for widgets that don't have a formindex set in their tags ...
    var $mnFormIndex = 0;

    /// Object that hold the Authenticator (See CWCAuthenticator())
    var $moAuthenticator = null;

    /// Controls which widgets will be available at runtime.
    /**
     * this controls which widgets will be available at runtime.  It is
     * controlled by the maturity_level entry in chameleon.xml and/or
     * the application-configured maturity_level.  Default is
     * RELEASECANDIDATE which means the code is considered stable and
     * tested, but the documentation may not be fully complete.
     */
    var $mnMinimumMaturityLevel = MATURITY_BETA;

    /**
     * Chameleon class constructor.
     *
     * Initialize Form variables, make sure the session (PHP)
     * was created and set current language (if any).
     */
    function Chameleon()
    {
        // Get form variables from POST of GET
        if (sizeof($_POST) > 0)
            $this->HTTP_FORM_VARS1 =& $_POST;
        else if (sizeof($_GET) > 0)
            $this->HTTP_FORM_VARS1 =& $_GET;
        else
            $this->HTTP_FORM_VARS1 = array("");

        // Check session
        if (isset($GLOBALS['bSessionOK']) && !$GLOBALS['bSessionOK'])
          $this->mbSessionOK = false;

        // Load form variables into a class
        $this->moHttpFormVars = new HttpFormVars($this->HTTP_FORM_VARS1);

        // Retrieve laststate for MapSession object (if any)
        if (isset($_SESSION['gszCurrentState']))
        {
            $this->mszCurrentState = $_SESSION['gszCurrentState'];
            //echo "state in session $this->mszCurrentState<BR>";
        }
        else
        if ($this->moHttpFormVars->isVarSet('currentState', false) &&
            $this->moHttpFormVars->getVar('currentState', false) != "")
        {
            $this->mszCurrentState = $this->moHttpFormVars->getVar('currentState', false);
        }

        // Retrieve language (if any)
        if( $this->isVarSet("LANGUAGE"))
        {
            $this->mszCurrentLanguage = $this->getVar("LANGUAGE");
        }
        elseif(isset($_SESSION['gszCurrentLanguage']))
        {
            $this->mszCurrentLanguage = $_SESSION['gszCurrentLanguage'];
        }
    }

    /**
     * CWCAddRegionalTemplate( $szLang, $szTemplateName )
     *
     * This function add a new template (to the list) for a
     * specific language.
     *
     * @param $szLang string Template language
     * @param $szTemplateName string Template name to set for the language
     * @param $szResourceFile string optional path to a file containing
     * language resources to load.
     */
    function CWCAddRegionalTemplate( $szLang, $szTemplateName, $szResourceFile=null )
    {
        $this->maszTemplates[$szLang] = $szTemplateName;
        if ($szResourceFile)
            $this->maszResourceFiles[$szLang] = $szResourceFile;
    }

    /**
     * CWCExecute($aszWidgetsDir=array())
     *
     * This functin execute chameleon engine.
     * In order, this function check if authentication needs to be done.
     * Load the template and extract all the widgets with the UIManager().
     * Process all widgets.
     * Output the result.
     *
     * @param $aszWidgetsDir array Array of path to search for more widgets.
     *
     * @return boolean if all steps successfully ran,
     *         or false if an error occurred.
     */
    function CWCExecute($aszWidgetsDir=array())
    {
        $this->CWCAuthenticate();

        // set a global reference
        $GLOBALS['oChameleonApp'] =& $this;

        include("UIManager.php");

        $nCount = 0;

        $bRet = false;
        /*
          Since some widget can redirect to different (events)
          template, we loop to the infinite or until
          the template was corretly loaded and displayed.
        */
        while($bRet == false)
        {
            // First thing, check if session is invalid and if a tmeplate is
            // specified
            if (!$this->mbSessionOK)
            {
                // If session failed and there's a Invalid Session template
                // specified, display it.
                if ($this->mszInvalidSessionTmpl == "")
                {
                // if no Invalid Session template specified, check template
                // name (if SessoinExpired in it) display it if so, or display
                // a messsage and exit.
                    $this->CWCLoadTemplate($this->mszTemplateName);
                    if (strpos($this->mszTemplate, "SessionExpired") === false)
                    {
                        echo "Your session has expired from our server, please come back to the entry page of the application to initiate a new session";
                        exit;
                    }

                }
                else
                    $this->CWCLoadTemplate($this->mszInvalidSessionTmpl);
            }
            else
                $this->CWCLoadTemplate($this->mszTemplateName);

            //trap invalid templates here
            if ($this->mszTemplate === false)
            {
                $_SESSION['gErrorManager']->setError(ERR_CRITICAL, "CRITICAL: Invalid template specified, execution cannot continue" );
                return false;
            }

            // Create UI Manager object
            $this->moUI = new UIManager($this->mszTemplate,
                                        $this->moMapSession,
                                        $aszWidgetsDir);

            // Call process URL. This will process URL for
            // all widgets in template.
            if ($this->CWCProcessURL($this->HTTP_FORM_VARS1))
            {
                $nCount = 0;

                // If no error, prepare display template content.
                $this->CWCPrepareDrawPublish();

                // Save MapSession state for next page and close sessoin
                $_SESSION['gszCurrentState']=$this->moMapSession->saveState();
                //echo "saved state to ".$_SESSION['gszCurrentState'];
                session_write_close();

                // And output it to client.
                $this->CWCDrawPublish();

                $bRet = true;
            }
            else
            {
                // An error occure in ProcessURL
                //
                // Check if the last template is the same as the previous one.
                // If so exit. If not, increment an internal couter to prevent
                // infinit loop and go back at the begining of the main loop.
                if ($this->mszTemplateName == $this->mszLastTemplateName)
                    $bRet = true;
                else
                    $nCount ++;

                // This should never happen.
                if ($nCount > 10)
                {
                    echo "Infinit loop. Exiting.";

                    echo "<!-- ".$this->mszTemplateName."\n\n";
                    print_r($this->HTTP_FORM_VARS1);
                    echo " -->";

                    exit;
                }
            }
        }

        return $bRet;
    }

    /**
     * Process the form variables submitted by the user.  This function
     * passes the form variables on to the UI manager, which then passes
     * them to each widget.
     *
     * This function can be overloaded in an application but the application
     * should call $this->moUI->ProcessURL($oHTTPFormVars); in the overloaded
     * function.
     *
     * @param $oHTTPFormVars HttpFormVars reference to an HttpFormVars instance
     * @return boolean true if all widgets successfully processed the form vars,
     *         or false if an error occurred.
     */
    function CWCProcessURL(&$oHTTPFormVars)
    {
        return $this->moUI->ProcessURL($oHTTPFormVars);
    }

    /**
     * Prepare the application for drawing.  This calls the UIManager to
     * gather javascript and form variables from every widget in the page.
     * in preparation for actually rendering the page.  The various pieces
     * of the application are processed back into the template as part of
     * this function so that the end result is in the UIManager's mszTemplate
     * member variable.
     *
     * This function can be overloaded in an application but the application
     * should call parent::CWCPrepareDrawPublish() in the overloaded function.
     */
    function CWCPrepareDrawPublish()
    {
        $this->moUI->PrepareDrawPublish();
    }

    /**
     * Draw the application.  This function actually sends the template to the client's
     * browser.
     *
     * This function can be overloaded in an application but the application
     * should call parent::CWCDrawPublish() to get the page contents
     */
    function CWCDrawPublish()
    {
        echo $this->moUI->DrawPublish();
    }

    /**
     * CWCInitialize($szTemplateName, $szMapFile="")
     *
     * Chameleon main initialization method. This set the template
     * and the mapfile to use. Also initialize all helper object.
     *
     * @param $szTemplateName string Template name to use
     * @param $szMapFile string Mapfile to load.
     */
    function CWCInitialize($szTemplateName, $szMapFile="")
    {
        // Make sure the path is absolute.
        //echo $_SESSION['gszAppPath']."<BR>";
        if ($szMapFile != "")
            $this->mszMapFile  = $this->resolvePath2($szMapFile, $_SESSION['gszAppPath']);
        else
            $this->mszMapFile = "";

        // define a new AppContext object
        $this->moContext = new AppContext( CHAMELEON_CONFIG_PATH."chameleon.xml" );

        // Get web path to php_utils.
        if(!defined("WEBCOMMON"))
            define( "WEBCOMMON", $this->moContext->getContextValue("web_server_path")."/common/" );



        // Get invalid session template
        $this->mszInvalidSessionTmpl =
          $this->moContext->getContextValue("invalid_session_template", "");

        // Get default language from configuration file
        if ($this->mszCurrentLanguage == "")
            $this->mszCurrentLanguage = $this->moContext->getContextValue("default_language","");

        // Set current language in session (should it be in CWCInitializeSession ?)
        $_SESSION['gszCurrentLanguage'] = $this->mszCurrentLanguage;

        // Set template name and map file
        $this->CWCSetTemplate($szTemplateName);

        // Init session variables if not already set
        if (!$this->moHttpFormVars->isVarSet('SID') ||
            !$this->mbSessionOK ||
            (isset($_SESSION['gszMapName']) &&
             realpath($_SESSION['gszMapName']) != realpath($szMapFile)) &&
             $szMapFile != "")
        {
            //echo "resetting session<BR>";
            $this->mszCurrentState = "";
            $this->CWCInitializeSession();

            if (strcmp(strtolower($this->moContext->getContextValue("count_hits")), "true") == 0)
            {
               @include_once( COMMON."hitcounter/stats.php" );
               if (function_exists( 'doStats' ))
               {
                   doStats();  //call function in stats.php (common/hitcount) to add an entry to the DBF file
               }
               else
               {
                 $_SESSION['gErrorManager']->setError( ERR_WARNING, 'ERROR: stats are turned on in the configuration file but the hitcounter is missing from the common directory.' );
               }
            }
        }

      /**
         _____________________________________________________________________
        |
        | Initialize language handling
        |_____________________________________________________________________

        **/

        // create unique filename based on template
        $szUniqueFileName = str_replace( '\\', '/',
                                                $_SESSION[ 'gszTmpImgPath' ] );
        $szUniqueFileName .= substr( $szUniqueFileName, -1 ) != '/'?'/':'';
        $szUniqueFileName .= md5_file( $this->mszTemplateName ).'_mlt.inc.php';

        // get nochache flag
        if ( !defined( 'MLT_NOCACHE' ) )
        {
            define( 'MLT_NOCACHE',
                strtolower( $this->moContext->getContextValue( 'cache_mlt' ) )
                == 'false' );
        }

        // store the NOCACHE and cache file var(s) in the session
        $_SESSION['MLT_NOCACHE'] = MLT_NOCACHE;
        $_SESSION['MLT_CACHE_FILE'] = $szUniqueFileName;

        // check to see if the MLT default class is to be used
        if ( !defined( 'MLT_DEFAULT_ONLY' ) )
        {

            // initialize the global object
            if( count($_SESSION['aszLang']) )
            {
                $this->moGlobalMLT = new MLTPHPInclude( $szUniqueFileName,
                                                        $_SESSION['aszLang'],
                                                        MLT_NOCACHE );
            }
            else if ( isset( $this->mszCurrentLanguage) )
            {

                $this->moGlobalMLT = new MLTPHPInclude( $szUniqueFileName,
                                                     $this->mszCurrentLanguage,
                                                     MLT_NOCACHE );
            }



            // set the current language
            if ( isset( $this->mszCurrentLanguage ) )
            {
                $this->moGlobalMLT->setLanguage($this->mszCurrentLanguage);
            }

            // load the core resources
            $this->moGlobalMLT->loadResource( 'core',
                                    str_replace("\\","/",dirname(__FILE__) ) );

            // load the common resources
            $this->moGlobalMLT->loadResource( 'common',
                                    str_replace("\\","/",dirname(__FILE__) ) );
        }
        else
        {
            // load default MLT class
            $this->moGlobalMLT = new MLTPHPIncludeDefault();
        }



        $this->moErrorManager = $_SESSION['gErrorManager'];

        $szMaturityLevel = "MATURITY_".strtoupper($this->moContext->getContextValue( "maturity_level", $this->mnMinimumMaturityLevel ));
        if (defined($szMaturityLevel))
        {
            $this->mnMinimumMaturityLevel = eval( "return ".$szMaturityLevel.";" );
        }
        else
        {
            $this->moErrorManager->setError(ERR_WARNING,
                 $this->moGlobalMLT->get( 'core', '5', 'WARNING: Invalid maturity level in chameleon.xml.  Contact your administrator.' ) );
        }

        if (!extension_loaded("MapScript"))
            dl($_SESSION['gszMapscriptModule']);

    // Load mapfile
        $this->CWCInitializeMap();
    }

    /**
     * CWCSetTemplate($szTemplateName)
     *
     * Set current template name (don't loading it).
     *
     * @param $szTemplateName string Current template name.
     */
    function CWCSetTemplate($szTemplateName)
    {
        // Keep last template name just in case...
        $this->mszLastTemplateName = $this->mszTemplateName;

        // If a template list is provided, use it with current language.
        if (isset($this->maszTemplates[$this->mszCurrentLanguage]))
        {
            $this->mszTemplateName = $this->maszTemplates[$this->mszCurrentLanguage];
            if (isset($this->maszResourceFiles[$this->mszCurrentLanguage]))
            {
                if (!function_exists('loadResources'))
                {
                    include_once($this->maszResourceFiles[$this->mszCurrentLanguage]);
                }

                if (function_exists('loadResources'))
                {
                    loadResources($this);
                }
                else
                {
                    $this->moErrorManager->setError(ERR_WARNING,
                    "Language resource file ".$this->maszResourceFiles[$this->mszCurrentLanguage]." does not define mandatory function 'loadResources(\$oApp)'.  Language resources not loaded!");
                }
            }
        }
        else
        {
            $this->mszTemplateName = $szTemplateName;
        }
    }

    /**
     * CWCLoadTemplate($szTemplateName)
     *
     * Load the template content into mszTemplate
     *
     * @param $szTemplateName string Template name to load.
     *
     * @return boolean true if the template loaded correctly, false otherwise.
     */
    function CWCLoadTemplate($szTemplateName)
    {
        // PHP function from 4.3.0 and up. Much faster.
        if (function_exists('file_get_contents'))
        {
            $this->mszTemplate = @file_get_contents($szTemplateName);
            if ($this->mszTemplate === false)
            {
                return false;
            }
        }
        else
        {
            $aszFile = @file($szTemplateName);
            if (!is_array($aszFile))
            {
                return false;
            }
            $this->mszTemplate = implode("\n", $aszFile );
        }
        return true;
    }

    /**
     * required by TemplateParser interface, return a template to be parsed
     * @param szTemplateName string the template to load
     * @return string a string containing the contents of the template or false
     */
    function GetTemplate( $szTemplateName )
    {
        $szTemplate = '';
        if (function_exists('file_get_contents'))
        {
            $szTemplate =  @file_get_contents($szTemplateName);
            if ($szTemplate === false)
            {
                $_SESSION['gErrorManager']->setError(ERR_FILE_IO,
                   "ERROR: The requested file (".$szTemplateName.") could not be found.");
            }
        }
        else
        {
            $aszTemplate = @file($szTemplateName);
            if ($szTemplate === false)
            {
                $_SESSION['gErrorManager']->setError(ERR_FILE_IO,
                   "ERROR: The requested file (".$szTemplateName.") could not be found.");
            }
            else
            {
                $szTemplate = implode("\n", $aszTemplate);
            }
        }
        return $szTemplate;
    }

    /**
     * CWCInitializeMap()
     *
     * Load mapfile. This method load the mapfile using
     * mapsession object. By default, a "ReadOnly" map session
     * object is used to load the map. If you need a writeable
     * map session object, make sure to create is before calling
     * this method and put a reference in to MapSession member.
     */
    function CWCInitializeMap()
    {
        //session map init
        // create a new map session object if not created
        if (!$this->moMapSession)
            $this->moMapSession = new MapSession_R;

        // set the global log file and error manager
        $this->moMapSession->setLogFile( $this->moLogFile );
        $this->moMapSession->setErrorManager( $this->moErrorManager );

        /* ===========================================================
         * Re-instate the previous map state
         * =========================================================== */
        if ($this->mszCurrentState == "" )
        {
            // load mapfile if necessary
            if ($this->mszMapFile != "")
            {
                // Init error stack
                ms_ResetErrorList();

                $bStatus = MS_FAILURE;
                if (strtoupper(substr($this->mszMapFile, -3)) == "MAP")
                {
                    $bStatus = $this->moMapSession->readMapFile($this->mszMapFile,
                                                                dirname($this->mszMapFile));

                    if ($bStatus)
                        $bStatus = MS_SUCCESS;
                    else
                        $bStatus = MS_FAILURE;

                }

                if ($bStatus == MS_FAILURE)
                {
                    if (isset($this->moErrorManager))
                        $this->moErrorManager->setError(ERR_WARNING,
                        trim($this->moGlobalMLT->get( 'core', '4',
                        'ERROR: Invalid map file.' ) ) );
                    else
                        echo "ERROR: Invalid map file file (".$this->mszMapFile.").";

                    // Get mapserver error stack and display them as HTML comments.
                    $oError = ms_GetErrorObj();
                    while($oError && $oError->code > 0)
                    {
                        if (isset($this->moErrorManager))
                        {
                            $szMsg = getMapServerErrorMessage( $oError );
                            $this->moErrorManager->setError(ERR_WARNING, $szMsg);
                        }
                        echo "<!-- ".$szMsg." -->";

                        $oError = $oError->next();
                    }
                }
                else
                {
                    // Reset form Vars when new context is loaded
                    $this->resetFormVars();
                    if (isset($_SESSION['gszTmpImgPath']) && $_SESSION['gszTmpImgPath'] != '')
                    {
                        $this->moMapSession->oMap->web->set( "imagepath", $_SESSION['gszTmpImgPath'] );
                    }
                    if (isset($_SESSION['gszTmpWebPath']) && $_SESSION['gszTmpWebPath'] != '')
                    {
                        $this->moMapSession->oMap->web->set( "imageurl", $_SESSION['gszTmpWebPath'] );
                    }
                }
            }
            else
            {
                //echo "create map file<BR>";
                $this->mszMapFile = getSessionSavePath()."default.map";
                $oMap = ms_newMapObj( "" );
                $oMap->set( "width", 1 );
                $oMap->set( "height", 1 );
                $oMap->setExtent( -1, -1, 1, 1 );
                $oMap->save( $this->mszMapFile );

                $this->moMapSession->readMapFile($this->mszMapFile,
                                                                dirname($this->mszMapFile));
                $_SESSION['gszMapName'] = $this->mszMapFile;
            }
        }
        else
        {
            if ($this->mszMapFile == "")
                $this->mszMapFile = getSessionSavePath()."default.map";

            // Load previous state.
            //echo "restoring state: ".$this->mszCurrentState." ".$this->mszMapFile."<BR>";
            $this->moMapSession->restoreState($this->mszCurrentState,
                                              $this->mszMapFile,
                                              dirname($this->mszMapFile));
        }

        // Set the ImgType from the MapFile value if AUTO
        if(strtoupper($_SESSION["gszImgType"]) == "AUTO")
        {
            $_SESSION["gszImgType"] =
                strtoupper($this->moMapSession->oMap->imagetype);
        }
    }

    /**
     * CWCInitializeSession()
     *
     * Initialize all session variables. This method
     * is only called once when page first loading.
     */
    function CWCInitializeSession()
    {
        $_SESSION['gszCoreWebPath'] =
                       $this->moContext->getContextValue("web_server_path");
        $aszParts = parse_url( $_SESSION['gszCoreWebPath']);

        if (!isset($aszParts['scheme']))
        {
            if (isset($_SERVER["HTTPS"]) && strcasecmp($_SERVER['HTTPS'], "on") == 0)
                $aszParts['scheme'] = "https";
            else
                $aszParts['scheme'] = "http";
        }
        // bartvde, MT bug 1518
        if (isset($_SERVER['HTTP_X_FORWARDED_HOST']))
        {
            if (strpos($_SERVER['HTTP_X_FORWARDED_HOST'], ',') !== false)
            {
              $aszParts['host'] = substr($_SERVER['HTTP_X_FORWARDED_HOST'], 0,
                strpos($_SERVER['HTTP_X_FORWARDED_HOST'], ','));
            }
            else
            {
              $aszParts['host'] = $_SERVER['HTTP_X_FORWARDED_HOST'];
            }
        }
        if (!isset($aszParts['host']))
        {
            $aszParts['host'] = $_SERVER["HTTP_HOST"];
        }
        if (!isset($aszParts['port']))
        {
            $aszParts['port'] = "";
        }
        else
        {
            $aszParts['port'] = ":".$aszParts['port'];
        }
        if (!isset($aszParts['path']))
        {
            $aszParts['path'] = '/chameleon/';
        }
        $szPath = str_replace( '//', '/', $aszParts['host'].$aszParts['port']."/".
                                      $aszParts['path'].'/' );
        //paste it back together
        $_SESSION['gszCoreWebPath'] = $aszParts['scheme']."://".$szPath;

        $_SESSION['gszCorePath'] = dirname(__FILE__)."/";

        $_SESSION['gszTmpPath']    = getSessionSavePath();
        $_SESSION['gszTmpMapPath'] = getSessionSavePath();
        $_SESSION['gszDefaultLanguage'] = $this->mszCurrentLanguage;

        $_SESSION['gnMapSessionMode'] = ((method_exists($this->moMapSession, "MapSession_RW")) ? "1":"0");

        $_SESSION['gaszSkinSearchPath'] = $this->maszSkinSearchPath;

        //  tmp web path
        $gszTmpWebPath = str_replace("\\", "/",
                                     $this->moContext->getContextValue("tmp_web_path"));
        if (substr($gszTmpWebPath, -1) != "/")
            $gszTmpWebPath .= "/";
        $_SESSION["gszTmpWebPath"] = $gszTmpWebPath;

        //  tmp image path
        $gszTmpImgPath = str_replace("\\", "/",
                                     $this->moContext->getContextValue("tmp_img_path"));
        if (substr($gszTmpImgPath, -1) != "/")
            $gszTmpImgPath .= "/";
        $_SESSION["gszTmpImgPath"] = $gszTmpImgPath;

        if (getenv("RUN_FROM_CD"))
        {
            if ($szTmpDir = getenv("TEMP"))
            {
                $_SESSION["gszTmpImgPath"] = $szTmpDir;
            }
        }
        //button cache path
        $gszButtonCachePath = $this->moContext->getContextValue("button_cache_path");
        if (substr($gszButtonCachePath, -1) != "/")
            $gszButtonCachePath .= "/";
        $_SESSION["gszButtonCachePath"] = $gszButtonCachePath;

        if (getenv("RUN_FROM_CD"))
        {
            if ($szTmpDir = getenv("TEMP"))
            {
                $_SESSION["gszButtonCachePath"]= $szTmpDir;
            }
        }
        //button cache url
        $gszButtonCacheWebPath = $this->moContext->getContextValue("button_cache_web_path");
        if (substr($gszButtonCacheWebPath, -1) != "/")
            $gszButtonCacheWebPath .= "/";
        $_SESSION["gszButtonCacheWebPath"] = $gszButtonCacheWebPath;

        if (getenv("RUN_FROM_CD"))
        {
            $_SESSION["gszButtonCacheWebPath"] = "/ms_tmp";
        }
        // Get image output type
        $_SESSION["gszImgType"] = $this->moContext->getContextValue("image_type");


        // set a default map title font.
        $_SESSION["gszMapTitleFontName"] = "Vera";

        // set a default legend font.
        $_SESSION["gszLegendFontName"] = "Vera";

        // path for the log file
        //$gszLogPath = str_replace("\\", "/", realpath($this->moContext->getContextValue("log_path")));
        //if (substr($gszLogPath, -1) != "/")
        //  $gszLogPath .= "/";

        // get the log level
        //$gszLogLevel = $this->moContext->getContextValue("log_level");

        $gnTimeout = intval($this->moContext->getContextValue( "execution_timeout" ));
        if ( $gnTimeout < 30 )
          $gnTimeout = 30;

        @set_time_limit( $gnTimeout );

        // create new logfile object (customize parameters)
        //$aszLog = explode(".", basename($_SERVER["PHP_SELF"]));
        //$gLogFile = new LogFile( $gszLogPath.$aszLog[0]."_cwc2.log", LOG_TO_FILE, true );

        // determine the max log level ( set in mapbrowser.xml )
        /*
        switch( $gszLogLevel )
          {
            case "LOG_ALL";
            $gnLogLevel = LOG_ALL;
            break;
          case "LOG_VERBOSE":
            $gnLogLevel = LOG_VERBOSE;
            break;
          case "LOG_QUIET":
            $gnLogLevel = LOG_QUIET;
            break;
          default:
            $gnLogLevel = LOG_OFF;
          } // switch
        */
        // set the max log level
        //$gLogFile->setMaxLogLevel( $gnLogLevel );

        // add log file parameters to the session for use elsewhere
        //$_SESSION["gnLogLevel"]= $gnLogLevel;
        //$_SESSION["gszLogPath"]= $gszLogPath;

        if (!isset($_SESSION["gErrorManager"] ) )
        {
            // create new error manager object
            $_SESSION["gErrorManager"]= new ErrorManager();
        }

        // create a logger object
        $oLog = new Logger( "General" );

        // set the global log file and error manager
        //$oLog->setLogFile( $gLogFile );
        $oLog->setErrorManager( $_SESSION["gErrorManager"] );

        $_SESSION['gszMapscriptModule'] =
                  $this->moContext->getContextValue("mapscript_module");

        $_SESSION['gszWMSParseFile'] = $this->moContext->getContextValue( "wms_parse_file" );

        $_SESSION['gszCurrentState'] = ((!isset($_SESSION['gszCurrentState'])) ? "" : $_SESSION['gszCurrentState']);
        $_SESSION['gszTmpWebPath'] = $gszTmpWebPath;
        $_SESSION['gszMapName'] = $this->mszMapFile;
        $_SESSION['gszMapPath'] = dirname($this->mszMapFile);
        $_SESSION['gnTimeout'] = $gnTimeout;
        $_SESSION['gszCurrentLanguage'] = $this->mszCurrentLanguage;

        // build list of languages to load
        $_SESSION['aszLang'] = array_keys( $this->maszTemplates );
    }


    /**
     * CWCAuthenticate()
     *
     * Check if the moAuthenticator object is set. If so, it wil check if the
     * isAuthenticated() function return true. If not, the login template
     * will be loaded.
     *
     * The moAuthenticator object must at least have three things:
     *
     * isAuthenticated(): returns true or false if the current connection is
     * authenticated
     *
     * authenticate($user,$password): authenticates a user
     *
     * mszLoginTemplate member that will hold the loging template name.
     *
     *
     * Otherwise this function must be overloaded. A default authentication
     * is available in Authenticator.php
     *
     * @return void
     */
    function CWCAuthenticate()
    {
        if ($this->moAuthenticator != null)
        {
            if (isset($_REQUEST['username']) && isset($_REQUEST['password']))
            {
                if ($this->moAuthenticator->authenticate($_REQUEST['username'], $_REQUEST['password'] ) == false)
                    $this->setVar('szLoginError', $this->moGlobalMLT->get( 'core', '6', 'Login Failed - Incorrect Username and/or Password'));
            }
            if (!$this->moAuthenticator->isAuthenticated())
            {
                $this->setVar('SID', session_id());
                $this->mszTemplateName = $this->moAuthenticator->mszLoginTemplate;
                $this->CWCLoadTemplate($this->mszTemplateName);

            }
        }
    }


    /**
     * This function reset the form variable relative to the map.
     * Not sure if that function is still needed.
     */
    function resetFormVars()
    {
        // Reset some form variables when loading a new context or map file
        if(isset($GLOBALS["HTTP_FORM_VARS1"]["MAP_EXTENTS_MINX"]))
        {
            unset($GLOBALS["HTTP_FORM_VARS1"]["MAP_EXTENTS_MINX"]);
            unset($GLOBALS["HTTP_FORM_VARS1"]["MAP_EXTENTS_MINY"]);
            unset($GLOBALS["HTTP_FORM_VARS1"]["MAP_EXTENTS_MAXX"]);
            unset($GLOBALS["HTTP_FORM_VARS1"]["MAP_EXTENTS_MAXY"]);
        }

        if(isset($GLOBALS["HTTP_FORM_VARS1"]["Extent_MAXX"]))
        {
            unset($GLOBALS["HTTP_FORM_VARS1"]["Extent_MAXX"]);
            unset($GLOBALS["HTTP_FORM_VARS1"]["Extent_MAXY"]);
            unset($GLOBALS["HTTP_FORM_VARS1"]["Extent_MINX"]);
            unset($GLOBALS["HTTP_FORM_VARS1"]["Extent_MINY"]);
        }

        if(isset($GLOBALS["HTTP_FORM_VARS1"]["CursorPos_X"]))
        {
            unset($GLOBALS["HTTP_FORM_VARS1"]["CursorPos_X"]);
            unset($GLOBALS["HTTP_FORM_VARS1"]["CursorPos_Y"]);
        }

        if(isset($GLOBALS["HTTP_FORM_VARS1"]["MAP_WIDTH"]))
        {
            unset($GLOBALS["HTTP_FORM_VARS1"]["MAP_WIDTH"]);
            unset($GLOBALS["HTTP_FORM_VARS1"]["MAP_HEIGHT"]);
        }

        if(isset($GLOBALS["HTTP_FORM_VARS1"]["NAV_INPUT_COORDINATES"]))
            unset($GLOBALS["HTTP_FORM_VARS1"]["NAV_INPUT_COORDINATES"]);

        if(isset($GLOBALS["HTTP_FORM_VARS1"]["NAV_CMD"]))
            unset($GLOBALS["HTTP_FORM_VARS1"]["NAV_CMD"]);

        if(isset($GLOBALS["HTTP_FORM_VARS1"]["SCALE"]))
            unset($GLOBALS["HTTP_FORM_VARS1"]["SCALE"]);
    }

    /**
     * abstract moHttpFormVars via accessor function to check if a URL
     * variable was set in the page load
     * @param szVar string the variable name to check
     * @return boolean flag indicating if var was set
     */
    function isVarSet( $szVar )
    {
        return $this->moHttpFormVars->isVarSet($szVar);
    }

    /**
     * return the value of a URL variable
     * @param szVar string the variable name to get
     * @return string containing the value or false if key not found
     */
    function getVar( $szVar )
    {
        return $this->moHttpFormVars->getVar( $szVar );
    }

    /**
     * set the value of a URL variable, overwriting existing value if set
     * @param szVar string the var to set
     * @param szValue string the value to set
     * @return string containing the value or false if key not found
     */
    function setVar( $szVar, $szValue )
    {
        return $this->moHttpFormVars->setVar( $szVar, $szValue );
    }

    /**
     * set the index of the form that Chameleon should consider the
     * 'active' form.  This affects core functionality (language) and
     * any widgets that don't have a formindex attribute explicitly set.
     * @param nIndex integer the index of the form to use, starts at 0 for
     * the first form in the page.
     *
     * @return void
     */
    function setFormIndex( $nIndex )
    {
        $this->mnFormIndex = $nIndex;
    }

    /**
     * &getWidgetByName($szName)
     *
     * Return a reference to a widget object
     * based on it's name. If more that one widget (with
     * the same name exist in template, return the first
     * one.
     *
     * @param $szName string Widget name to return
     * @return object The refenrence to the widget object.
     */

    function &getWidgetByName($szName)
    {
        $nWidgets = count($this->moUI->maoWidgets);

        foreach(array_keys($this->moUI->maoWidgets) as $szKey)
        {
            $oWidget =& $this->moUI->maoWidgets[$szKey];

            if ($oWidget->GetValue("TYPE") == $szName)
                return $oWidget;
        }

        return false;
    }

    /**
     * register a skin directory with the Chameleon core skinning engine.
     * Paths that are relative are tested relative to both the application
     * path and the chameleon/htdocs path.
     * @param szPath string the path to register
     * @return void
     */
    function registerSkin( $szPath )
    {
        array_push( $this->maszSkinSearchPath, $szPath );
    }

    /**
     * this function loads a context. The name passed to this function
     * can be either a filename on the local filesystem OR a URL to a remote
     * context.  If it is a remote context, it will be downloaded first
     * and then loaded.
     *
     * If the file is a context collection, then each context in the
     * collection will be loaded in order.
     *
     * @param szContextName string the name (file or URL) of the context or
     * collection to load.
     * @param bAllowResize boolean (default true) Allow or not to resize the
     * map width and height with the context width and height.
     */
    function loadContext( $szContextName, $bAllowResize = true )
    {
        $bResult = loadContext( $szContextName, $this->moMapSession->oMap, $bAllowResize, false);

        if($bResult)
        {
            $this->mszCurrentState = $this->moMapSession->saveState();
            $_SESSION["gszCurrentState"] = $this->mszCurrentState;
            $this->moMapSession->restoreState($this->mszCurrentState,
                                              $this->mszMapFile,
                                              dirname($this->mszMapFile));
        }
    }
    /**
    * this function tests a file name and downloads it as a local file in the
    * session if it is a remote file, then returns the local filename.  If the
    * file is already local, then it will simply return the same name.
    * @param szFilename string the filename to get
    * @param szExtension string an optional extension to place on the local file if the
    * file is downloaded.  If the file is not downloaded, the filename is not
    * changed.
    * @return string a local filename or FALSE if fetching the remote file failed.
    */
    function getRemoteFile( $szFilename, $szExtension = "" )
    {
        if (strlen($szFilename) < 7)
        {
            $szLocalFile = $this->findFile($szFilename);
        }
        else if (strcasecmp( "http://", substr($szFilename, 0, 7 )) != 0)
        {
            $szLocalFile = $this->findFile( $szFilename );
        }
        else
        {
            //at this point we need to fetch the file
            $aszFile = @file( $szFilename );
            if ($aszFile === false)
            {
                $_SESSION["gErrorManager"]->setError(ERR_ERROR, "Error retrieving remote file ($szFilename), please ensure the URL is correct" );
                $szLocalFile = false;
            }
            else
            {
                $szLocalFile = tempnam($_SESSION['gszTmpPath'], "remote").".".$szExtension;
                $fh = @fopen($szLocalFile, "w");
                if ($fh === false)
                {
                    $szLocalFile = false;
                    $_SESSION["gErrorManager"]->setError(ERR_ERROR, "Error creating local copy ($szLocalFile) of remote file ($szFilename), please ensure permissions are correctly set." );
                }
                else
                {
                    $nbLine = count($aszFile);

                    for($i=0; $i<$nbLine; $i++)
                    {
                        fwrite($fh, $aszFile[$i]);
                    }
                    fclose($fh);
                }
            }
        }
        return $szLocalFile;
    }

    /**
     * this function attempts to locate a file in one of
     * (possibly) several locations.  If the original file
     * path is absolute, it will be returned as is.  If it
     * is relative, the it will be looked for in four possible
     * cases.
     *
     * 1. relative to app path in skin search paths
     * 2. relative to app path
     * 3. relative to chameleon in skin search paths
     * 4. relative to chameleon
     *
     * @param szFilePath string an absolute or relative path and file
     *        name to locate
     * @return string an absolute path to the file or false if the file
     *         could not be found.
     */
    function findFile( $szFilePath )
    {
        //echo "searching for $szFilePath<BR>\n";
        if ($szFilePath == '')
        {
            //echo "path is empty, returning false<BR>\n";
            return false;
        }
        //if path is absolute already, just test existance
        if ($this->isAbsolutePath( $szFilePath))
        {
            clearstatcache();
            if (file_exists( $szFilePath ))
            {
                //echo "path is absolute, returning $szFilePath.<BR>\n";
                return $szFilePath;
            }
            else
            {
                //echo "path is absolute but doesn't exist, returning false<BR>\n";
                return false;
            }
        }

        /* case 1 - skin search path relative to app */
        foreach( array_reverse($this->maszSkinSearchPath) as $szPath )
        {
            //echo "searching registered skin path $szPath<BR>\n";
            if ($this->isAbsolutePath($szPath))
            {
                $szTempPath = $this->resolvePath2( $szFilePath, $szPath );
            }
            else
            {
                $szTempPath = $this->resolvePath2( $szFilePath, $_SESSION['gszAppPath'].'/'.$szPath."/" );
            }
            //echo "resolved search path to $szTempPath<BR>\n";
            clearstatcache();
            if ($szTempPath != "" && file_exists($szTempPath))
            {
                //echo "found in registered skin: $szTempPath<BR>\n";
                return $szTempPath;
            }
        }

        /* case 2 - relative to app */
        $szTempPath = $this->resolvePath2( $szFilePath, $_SESSION['gszAppPath'] );
        clearstatcache();
        if ($szTempPath != "" && file_exists($szTempPath))
        {
            //echo "found relative to app: $szTempPath<BR>\n";
            return $szTempPath;
        }

        /* case 3 - skin search path relative to chameleon */
        foreach( array_reverse($this->maszSkinSearchPath) as $szPath )
        {
            $szTempPath = $this->resolvePath2( $szFilePath, $_SESSION['gszCorePath'].'/'.$szPath.'/' );
            clearstatcache();
            if ($szTempPath != "" && file_exists($szTempPath))
            {
                //echo "found in chameleon skins: $szTempPath<BR>\n";
                return $szTempPath;
            }
        }

        /* case 4 - relative to chameleon */
        $szTempPath = $this->resolvePath2( $szFilePath, $_SESSION['gszCorePath'] );
        clearstatcache();
        if ($szTempPath != "" && file_exists($szTempPath))
        {
            //echo "found: $szTempPath<BR>\n";
            return $szTempPath;
        }

        //echo "not found at all, returning false<BR>\n";
        return false;
    }

    /**
     * convert a filesystem path into a web accessible path.  With the second
     * parameter set to false (default value), this will return the file system
     * path if the file is not in a web-accessible location.  With the
     * second parameter set to true, the file will be copied to a web-accessible
     * location and the web-path will be calculated from there.  This guarantees
     * the result will be a URL :)
     * @param szFileSystemPath string the path to the file
     * @param bMakeWebVisible boolean if true, copy the file to a web-visible
     *        directory if necessary.
     * @return string a URL to the file or the original path if it is not web-visible.
     */
    function fileSystemToURL( $szFileSystemPath, $bMakeWebVisible=false )
    {
        $szFileSystemPath = str_replace( '\\', '/', $szFileSystemPath );
        $szFileSystemPath = ereg_replace ("/+", "/", $szFileSystemPath);
        //echo "filesystem path: $szFileSystemPath<BR>";

        $szAppPath = str_replace( '\\', '/', realpath($_SESSION['gszAppPath']) );
        $szAppPath = ereg_replace ("/+", "/", $szAppPath);
        //echo "app path: $szAppPath<BR>";

        if (strncmp( $szFileSystemPath, $szAppPath, strlen($szAppPath) ) == 0)
            return $_SESSION['gszAppWebPath'].'/'.substr( $szFileSystemPath, strlen($szAppPath));

        $szCorePath = str_replace( '\\', '/', realpath($_SESSION['gszCorePath']) );
        $szCorePath = ereg_replace ("/+", "/", $szCorePath);
        if (strncmp( $szFileSystemPath, $szCorePath, strlen($szCorePath) ) == 0)
            return $_SESSION['gszCoreWebPath'].'/'.substr($szFileSystemPath,strlen($szCorePath));

        $szTmpImgPath = str_replace( '\\', '/',
                                     realpath($_SESSION['gszTmpImgPath']) );
        $szTmpImgPath = ereg_replace ("/+", "/", $szTmpImgPath);
        if (strncmp( $szFileSystemPath, $szTmpImgPath, strlen($szTmpImgPath) ) == 0)
            return $_SESSION['gszTmpWebPath'].'/'.substr($szFileSystemPath,strlen($szTmpImgPath));
        // bartvde, if the function does not return before here, it needs to be made web visible automatically
        $bMakeWebVisible = true;
        if($bMakeWebVisible == true && is_file($szFileSystemPath))
        {
            $szDestFileName = $szTmpImgPath.'/'.
                substr($szFileSystemPath, strrpos($szFileSystemPath, '/'));
            copy($szFileSystemPath, $szDestFileName);
            return $_SESSION['gszTmpWebPath'].'/'.substr($szDestFileName,strlen($szTmpImgPath)+1);
        }
        // bartvde, this should never happen
        //return $szFileSystemPath;
    }

    /**
     * this function determines if a path represents an absolute path and returns
     * true if it is, and false if it is not
     * @param szPath string the path to test
     * @result boolean true if the path is absolute, false otherwise
     */
    function isAbsolutePath( $szPath )
    {
        if ($szPath == "") return false;
        if ($szPath[0] == "/" || preg_match('/^(\w:)/', $szPath))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    /**
     * This function translate $szDestPath (relative or absolute)
     * to a absolute path based on $szOrigPath.
     *
     * @param $szDestPath string Destination path to translate
     * @param $szOrigPath string Refenrece path
     */
    function resolvePath2 ($szDestPath, $szOrigPath)
    {
        // If one or other path is missing or absolute, return it.
        if ($szDestPath == "") return $szOrigPath;
        if ($szOrigPath == "") return $szDestPath;
        if ($szDestPath[0] == "/" || preg_match('/^(\w:)/', $szDestPath))
        {
            //echo "absolute: $szDestPath<BR>";
            return $szDestPath;
        }

        // If windows prefix (eg: c:) get it
        $szPrefix = "";
        if ($szOrigPath[0] != "/")
        {
            if (preg_match('/^(\w:)(.*)/i', $szOrigPath, $aMatch))
            {
                $szPrefix = $aMatch[1];
                $szOrigPath = $aMatch[2];
            }
            else
            {
                $szOrigPath = "/".$szOrigPath;
            }
        }

        // Make sure path finishing with "/"
        if ($szOrigPath[strlen($szOrigPath)-1] != "/" &&
            !is_dir($szOrigPath))
            $szOrigPath = dirname($szOrigPath)."/";
        if ($szOrigPath[strlen($szOrigPath)-1] != "/")
            $szOrigPath = $szOrigPath."/";

        $szPath = $szOrigPath.$szDestPath;

        // Remove repetitive "/"
        $szPath = ereg_replace ("/+", "/", $szPath);

        $szPath = $this->iterate_ereg_replace ("/\./", "/", $szPath);
        $szPath = $this->iterate_ereg_replace ("/[^(/|\.)]+/\.\./", "/", $szPath);

        //Rest of the function
        return $szPrefix.$szPath;
    }

    /**
     * Recursive ereg_replace
     *
     * @param $szPattern string Regular expression to process
     * @param $szReplacement string Value to replace all matching result with
     * @param $szString string Haystack to process on
     *
     * @return string szString with the matching result replaced.
     */
    function iterate_ereg_replace ( $szPattern, $szReplacement, $szString)
    {
        $szResult = $szString;
        do
        {
            $szString = $szResult;
            $szResult = ereg_replace ($szPattern, $szReplacement, $szString);
        }
        while ($szResult != $szString);

        return $szResult;
    }
}

/**
 * Return a reference to the main application.
 * @return object the global Chameleon application instance
 */
function &GetChameleonApplication()
{
    if(isset($GLOBALS['oChameleonApp']))
        return $GLOBALS['oChameleonApp'];

    $oApp = false;
    return $oApp;
}

 /* code maturity indicators
  * Code maturity indicates the stability and completeness of a widget.
  * It is to be maintained by the widget developer in conjunction with the
  * QA and documentation team.  Every widget, by default, will
  * inherit an UNKNOWN maturity level.  Widgets that are undergoing
  * active development should be marked as ALPHA.  When a widget is
  * considered functionally complete and free of major errors, it should
  * be marked as BETA.  Once QA has verified the widget functionality to
  * be stable, the widget can be marked as RELEASECANDIDATE.  When
  * a widget has full documentation (English) it can be changed to
  * a RELEASE level.  Any changes to a widget after marking as RELEASE
  * must be accompanied by a corresponding change in maturity level.  For
  * changes related to bug fixes, it is sufficient to drop one level to
  * RELEASECANDIDATE until the bug fix has been verified.  Any new development
  * will require that the widget be marked as BETA until the new functionality
  * has been tested.
  *
  * Code maturity level will be reflected in the widget documentation for
  * each widget.  In addition, it can affect whether the widget is available
  * in a given installation.  The Chameleon configuration file now contains
  * a code maturity level item that allows the administrator to define the
  * minimum maturity level available to all applications.  In addition,
  * individual applications can set a maturity level separately, but will be
  * restricted to the administratively configured minimum.  Only widgets at
  * or above the minimum maturity level will be available in an application.
  */
define( "MATURITY_MINIMUM", 0 );
define( "MATURITY_UNKNOWN", MATURITY_MINIMUM );
define( "MATURITY_ALPHA", MATURITY_UNKNOWN + 1 );
define( "MATURITY_BETA", MATURITY_ALPHA + 1 );
define( "MATURITY_RELEASECANDIDATE", MATURITY_BETA + 1 );
define( "MATURITY_TECHNICALRELEASE", MATURITY_RELEASECANDIDATE + 1 );
define( "MATURITY_PRODUCTRELEASE", MATURITY_TECHNICALRELEASE + 1 );
define( "MATURITY_MAXIMUM", MATURITY_PRODUCTRELEASE );

/*
 * chameleon API version.
 * The API version started with version 1.99.
 * It is used by some components (starting with the widget name
 * mapping in WidgetManger.php) to define an API version.  It
 * can be expected that the API will be consistent between POINT
 * versions but can change between MAJOR and MINOR versions.
 *
 * It could also be used for widgets that require a certain API
 * version to work in the future.
 *
 * There are 5 values defined:
 *
 * CHAMELEON_MAJOR_VERSION - the major release number
 * CHAMELEON_MINOR_VERSION - the minor release number, odd is dev, even is stable
 * CHAMELEON_POINT_VERSION - a bugfix release within a minor version
 * CHAMELEON_STATE_VERSION - a qualifier like ALPHA or BETA
 * CHAMELEON_VERSION - a combination of the above, in the form:
 *
 * 1.99.0
 * 2.2.0-beta3
 *
 *
 */
define( "CHAMELEON_MAJOR_VERSION", "2" );
define( "CHAMELEON_MINOR_VERSION", "6" );
define( "CHAMELEON_POINT_VERSION", "0" );
define( "CHAMELEON_STATE_VERSION", "rc1" );

define( "CHAMELEON_VERSION", CHAMELEON_MAJOR_VERSION.".".
                             CHAMELEON_MINOR_VERSION.
                             (CHAMELEON_POINT_VERSION == '' ? '' : "-" ).
                             CHAMELEON_STATE_VERSION );
//
// Make sure to report ALL errors
//
error_reporting( E_ALL & ~E_DEPRECATED );

//
// Form variables manager class definition
//
include_once("HttpFormVars.php");

//
// Define chameleon absolute path
//
if(!defined("CHAMELEON_PATH"))
    define( "CHAMELEON_PATH", dirname(__FILE__)."/." );

//
// Define path to the conguration settings
//
if(!defined("CHAMELEON_CONFIG_PATH"))
    define( "CHAMELEON_CONFIG_PATH", dirname(__FILE__)."/../config/" );
if (!file_exists(CHAMELEON_CONFIG_PATH))
{
    echo "Fatal error: Chameleon configuration directory (".CHAMELEON_CONFIG_PATH.
         ") does not exist. Please check your configuration.";
    exit;
}
if (!file_exists(str_replace("\\","/",CHAMELEON_CONFIG_PATH."/chameleon.xml")))
{
    echo "Fatal error: Chameleon configuration file ".
         "does not exist. Please check your configuration.";
    exit;
}

//
// Those 2 lines shouldn't be touched. They are replaced
// by the installer.
//
//%DMPEAR_COMMON%
//%DMPEAR_WEBCOMMON%


//
// Define path to php_utils
//
if(!defined("COMMON"))
    define( "COMMON",  dirname(__FILE__)."/common/" );
if (!file_exists(COMMON))
{
    echo "Fatal error: Common directory (".COMMON.") does not exist. Please check your configuration.";
    exit;
}

//
// include the logging functions
//
include_once( COMMON."logger/logfile.php" );
include_once( COMMON."logger/error_manager.php" );
include_once( COMMON."logger/logger.php" );

//
// include the xml parsing class
//
include_once( COMMON."appcontext/appcontext.php" );

//
// include wrapper file(s)
//
include_once( COMMON."wrapper/map_session.php" );

//
// include the mlt file
//
include_once( COMMON."mlt/mlt.php" );

//
// Session management
//
include_once( COMMON."session/session.php");

//
// MapServer Error Messages
//
include_once( 'widgets/ms_error.php' );

//
// ows functions
//
include_once( 'widgets/ows.php' );

//
// User management functions
//
include_once( 'Authenticator.php' );

//
// Initialize session management and start a session
//
installSessionDirectoryHandler();
$GLOBALS['bSessionOK'] = initializeSession("sid");


//
// convert the global session reference if necessary
//
if ( PHP_OS == "WINNT" || PHP_OS == "WIN32" )
{
    if ( version_compare( phpversion(), "4.2.1" ) < 0 )
        $_SESSION = &$HTTP_SESSION_VARS;
}

//
// Retrieve gszAppWebPath from session or as global variable
//
if (!isset($GLOBALS['gszAppWebPath']))
{
    if (isset($_SERVER["HTTPS"]) && strcasecmp($_SERVER['HTTPS'], "on") == 0)
        $http = "https://";
    else
        $http = "http://";

    if (isset($_SERVER['HTTP_X_FORWARDED_HOST']))
    {
        $GLOBALS['gszAppWebPath'] = $http.$_SERVER['HTTP_X_FORWARDED_HOST'];
    }
    else
    {
        $GLOBALS['gszAppWebPath'] = $http.$_SERVER['HTTP_HOST'];
    }

    if (version_compare( phpversion(), "4.3.3" ) < 0 ||
        (isset($_SERVER['REQUEST_URI']) &&
         $_SERVER['REQUEST_URI'] != $_SERVER['SCRIPT_NAME']))
    {
        $szURI = $_SERVER['REQUEST_URI'];
    }
    else
    {
        $szURI = $_SERVER['SCRIPT_NAME'];
    }

    /* there was a bug that caused gszAppWebPath to be incorrect if no
       filename was provided in the url (specifically, using the default
       index page in a directory), the original code did not account for
       this and the directory name would be stripped.  This attempts to
       build the directory correctly
    */
    $aszURI = parse_url( $szURI );
    $aszPath = pathinfo($aszURI['path']);
    if (isset($aszPath['extension']))
        $szPath = $aszPath['dirname'].'/';
    else
        if(substr($aszPath['dirname'], -1) != '/')
            $szPath = $aszPath['dirname']."/".$aszPath['basename'].'/';
        else
            $szPath = $aszPath['dirname'].$aszPath['basename'].'/';

    $GLOBALS['gszAppWebPath'] .= $szPath;
    $GLOBALS['gszAppWebPath'] = str_replace( '\\', '/', $GLOBALS['gszAppWebPath']);
    //$GLOBALS['gszAppWebPath'] = ereg_replace ("/+", "/", $GLOBALS['gszAppWebPath']);

}

if (!isset($_SESSION['gszAppWebPath']))
{
    $_SESSION['gszAppWebPath'] = $GLOBALS['gszAppWebPath'];
}

if (!isset($GLOBALS['gszAppPath']))
{
    //print_r($_SERVER);
    if (isset($_SERVER['PATH_TRANSLATED']) && $_SERVER['PATH_TRANSLATED'] != '')
    {
        $GLOBALS['gszAppPath'] = dirname( $_SERVER['PATH_TRANSLATED'])."/";
    }
    elseif (isset($_SERVER['ORIG_PATH_TRANSLATED']) && $_SERVER['ORIG_PATH_TRANSLATED'] != '')
    {
        $GLOBALS['gszAppPath'] = dirname( $_SERVER['ORIG_PATH_TRANSLATED'])."/";
    }
    elseif (isset($_SERVER['SCRIPT_FILENAME']) && $_SERVER['SCRIPT_FILENAME'] != '')
    {
        $GLOBALS['gszAppPath'] = dirname( $_SERVER['SCRIPT_FILENAME'])."/";
    }
    else
    {
        echo "FATAL Error: Chameleon was unable to determine the path to the application on the server.  To fix this, this application must explicitly set the application path before including chameleon.php.  The suggested method of doing this is:<br><PRE>\$GLOBALS['gszAppPath'] = '/full/path/to/application/htdocs/';</PRE><br>.";
        exit;
    }
}
if (!isset($_SESSION['gszAppPath']))
{
    $_SESSION['gszAppPath'] = realpath($GLOBALS['gszAppPath']);
}




?>
