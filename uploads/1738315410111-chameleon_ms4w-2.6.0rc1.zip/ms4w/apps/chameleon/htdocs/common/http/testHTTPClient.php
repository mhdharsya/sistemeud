<?php

// -------------------------------------------------------------------------------
// test script for the HTTP client based on the default implementation
// author: Bart van den Eijnden, OSGIS, http://www.osgis.nl
// -------------------------------------------------------------------------------

include_once('./HTTPClient.php');

// use default for the testcases
$_SESSION['HTTPClientType'] = 0;

// testcase 3 and 4 write out to file
$szTestcase3File = '/tmp/testcase3.xml';
$szTestcase4File = '/tmp/testcase4.xml';

$szOnlineResource = 'http://localhost:8081/cgi-bin/mapserv?map=/data/OGC_UMN_services/overzichtskaartnl.map&';
$szGET = 'service=WFS&request=GetCapabilities&version=1.0.0';
$szPOST = '<GetFeature service="WFS" version="1.0.0" maxfeatures="5"><Query typename="NL-prov">'.
  '</Query></GetFeature>'; 
// timeout in seconds
$timeout = 30;

// create the http client
$oHTTPClient = new HTTPClient($szOnlineResource, $timeout);

echo "<html>";
echo "<body>";

// --------------------------------------------------------------------------------------
// testcase 1: perform a HTTP GET request using curl and output as stream
// --------------------------------------------------------------------------------------
$result = $oHTTPClient->doGET($szGET);
if (!$result)
{
  echo "<p>Testcase 1 failed with the following error: ".$oHTTPClient->mszLastError."</p>";
}
else
{
  echo "<p>Testcase 1 succeeded with the following response: <xmp>".$result."</xmp></p>";
}

// --------------------------------------------------------------------------------------
// testcase 2: perform a HTTP POST request using curl and output as stream
// --------------------------------------------------------------------------------------
$result = $oHTTPClient->doPOST($szPOST);
if (!$result) 
{ 
  echo "<p>Testcase 2 failed with the following error: ".$oHTTPClient->mszLastError."</p>"; 
}
else
{
  echo "<p>Testcase 2 succeeded with the following response: <xmp>".$result."</xmp></p>";
}

// --------------------------------------------------------------------------------------
// testcase 3: perform a HTTP GET request using curl and output as file
// --------------------------------------------------------------------------------------
if (!($fpOut = fopen($szTestcase3File, 'w')))
{
  echo "<p>Could not open file for testcase 3</p>";
}
else
{
  $result = $oHTTPClient->doGET($szGET, $fpOut);
  if (!$result)  
  {
    echo "<p>Testcase 3 failed with the following error: ".$oHTTPClient->mszLastError."</p>";
  }
  else
  {
    echo "<p>Testcase 3 succeeded. Check file on disk: ".$szTestcase3File."</p>";
  }
}

// --------------------------------------------------------------------------------------
// testcase 4: perform a HTTP POST request using curl and output as file
// --------------------------------------------------------------------------------------
if (!($fpOut = fopen($szTestcase4File, 'w')))
{
  echo "<p>Could not open file for testcase 4</p>";
}
else
{
  $result = $oHTTPClient->doPOST($szPOST, $fpOut);
  if (!result)
  {
    echo "<p>Testcase 4 failed with the following error: ".$oHTTPClient->mszLastError."</p>";
  }
  else
  {
    echo "<p>Testcase 4 succeeded. Check file on disk: ".$szTestcase4File."</p>";
  }
}

echo "</body>";
echo "</html>";

?>
