<?php
/**
 * HTTP client
 *
 * @project     CWC2
 * @revision    $Id: HTTPClient.php,v 1.7 2007/07/26 16:07:26 bartvde Exp $
 * @purpose     HTTP client class, supports HTTP GET and HTTP POST
 * @author      OSGIS (bartvde@xs4all.nl)
 * @copyright
 * <b>Copyright (c) 2002, DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

class HTTPClient
{
  /* the online resource */
  var $mszOnlineResource;

  /* timeout in seconds */
  var $miTimeout;

  /* last error message */
  var $mszLastError;

  /* content-type returned */
  var $mszContentType;

  /* @abstract(constructor) */
  function HTTPClient($szOnlineResource, $iTimeout)
  {
    if (!isset($_SESSION['HTTPClientType']))
    {
      // the default is not using curl
      $_SESSION['HTTPClientType'] = 0;
    }

    $this->mszOnlineResource = $szOnlineResource;
    $this->miTimeout = $iTimeout;

    // if curl, check if curl is loaded
    if ($_SESSION['HTTPClientType'] == 1)
    {
      $szCURLModule = "php_curl";
      if (!extension_loaded("curl"))
        dl($szCURLModule . "." . PHP_SHLIB_SUFFIX);
    }
  }

  /* @abstract(perform a HTTP GET request, optionally save to file) */
  function doGET($szRequest, $fpOut = false)
  {
    // curl
    if ($_SESSION['HTTPClientType'] == 1)
    {
      $ch = curl_init();

      $header[] = "User-Agent: curl";
      curl_setopt($ch, CURLOPT_HTTPHEADER, $header);

      curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

      curl_setopt ($ch, CURLOPT_URL, $this->mszOnlineResource.$szRequest);
      curl_setopt ($ch, CURLOPT_HEADER, 0);
      curl_setopt ($ch, CURLOPT_TIMEOUT, $this->miTimeout);
      // do not return to stdout
      curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
      if ($fpOut)
      {
        curl_setopt($ch, CURLOPT_FILE, $fpOut);
        curl_exec($ch);
      }
      else
      {
        $data = curl_exec ($ch);
      }
      if (curl_errno($ch))
      {
        $this->mszLastError = curl_error($ch);
        return false;
      }
      else
      {
        $info = curl_getinfo($ch);
        $this->mszContentType = $info['content_type'];
        curl_close($ch);
        if ($fpOut)
        {
          fclose( $fpOut);
          return true;
        }
        else
        {
          return $data;
        }
      }
    }
    else if ($_SESSION['HTTPClientType'] == 0)
    {
      @set_time_limit( $this->miTimeout );
      if (false === ($fpIn = fopen($this->mszOnlineResource.$szRequest, "r")))
      {
        $this->mszLastError = "Could not access $szOnlineResource";
        return false;
      }
      else if ($fpOut)
      {
        // copy the file line by line
        while($fpIn && !feof($fpIn))
        {
          // build buffer
          $line = fgets($fpIn, 4096);

          // rewrite encoding tag
          // write the buffer to file
          fwrite($fpOut, $line, strlen($line));
        }

        // force a buffer write
        fflush( $fpOut );
        fclose( $fpOut );
        return true;
      }
      else
      {
        $buffer = '';
        while ($fpIn && !feof($fpIn))
        {
          $buffer .= fgets($fpIn, 4096);
        }
        return $buffer;
      }
      fclose($fpIn);
    }
  }

  /* @abstract(perform a HTTP POST request) */
  function doPOST($szRequest, $fpOut = false)
  {
    if ($_SESSION['HTTPClientType'] == 1)
    {
      $header[] = "MIME-Version: 1.0";
      $header[] = "User-Agent: curl";
      $header[] = "Content-type: text/xml";
      $header[] = "Accept: text/xml";
      $header[] = "Content-length: ".strlen($szRequest);
      $header[] = "Cache-Control: no-cache";
      $header[] = "Connection: close \r\n";
      $header[] = $szRequest;

      $ch = curl_init();
      curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
      curl_setopt($ch, CURLOPT_URL,$this->mszOnlineResource);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_TIMEOUT, $this->miTimeout);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST,'POST');
      curl_setopt($ch, CURLOPT_HTTPHEADER, $header);

      if ($fpOut)
      {
        curl_setopt($ch, CURLOPT_FILE, $fpOut);
        curl_exec($ch);
      }
      else
      {
        $data = curl_exec ($ch);
      }

      if (curl_errno($ch))
      {
        $this->mszLastError = curl_error($ch);
         return false;
      }
      else
      {
        $info = curl_getinfo($ch);
        $this->mszContentType = $info['content_type'];
        curl_close($ch);
        if ($fpOut)
        {
          fclose( $fpOut);
          return true;
        }
        else
        {
          return $data;
        }
      }
    }
    else if ($_SESSION['HTTPClientType'] == 0)
    {
      require_once(dirname(__FILE__)."/../../widgets/utils.php");
      $aUrlParts = parse_url($this->mszOnlineResource);
      $result = xu_query_http_post( $szRequest, $aUrlParts['host'], $this->mszOnlineResource, $aUrlParts['port'], 0, $this->miTimeout, null, null);
      if ($result == '')
      {
        $this->mszLastError = 'General error, empty response';
        return false;
      }
      else
      {
        if (!$fpOut)
        {
          return $result;
        }
        else
        {
          fwrite($fpOut, $result, strlen($result));
          fclose($fpOut);
        }
      }
    }
  }
}

?>
