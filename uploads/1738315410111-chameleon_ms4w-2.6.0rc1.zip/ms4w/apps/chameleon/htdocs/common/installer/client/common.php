<?php
/**
 * Installer main core
 *
 * @project     php_utils
 * @revision    $Id:
 * @purpose     Installer
 * @author      DM Solutions Group (sfournier@dmsolutions.ca)
 * @copyright
 * <b>Copyright (c) 2002, DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 * 
 */
require_once 'PEAR/Registry.php';
require_once 'PEAR/Command.php';
require_once 'PEAR/Frontend/CLI.php';
require_once 'XML/RPC.php';

define("CONSTANT_DEFINING_SERVER", "My Other Server");

$_GET['server'] = urlencode(CONSTANT_DEFINING_SERVER);

/**
 * Dummy class
 *
 * ... add comments ...
 */
class MyCustomClient extends PEAR
{
    function log($msg)
    {
    }

    function message($msg)
    {
    }

    function outputdata($msg, $command)
    {
    }
}

/*
if (!extension_loaded("php_mapscript"))
    dl("php_mapscript.so");

$gaMSInfo = GetMSInfo();
*/

// get applicagtions repository
$nPos = strpos(__FILE__, DIRECTORY_SEPARATOR."installer".DIRECTORY_SEPARATOR.
               "client".DIRECTORY_SEPARATOR."common.php");

$gszApplicationsRepository = substr(__FILE__, 0, $nPos+1);
$gaRemotePackages = array();   // Will contain a list of available packages (remotely)
$gaLocalPackages = array();    // Will contain a list of available packages (Localy)
$gaInstalledPackages = array();// Contain a simple list of all installed packages

$gaRemoteProducts = array();   // Will contain a list of available product (remotely)
$gaLocalProducts = array();    // Will contain a list of available product (localy)

$gaszServers = array();        // Will contain a list of cached servers

$gaszError = array();                // Error stack
$gaszWarning = array();              // Warning stack

$gszCatDesc = "";
$gszCatVer  = "";

// Check if user can write to $gszApplicationPath
if (!is_writable($gszApplicationsRepository))
{
    array_push($gaszError, "ERROR: No write access to ($gszApplicationsRepository).");
}

// Create a global registry object
$goRegistry = new PEAR_Registry($gszApplicationsRepository);

// Load all currently installed packages as a simple list
$gaInstalledPackages = ReloadInstalledPackage($goRegistry);

// Load all currently installed products
$gaLocalProducts = GetLocalProducts($goRegistry);

// Set the product to a default one if not set from URL.
if ((!isset($_GET['category']) || $_GET['category'] == ""))
{
    if (is_array($gaLocalProducts) && count($gaLocalProducts) > 0)
    {
        $aszKey = array_keys($gaLocalProducts);
        $_GET['category'] = $aszKey[0];
    }
    else
    {
        $_GET['category'] = "";
    }
}

// Load cached server list
$gaszServers = LoadServers();

// If a server is specified in URL, connect to it.
if (isset($_GET['server']) && $_GET['server'] != "")
{
    // Get server url
    $gszServerURL = $gaszServers[urldecode($_GET['server'])][0];

    // Get all packages from that server.
    // Ignore already installed ones.
    $gaRemoteProducts = ConnectServer($gszServerURL);

    // Remove already installed products
    if (is_array($gaLocalProducts))
    {
        foreach($gaLocalProducts as $szKey=>$szVal)
            if (isset($gaRemoteProducts[$szKey]))
	        unset($gaRemoteProducts[$szKey]);
    }

    // Get all remote  packages from server
    $gaRemotePackages = GetPackages($gszServerURL, $_GET['category'], 
                                    $gaInstalledPackages);
}

// Get all installed packages details
$gaLocalPackages = 
      GetLocalPackages(((isset($_GET['category']) && $_GET['category']!="") ? $_GET['category'] : 
                       ((isset($gaLocalProducts[0])) ? $gaLocalProducts[0] : "")),
		       $gaInstalledPackages,
		       ((isset($_GET['server']) && $_GET['server']!="") ? $gaszServers[urldecode($_GET['server'])][0] : ""));


/********************************
 * Helper functions below
 * 
 */



/**
 * Get all local products installed
 */
function GetLocalProducts(&$oRegistry)
{
    $aInstalledPackages = $oRegistry->listPackages();

    foreach($aInstalledPackages as $szPackage)
    {
        $aPackage = $GLOBALS['goRegistry']->packageInfo($szPackage);
        if (isset($aPackage['category']))
	{
	    if (isset($aReturn[$aPackage['category']]))
                $aReturn[$aPackage['category']]++;
            else
                $aReturn[$aPackage['category']] = 0;
	}
    }

    return $aReturn;
}

/**
 * ConnectServer()
 * 
 * This function check if server exist and connect
 * to it. Then retrieve all available packages
 * from it.
 *
 * @param szServerName Server name to connect to.
 * 
 */
function ConnectServer($szServerName)
{
    // separate url in parts.
    $aURLInfo = parse_url($szServerName);

    // Create XML RPC client
    $oClient = new XML_RPC_Client(
                          $aURLInfo['path'], 
                          $aURLInfo['host'], 
                          (isset($aURLInfo['port'])) ? $aURLInfo['port'] : 80);

    //$oClient->setDebug(1);

    // Get all categories
    $oRespond = $oClient->send(new XML_RPC_Message("server.listCategories"));
    $oValue = $oRespond->value();

    if (!isset($oValue->me['struct']))
    {
        array_push($GLOBALS['gaszError'],"ERROR: Can't connect to server ($szServerName).");
        return;
    }

    // Reinitialize array
    $aRemoteCategories = array();
    foreach($oValue->me['struct'] as $szCategory => $oInfo)
    {
        $szCatDesc = $oInfo->me['struct']['description']->me['string'];
        $szCatVer = $oInfo->me['struct']['version']->me['string'];

        $aPackages = array();
        foreach($oInfo->me['struct']['packages']->me['array'] as $oPackage)
	{
            array_push($aPackages, $oPackage->me['string']);
	}

        $aRemoteCategories[$szCategory] = array('description'=>$szCatDesc, 
                                                'version'=>$szCatVer,
                                                'packages'=>$aPackages);
    }

    return $aRemoteCategories;
}

/**
 * ConnectServer()
 * 
 * This function check if server exist and connect
 * to it. Then retrieve all available packages
 * from it.
 *
 * @param szServerName Server name to connect to.
 * 
 */
function GetPackages($szServerName, $szCategory, $aInstalledPackages=array())
{
    $aURLInfo = parse_url($szServerName);

    // Create XML RPC client
    $oClient = new XML_RPC_Client(
                                  $aURLInfo['path'], 
                                  $aURLInfo['host'], 
                                  (isset($aURLInfo['port'])) ? $aURLInfo['port'] : 80);

    //$oClient->setDebug(1);

    // Get all package
    $oRespond = $oClient->send(new XML_RPC_Message("package.listAll"));

    $oValue = $oRespond->value();

    if (!isset($oValue->me['struct']))
    {
        array_push($GLOBALS['gaszError'], "ERROR: Can't get packages from server ($szServerName).");
        return;
    }

    // Reinitialize array
    $aRemotePackages = array();
    foreach($oValue->me['struct'] as $szPackage => $oInfo)
    {
        $szInstalledVersion = "";
	//if ($oInfo->me['struct']['category']->me['string'] == $szCategory)
	{
            // Check if packages is installed. Only include the package
            // if the package is more recent.
            foreach ($aInstalledPackages as $szTmpPackage)
            {
	        if (strcasecmp($szTmpPackage, $szPackage) == 0)
                {
                    $aPackage = $GLOBALS['goRegistry']->packageInfo($szPackage);

                    if (PEAR::isError($aPackage))
                    {
                        array_push($GLOBALS['gaszError'], $aPackage->getMessage());
                        return;
                    }
        
                    $szInstalledVersion = $aPackage['version'];
                }
            }

	    // Get dependecies (if any)

            // Translate the package info in a more convenient structure.
            if ($szInstalledVersion < trim($oInfo->me['struct']['version']->me['string']))
	    {
	        $aDeps = array();
	        foreach($oInfo->me['struct']['release_deps']->me['array'] as $oDep)
		{
                    $aDep = array();
		    foreach ($oDep->me['struct'] as $szKey => $oVal)
		    {
		        $aDep[$szKey] = $oVal->me['string'];
		    }
                    array_push($aDeps, $aDep);
		}

                $aRemotePackages[$szPackage] = 
                  array('version'=>$oInfo->me['struct']['version']->me['string'],
                        'summary'=>$oInfo->me['struct']['summary']->me['string'],
                        'description'=>$oInfo->me['struct']['description']->me['string'],
                        'category'=>$oInfo->me['struct']['category']->me['string'],
                        'stable'=>$oInfo->me['struct']['stable']->me['string'],
                        'filesize'=>$oInfo->me['struct']['filesize']->me['int'],
                        'location'=>$oInfo->me['struct']['location']->me['string'],
                        'installed_version'=>$szInstalledVersion,
                        'release_deps'=>$aDeps);
	    }
        }
    }

    return $aRemotePackages;
}

/**
 * GetLocalPackags()
 * 
 * Return a list of localy installed packages
 *
 */
function GetLocalPackages($szCategory, $aInstalledPackages, $szServerName="")
{
    // Reinitialize array
    $aLocalPackages = array();

    if ($szServerName == "")
        $szAvailableVersion = "";

    foreach ($aInstalledPackages as $szPackage)
    {
        $aPackage = $GLOBALS['goRegistry']->packageInfo($szPackage);

        if (PEAR::isError($aPackage))
        {
            array_push($GLOBALS['gaszError'], $aPackage->getMessage());
            return;
        }

        if ($szServerName != "")
	{
	    // Get Package info
	    $aURLInfo = parse_url($szServerName);
	    $oClient = new XML_RPC_Client(
                      $aURLInfo['path'],
                      $aURLInfo['host'],
		      (isset($aURLInfo['port'])) ? $aURLInfo['port'] : 80);

	    //$oClient->setDebug(1);

	    $oRespond = $oClient->send(
			  new XML_RPC_Message("package.info", 
			 		      array(new XML_RPC_Value(basename($szPackage), "string"))));

	    if (PEAR::isError($oRespond) || !isset($oRespond->xv->me['struct']))
	    {
	        $szAvailableVersion="";
	    }
        else
	    {
	        $oInfo = $oRespond->value();
            foreach($oInfo->me['struct'] as $szVersion=>$oPackageInfo)
		    {
                if (isset($oPackageInfo->me['struct']['version']->me['string']))
		        {
    		        $szAvailableVersion = $oPackageInfo->me['struct']['version']->me['string'];
                    break;
		        }
		    }
	    }
	}

        // available_version is only set if installed from the web insterface.
        if (isset($aPackage['available_version']))
            $aPackage['available_version'] =  $szAvailableVersion;

        $szTmpCategory = $aPackage['category'];

        if ($szCategory == $szTmpCategory)
	    $aLocalPackages[$aPackage['package']] = $aPackage; 
    }

    return $aLocalPackages;
}

/*
function GetLocalPackageBaseDir($szPackage)
{
    $aFiles = array();
    $aFileList = $GLOBALS['goRegistry']->packageInfo($szPackage, 'filelist');

    if (!is_array($aFileList))
        return false;

    foreach ($aFileList as $szName => $aAttrs)
    {
        if (isset($aAttrs['role']) && $aAttrs['role'] != 'php')
	    continue;

        if (isset($aAttrs['baseinstalldir']))
	    $szFile = $aAttrs['baseinstalldir'].DIRECTORY_SEPARATOR.$szName;
        else
	    $szFile = $szName;

        $szFile = preg_replace(',^/+,', '', $szFile);

	return dirname($szFile);
    }
}
*/

/**
 * DeleteServer
 * 
 * @param szServerName Server name to delete
 *
 * this should delete a server from the cached
 * server list.
 */
function DeleteServer($szServerName)
{
    // Not yet implemented
}

/**
 * AddServer
 * 
 * @param szServerName Server name to add
 * @param szServerURL Server url to add
 *
 * this should add a server into the cached
 * server list.
 */
function AddServer($szServerName, $szServerURL)
{
    // not yet implemented
}

/**
 * ReloadInstalledPackage()
 *
 * This function simply reload the list of
 * installed packages on the system.
 */
function  ReloadInstalledPackage(&$oRegistry)
{
    $aInstalledPackages = $oRegistry->listPackages();

    return $aInstalledPackages;
}
/**
 * LoadServers
 *
 * Load local cached server list
 */
function LoadServers($szFileName="./cached_servers.txt")
{
    $aszServers = file($szFileName);
    $aszServerReturn = array();
    foreach ($aszServers as $aszServer)
    {
        // Skip empty line or ones starting with #
        if (substr($aszServer, 0, 1) == "#" ||
            trim($aszServer) == "")
            continue;

        $aServer = explode("|", $aszServer);
        $szName = trim($aServer[0]);
        $szURL = trim($aServer[1]);

        // Load predefined path for applications
        $aCategory = array();
        for($i=2; $i<count($aServer);$i=$i+2)
	{
	    if (isset($aServer[$i]) && isset($aServer[$i+1]))
	        $aCategory[trim($aServer[$i])] = trim($aServer[$i+1]);
	}

        $aszServersReturn[$szName] = array($szURL, $aCategory);
    }

    return $aszServersReturn;
}

/**
 * SaveServers()
 *
 * Save all servers list to a file
 */
function SaveServers($szFileName="./cached_servers.txt", $aszServers=array())
{
    if (!is_writable($szFileName))
    {
        array_push($GLOBALS['gaszError'], "ERROR: No write access to cached_servers.txt. Skiping save cached servers.");
        return;
    }

    $fh = fopen($szFileName, "w");

    foreach($aszServers as $szServerName => $szURL)
        fwrite($fh, $szServerName."|".$szURL."\n");

    fclose($fh);
}

function GetMSInfo()
{
    if (!function_exists("ms_getversion"))
        return false;

    $aszMSInfo = explode(" ", ms_getversion());
    $szMSVersion = $aszMSInfo[2];
    $aMSInfo = array();
    for ($i=3;$i<count($aszMSInfo); $i++)
    {
        $aszTmpInfo = explode("=", $aszMSInfo[$i]);
	if (isset($aMSInfo[$aszTmpInfo[0]]) && is_array($aMSInfo[$aszTmpInfo[0]]))
            array_push($aMSInfo[$aszTmpInfo[0]], $aszTmpInfo[1]);
        else if (isset($aMSInfo[$aszTmpInfo[0]]))
            $aMSInfo[$aszTmpInfo[0]] = array($aMSInfo[$aszTmpInfo[0]], $aszTmpInfo[1]);
        else
            $aMSInfo[$aszTmpInfo[0]] = $aszTmpInfo[1];
    }
    $aMSInfo['VERSION'] = $szMSVersion;

    return $aMSInfo;
}
?>
