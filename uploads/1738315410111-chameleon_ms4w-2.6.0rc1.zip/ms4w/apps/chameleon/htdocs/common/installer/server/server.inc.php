<?php
require_once 'XML/RPC/Server.php';
require_once 'PEAR/Common.php';

define('PACKAGES_REPOSITORY', './packages/');
define('PACKAGES_WEB_REPOSITORY', 'http://192.168.4.13/packages/');

define('CATEGORIES_FILE', 'categories.xml');
?>