<?php
define("INSTALL_INCLUDED", "true");
define("DS", DIRECTORY_SEPARATOR);

// If script is called from the user and not the web installer
// we have to create the registry object.
if (!isset($goRegistry))
{
  include_once("PEAR/Registry.php");
  $gszApplicationsRepository = realpath(dirname(__FILE__).DS."..").
                               DS;
  $goRegistry = new PEAR_Registry($gszApplicationsRepository);

}

function setApplicationName($szPackageName, $szApplicationName)
{
    GLOBAL $goRegistry;

    $goRegistry->UpdatePackage($szPackageName, array('category' => $szApplicationName));
}

function setHttpdConfFile($szPackageName, $szConfFile)
{
    GLOBAL $gszApplicationsRepository;

    if ( PHP_OS == "WINNT" || PHP_OS == "WIN32" )
      $szConfFile = str_replace("/", "\\\\", $szConfFile);

    // Make sure the directory exist.
    if (!file_exists($gszApplicationsRepository."httpd.d"))
        mkdir($gszApplicationsRepository."httpd.d");

    // Create configuration file for apache
    $fh = fopen($gszApplicationsRepository.DS."httpd.d".DS.
                "httpd_".$szPackageName.".conf", "w");
    $aFile = file($gszApplicationsRepository.DS.$szConfFile);

    foreach($aFile as $szKey => $szContent)
    {
        fwrite($fh, str_replace("\\", "/", 
                    str_replace("%DMPEAR%", $gszApplicationsRepository,  $szContent)));
    }

    fclose($fh);
}

function copyFileAndReplace($aszReplaceFrom, $aszReplaceTo, $szInFile, $szOutFile="")
{
    GLOBAL $gszApplicationsRepository;

    if ( PHP_OS == "WINNT" || PHP_OS == "WIN32" )
    {
        $szInFile = str_replace("/", "\\\\", $szInFile);
        $szOutFile = str_replace("/", "\\\\", $szOutFile);
    }

    // Open in file
    $aFile = file($gszApplicationsRepository.DS.$szInFile);

    // Open out file
    if ($szOutFile=="")
        $szOutFile = $szInFile;

    $fh = fopen($gszApplicationsRepository.DS.$szOutFile, "w");

    //parse each line of in file and put it in out file
    foreach($aFile as $szKey => $szContent)
        fwrite($fh, str_replace($aszReplaceFrom, $aszReplaceTo, $szContent));

    // Close file
    fclose($fh);
}

function getApplicationRepositoryDir()
{
    return $GLOBALS['gszApplicationsRepository'];
}
?>