<?php
/* ************************************************
     Post installation process for installer
   ***********************************************/
// Include help functions
if (!defined("INSTALL_INCLUDED"))
{
    if (isset($GLOBALS['argv'][1]))
    {
        if (!@include_once(str_replace("\\", "/", $GLOBALS['argv'][1]."/installer/client/install.php")))
        {
            echo "\n\nPlease specify path to applications repository. EG: php -q post-installation.php /DMPear/\n\n";
            exit;
        }
    }
    else
    {
        echo "\n\nPlease specify path to applications repository. EG: php -q post-installation.php /DMPear/\n\n";
        exit;
    }
}

// Step 1.
//
// Update registry. We put category inside the registry.
setApplicationName("installer", "installer");


// Step 2.
//
// Create httpd.d if don't exist. Copy the file in the correct
// directory and replace all %DMPEAR% instance to the current
// applications repository.
setHttpdConfFile("installer", "installer/httpd_installer.conf");
?>