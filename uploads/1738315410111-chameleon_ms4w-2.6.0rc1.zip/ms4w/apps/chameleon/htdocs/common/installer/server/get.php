<?php // -*- PHP -*-
include_once 'server.inc.php';

// shut up or we risk getting corrupted tgz files
error_reporting(0);

function error_404($obj)
{
  header('HTTP/1.0 404 Not Found');
  if (is_object($obj))
  {
    echo $obj->getMessage();
    if (DEVBOX)
    {
      echo ' ' . $obj->getDebugInfo();
    }
  } 
  else
  {
    print $obj;
  }
  exit;
}

PEAR::setErrorHandling(PEAR_ERROR_CALLBACK, 'error_404');

if (!isset($_SERVER['PATH_INFO']) || $_SERVER['PATH_INFO'] == '/')
{
  PEAR::raiseError('no package selected');
}

$opts = explode('/', substr($_SERVER['PATH_INFO'], 5));
$ok = false;

if (isset($_GET['uncompress']) && in_array($_GET['uncompress'], array('1', 'yes', 'on')))
{
  $uncompress = true;
}
else
{
  $uncompress = false;
}

switch (sizeof($opts))
{
  case 1:
  {
    if (preg_match('/^([a-zA-Z0-9_]+)-(.+)\.(tar|tgz)$/', $opts[0], $matches)) 
    {
      list(, $package, $version) = $matches;
      $ok = HTTPdownload($package, $version, $opts[0], $uncompress);
    }
    elseif (preg_match('/^([a-zA-Z0-9_]+)-(.+)$/', $opts[0], $matches))
    {
      list(, $package, $version) = $matches;
      $ok = HTTPdownload($package, $version, null, $uncompress);
    }
    else
    {
      $ok = HTTPdownload($opts[0], null, null, $uncompress);
    }
    break;
  }
  case 2:
  {
    $ok = HTTPdownload($opts[0], $opts[1], null, $uncompress);
    break;
  }
  default:
  {
    $ok = false;
  }
}

function getLatestVersion($szPackage)
{
    $oPearCommon = new PEAR_Common();

    $szVersion = false;

    // Browse all package from directory
    $hDir = dir(PACKAGES_REPOSITORY);
    while (false !== ($szEntry = $hDir->read()))
    {
        if (substr($szEntry, -4) == '.tgz')
        {
            $aReturn = $oPearCommon->infoFromTgzFile(PACKAGES_REPOSITORY.$szEntry);
            if ($aReturn['package'] == $szPackage)
	    {
	        if ($szVersion < $aReturn['version'])
                    $szVersion = $aReturn['version'];
	    }
	}
    }

    return $szVersion;
}


function HTTPdownload($szPackage, $szVersion = null, $szFile = null, $bUncompress = false)
{
    $oPearCommon = new PEAR_Common();

    if ($szFile === null)
    { 
        $szFile = $szPackage;

        if ($szVersion === null)
            $szVersion = getLatestVersion($szPackage);

        if ($szVersion === false)
        {
            header('HTTP/1.0 404 Not Found');
            print 'File not found';
            exit;
        }

        $szFile .= "-".$szVersion.".tgz";
    }

    $aReturn = $oPearCommon->infoFromTgzFile(PACKAGES_REPOSITORY.$szFile);

    if (!$aReturn)
    {
        return PEAR::raiseError("release download:: package '".htmlspecialchars($szPackage).
	    		        "' does not exist");
    }

    //    header('Last-modified: '.filemtime(PACKAGES_REPOSITORY.$szFile));
    header('Content-type: application/octet-stream');

    if ($bUncompress)
    {
      $tarname = preg_replace('/\.tgz$/', '.tar', $szFile);
      header('Content-disposition: attachment; filename="'.$tarname.'"');

      readgzfile(PACKAGES_REPOSITORY.$szFile);
    }
    else
    {
      header('Content-disposition: attachment; filename="'.$szFile.'"');
      header('Content-length: '.filesize(PACKAGES_REPOSITORY.$szFile));

      readfile(PACKAGES_REPOSITORY.$szFile);
    }
}
?>
