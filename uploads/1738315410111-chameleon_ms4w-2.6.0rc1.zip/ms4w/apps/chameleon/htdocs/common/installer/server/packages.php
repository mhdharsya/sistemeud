<?php
/**
 * Server packages manager
 *
 * @project     php_utils
 * @revision    $Id:
 * @purpose     Server package manager
 * @author      DM Solutions Group (sfournier@dmsolutions.ca)
 * @copyright
 * <b>Copyright (c) 2002, DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 * 
 */
include_once 'server.inc.php';
require_once 'XML/RPC/Server.php';
require_once 'XML/Tree.php';

// Create XML RPC server
$s = new XML_RPC_Server(array(
            "server.listCategories" => array("function" => "listCategories"),
            "package.listAll" => array("function" => "listPackages"),
            "package.listLatestReleases" => array("function" => "listPackages"),
            "package.info" => array("function" => "info")));

/**
 * This function will send a list of all products
 * supported by the server.
 *
 */
function listCategories()
{
    // Parse all category from text file
    $oXML = new XML_Tree(PACKAGES_REPOSITORY.CATEGORIES_FILE);
    $oRoot = $oXML->getTreeFromFile();
    $oCategories = $oRoot->getNodeAt('category');

    $nCategory = 0;
    $oCategory = $oRoot->getElement($nCategory);
    while (!PEAR::isError($oCategory))
    {
        // parse all package for that category and count only the lates version
        $aCategory = array();
        $aDefaultPackages = array();
        $nCount=0;

        $oPackages = $oCategory->getNodeAt('packages');
        if (PEAR::isError($oPackages))
  	    continue;

        $nPackage = 0;
        $oPackage = $oPackages->getElement($nPackage);
        while(!PEAR::isError($oPackage))
	{
	    // Get package name (without version)
	    if (!isset($oPackage->attributes['name']))
	        continue;

	    $szPackage = substr($oPackage->attributes['name'], 0, 
                                strpos($oPackage->attributes['name'], "-"));

            if (!isset($aCategory[$oPackage->attributes['name']]) || 
                !in_array($szPackage, $aCategory[$oPackage->attributes['name']]))
	    {
                if (!isset($aCategory[$oPackage->attributes['name']]))
	            $aCategory[$oPackage->attributes['name']] = array();

	        array_push($aCategory[$oPackage->attributes['name']], $szPackage);
                if (isset($oPackage->attributes['default']) && 
		    strcasecmp($oPackage->attributes['default'], "true") == 0)
		    array_push($aDefaultPackages, new XML_RPC_Value($szPackage));

                $nCount++;
	    }

            $nPackage++;
            $oPackage = $oPackages->getElement($nPackage);
	}

        // Get category description
        $oDesc = $oCategory->getNodeAt('description');
        if (!PEAR::isError($oDesc))
 	    $szDesc = $oDesc->content;
        else
 	    $szDesc = "";

        // Version version
        $szVer = (isset($oCategory->attributes['version'])) ? $oCategory->attributes['version']: "";

        $aReturn[$oCategory->attributes['name']] = new XML_RPC_Value(
                          array('description' => new XML_RPC_Value(htmlspecialchars($szDesc), 'string'),
                                'version'     => new XML_RPC_Value($szVer, 'string'),
                                'packages'    => new XML_RPC_Value($aDefaultPackages, 'array')), "struct");

        $nCategory++;
        $oCategory = $oRoot->getElement($nCategory);
    }

    return new XML_RPC_Response(new XML_RPC_Value($aReturn, "struct"));
}


/**
 * This function answer to "listAll" XMLRPC call.
 *
 * It return a list of packages.
 */
function listPackages()
{
    // Create Base pear object
    $oPearCommon = new PEAR_Common();

    $aReturn = array();

    // Browse all file finishing by .tgz
    $hDir = dir(PACKAGES_REPOSITORY);
    while (false !== ($szEntry = $hDir->read()))
    {
        if (substr($szEntry, -4) == '.tgz')
	{
	    $nFileSize = filesize(PACKAGES_REPOSITORY.$szEntry);

	    // Get package info
	    $aPackage = $oPearCommon->infoFromTgzFile(PACKAGES_REPOSITORY.$szEntry);

	    // If there's already a version keep the newest one
	    if (!isset($aReturn[$aPackage['package']]) ||
		$aReturn[$aPackage['package']]->me['struct']['version']->me['string'] <
		$aPackage['version'])
	    {
	        // Get dependecies.
	        $aaDeps = array();
                if (isset($aPackage['release_deps']))
   	            foreach($aPackage['release_deps'] as $aDep)
		    {
     	                $aDeps = array();
			foreach($aDep as $szKey=>$szVal)
			    $aDeps[htmlspecialchars($szKey)] = new XML_RPC_Value(htmlspecialchars($aDep[$szKey])); 

			array_push($aaDeps, new XML_RPC_Value($aDeps, 'struct'));
		    }

	        $aReturn[$aPackage['package']] = 
		  new XML_RPC_Value(array("summary"=>new XML_RPC_Value(htmlspecialchars($aPackage['summary'])),
				     "description"=>new XML_RPC_Value(htmlspecialchars($aPackage['description'])),
		  	             "category"=>new XML_RPC_Value(GetCategoryFor($szEntry)),
				     "stable"=>new XML_RPC_Value(htmlspecialchars($aPackage['version'])),
				     "version"=>new XML_RPC_Value(htmlspecialchars($aPackage['version'])),
				     "filesize"=>new XML_RPC_Value($nFileSize,"int"),
				     "location"=>new XML_RPC_Value(htmlspecialchars(PACKAGES_WEB_REPOSITORY.$szEntry)),
			             "release_deps"=>new XML_RPC_Value($aaDeps, 'array')),"struct");
            }
	}
    }

    $oResp = new XML_RPC_Response(new XML_RPC_Value($aReturn, "struct"));

    return $oResp;
}

function GetCategoryFor($szPackage)
{
    // Parse all category from text file
    $oXML = new XML_Tree(PACKAGES_REPOSITORY.CATEGORIES_FILE);
    $oRoot = $oXML->getTreeFromFile();
    $oCategories = $oRoot->getNodeAt('category');

    $nCategory = 0;
    $oCategory = $oRoot->getElement($nCategory);
    while (!PEAR::isError($oCategory))
    {
        // parse all package for that category and count only the lates version
        $aCategory = array();
        $nCount=0;

        $oPackages = $oCategory->getNodeAt('packages');
        if (PEAR::isError($oPackages))
  	    continue;

        $nPackage = 0;
        $oPackage = $oPackages->getElement($nPackage);
        while(!PEAR::isError($oPackage))
	{
	    // Get package name (without version)
	    if (!isset($oPackage->attributes['name']))
	        continue;

            if (strcasecmp($szPackage, $oPackage->attributes['name']) == 0)
	        return $oCategory->attributes['name'];

            $nPackage++;
            $oPackage = $oPackages->getElement($nPackage);
	}

        $nCategory++;
        $oCategory = $oRoot->getElement($nCategory);
    }

    return "Misc";
}

/**
 * This function answer to "info" XMLRPC call.
 *
 * It return all info for a package
 */
function info($oParam)
{
    // Get package name from parameter
    $szPackage = $oParam->params[0]->me['string'];

    // Create base pear object
    $oPearCommon = new PEAR_Common();

    $aReturn = false;

    // Browse all package from directory
    $hDir = dir(PACKAGES_REPOSITORY);
    while (false !== ($szEntry = $hDir->read()))
    {
        if (substr($szEntry, -4) == '.tgz')
        {
	    $szTmpPackage = substr($szEntry, 0, -4);

            $aPackage = $oPearCommon->infoFromTgzFile(PACKAGES_REPOSITORY.$szEntry);
            if (PEAR::isError($aPackage))
	    {
	      // error with package
	      continue;
	    }

            $nFileSize = filesize(PACKAGES_REPOSITORY.$szEntry);

            $aMatch = array();
            preg_match("/([a-zA-Z0-9_]+)[-]([a-zA-Z0-9.]+)/", $szTmpPackage, $aMatch);

            if (count($aMatch) == 3 && strcasecmp($aMatch[1], $szPackage) == 0)
	    {
	        // Get dependecies.
	        $aaDeps = array();
                if (isset($aPackage['release_deps']))
   	            foreach($aPackage['release_deps'] as $aDep)
		    {
     	                $aDeps = array();
			foreach($aDep as $szKey=>$szVal)
			    $aDeps[htmlspecialchars($szKey)] = new XML_RPC_Value(htmlspecialchars($aDep[$szKey])); 

			array_push($aaDeps, new XML_RPC_Value($aDeps, 'struct'));
		    }

	         $aReturn = new XML_RPC_Value(array($aPackage['version'] => new XML_RPC_Value(array("summary"=>new XML_RPC_Value(htmlspecialchars($aPackage['summary'])),
				   "name"=>new XML_RPC_Value(htmlspecialchars($szPackage)),
				   "description"=>new XML_RPC_Value(htmlspecialchars($aPackage['description'])),
		  	           "category"=>new XML_RPC_Value(htmlspecialchars(GetCategoryFor($szEntry))),
				   "state"=>new XML_RPC_Value(htmlspecialchars($aPackage['release_state'])),
				   "version"=>new XML_RPC_Value(htmlspecialchars($aPackage['version'])),
				   "stable"=>new XML_RPC_Value(htmlspecialchars($aPackage['version'])),
				   "filesize"=>new XML_RPC_Value($nFileSize,"int"),
				   "license"=>new XML_RPC_Value(htmlspecialchars($aPackage['release_license'])),
				   "location"=>new XML_RPC_Value(htmlspecialchars(PACKAGES_WEB_REPOSITORY.$szEntry)),
			           "release_deps"=>new XML_RPC_Value($aaDeps, 'array')),"struct")),"struct");

                 return new XML_RPC_Response($aReturn);
            }
        }
    }

    return new XML_RPC_Response(new XML_RPC_Value(0));
}
?>