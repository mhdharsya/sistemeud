var browser ="";
var version = "";
var xpos;
if (navigator.appName == "Netscape")
{
    browser = "netscape";
    if ( navigator.appVersion[0] <= 4)
      version = 4;
    else
      version = 5;
}
else
{
    browser = "ie";
}

function SetLayerPos(layerName, x, y)
{
    var oLayer = UTLGetLayer(layerName);
    
    if (oLayer != null)
    {
        oLayer.left=x;
        oLayer.top=y;
    }
    else
        alert( "layer " + layerName + " doesn't exist" );
}

function SetLayerSize(layerName, lWidth, lHeight)
{

    var oLayer = UTLGetLayer( layerName );

    oLayer.width = lWidth;
    oLayer.height = lHeight;

}

function SetLayerVis(layerName, bVisible)
{
    var oLayer = UTLGetLayer(layerName);
    if (browser == "netscape" && version == 4)
    {
        if (bVisible)
            oLayer.visibility = "show";
        else
            oLayer.visibility = "hide";
    }
    else
    {
        if (bVisible)
            oLayer.visibility = "visible";
        else            
            oLayer.visibility = "hidden";
    }
}

function UTLGetLayer( name )
{
    
    var layer;
    
    if (browser == "netscape")
    {                
        if (version == "4")
          return document.layers[name];
        else
        {
            if (eval('document.getElementById("' + name + '")') != null)
            {
                if( arguments.length > 1 && arguments[1] == true )
                {
                    layer = eval('document.getElementById("' + name + '")');
                }
                else
                {
                    layer = eval('document.getElementById("' + name + '").style');
                }
                return layer;
            } 
            else 
            {
                return null;
            }
        } 
    }
    else if (browser == "ie")
    {            
        if (eval('document.all.' + name) != null) 
        {
            if( arguments.length > 1 && arguments[1] == true )
            {
                layer = eval('document.all.' + name);
            }
            else
            {
                layer = eval('document.all.' + name + '.style');
            }
            return layer;

        } 
        else 
        {
            return null;
        }
    } 
    else // Don't know
    {                              
        return null;
    }
}


function spawnChild(szPage, nWidth, nHeight)
{
    window.open(szPage,'genwin','width='+nWidth+',height='+nHeight+',directories=no,location=no,menubar=no,scrollbars=no,status=no,toolbar=no,resizable=yes');
}

// expands the component metadata info layer
function ShowCompInfo( bFlag )
{
    var oLayer = UTLGetLayer( 'localconfig' );
    
    if( bFlag == true )
    {
        oLayer.height = 150;
        //SetLayerVis( 'alphaLayer', true );
    }
    else
    {
        oLayer.height = 60;
        //SetLayerVis( 'alphaLayer', false );
    }
}

// Sets the textarea description field from the selected component
function SetDesc( szDesc, szKey )
{
    if( szDesc.length > 0 )
    {
        document.forms[0].descriptionField.value = '';
        document.forms[0].descriptionField.value = unescape(szDesc);
    }
    else
    {
        document.forms[0].descriptionField.value = 'No Description Available';
    }
    
    var oLayer = UTLGetLayer( 'packageTitle', true );
    oLayer.innerHTML = szKey;
}


// Inits the packages install
function InstallPackage( szKey )
{
    // show the install layer
    SetLayerVis( 'installLayer', true );
    // hide the rest of the screen
    SetLayerVis( 'alphaLayer', true );
}

function CancelInstallPackage()
{
    // show the install layer
    SetLayerVis( 'installLayer', false );
    // hide the rest of the screen
    SetLayerVis( 'alphaLayer', false );
}
