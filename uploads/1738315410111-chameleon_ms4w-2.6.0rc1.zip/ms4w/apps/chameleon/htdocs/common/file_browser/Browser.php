<?php
/**
 * Browser
 *
 * szMode
 *   - open   (Open a file)
 *   - new    (select a directory and create a new file in it)
 *   - select (select a directory)
 */

/**
 * Check for a defined COMMON variable containing the absolute path.  If not
 * found then check ../ then ./ else failure.
 */
if ( defined( "COMMON" ) && is_dir( COMMON ) )
{
    // check for closing "\" or "/"
    if ( substr( COMMON, strlen( COMMON )- 1, 1 ) == "\\" ||
         substr( COMMON, strlen( COMMON ) - 1, 1 ) == "/" )
    {
        include_once( COMMON."logger/logger.php");
        include_once( COMMON."logger/logfile.php");
        include_once( COMMON."logger/errormanager.php");
	include_once( COMMON."session/session.php" );
    }
    else
    {
        include_once( COMMON."/logger/logger.php");
        include_once( COMMON."/logger/logfile.php");
        include_once( COMMON."/logger/error_manager.php");
	include_once( COMMON."/session/session.php" );
    }
}
elseif (file_exists("../logger/logger.php"))
{
    include_once("../logger/logger.php");
    include_once("../logger/logfile.php");
    include_once("../logger/error_manager.php");
    include_once("../session/session.php" );
}
else
{
    include_once("./logger/logger.php");
    include_once("./logger/logfile.php");
    include_once("./logger/error_manager.php");
    include_once("./session/session.php" );
}

installSessionDirectoryHandler();
initializeSession();

define("mode_open", 1); /// Open a existing file mode
define("mode_new", 2); /// create a new file mode
define("mode_select", 3); /// Select a directory mode
define("mode_save", 4); //save or saveas
define("last_mode", 5); /// internal use

$http_form_vars = sizeof($_POST) > 0 ? $_POST :
                  (sizeof($_GET) > 0 ? $_GET : array(""));

class Browser extends Logger
{
    var $m_szCallBackFunc; // Call back function name
    var $m_szCurrentDir; /// Last directory selected
    var $m_szRootDir;
    var $m_szFilter; /// file filter (eg: "*.zip")

    var $m_aszDirectory;
    var $m_aszFile;

    /**
     * Browser constructor
     *
     */
    function Browser()
    {
        $this->m_szCallBackFunc = "";

        $this->m_szCurrentDir = "";
        $this->m_szFilter = "";
        $this->m_szRootDir = "";

        $this->m_aszDirectory = array();
        $this->m_aszFile = array();
    }

    /**
     * Initialise Browser
     *
     * @param  $szCallBackFunc is the javascript callback function to call when a user click on something.
     * @param  $szCurrentDir represent the starting directory.
     * @param  $szRootDir is the base directory. User cant go under this folder
     * @param  $szExtension if set browser only display file that finish with this parameter.
     *
     */
    function Initialize($szCallBackFunc, $szCurrentDir="/", $szRootDir="/", $szFilter="All files (*.*)|*.*")
    {
        $this->logFuncStart(LOG_VERBOSE, "Initialize($szCallBackFunc, $szCurrentDir, $szRootDir, $szFilter) called.");

        /**
         * if callback function is invalid set it to default one
         */
        if ($szCallBackFunc == "")
        {
            $this->error(ERR_WARNING, "Invalid specified callback function. Using \"CallbackFunc\" as default.");

            $szCallBackFunc = "CallbackFunc";
        }

        /**
         * If szRootDir if invalid set it to path name of szSelected.
         */
        if ($szRootDir == "" ||
            !is_dir(str_replace("\\","/", $szRootDir)))
        {
            $this->error(ERR_WARNING, "Invalid specified root directory. Using \"$szSelected\" as default.");
            $szRootDir = dirname(getcwd());
        }
        else
            $szRootDir = str_replace("\\", "/", realpath($szRootDir));


        if ($szCurrentDir == "" ||
            !is_dir(str_replace("\\", "/", $szRootDir.$szCurrentDir)))
        {
            $szCurrentDir = "/";
        }
        else
        if (substr($szCurrentDir, -1) != "/")
            $szCurrentDir = str_replace("\\", "/", $szCurrentDir."/");
        else
            $szCurrentDir = str_replace("\\", "/", $szCurrentDir);


        if ($szFilter == "")
        {
            $this->error(ERR_NOTICE, "Unspecified extension filter. Using \"*\" as default.");

            $szFilter = "All files (*.*)|*.*";
        }

        /**
         * Check if selected dir is under root dir.
         */
        if (strstr(realpath($szRootDir.$szCurrentDir),
                   realpath($szRootDir)) == false)
            $this->m_szCurrentDir = "/";
        else
             $this->m_szCurrentDir = str_replace("\\", "/", substr(realpath($szRootDir.$szCurrentDir)."/", strlen($szRootDir) ));

        $this->m_szCallBackFunc = $szCallBackFunc;
        $this->m_szRootDir = $szRootDir;
        $this->m_szFilter = $szFilter;

        $this->logFuncEnd(LOG_VERBOSE, "Initialize() return.");
    }

    /**
     * Build XML document that represent the
     * browser.
     */
    function buildFileList()
    {
        $this->logFuncStart(LOG_VERBOSE, "buildFileList called.");

        /**
         * Scan all file and directory in starting dir.
         */
        $handle=opendir($this->m_szRootDir.$this->m_szCurrentDir);

        while ($szFileName = readdir($handle))
        {
            if($szFileName == '.')
                continue;

            if($szFileName == "..")
            {
                array_push($this->m_aszDirectory, "..");

                continue;
            }

            if(is_dir($this->m_szRootDir.$this->m_szCurrentDir.$szFileName))
            {
                array_push($this->m_aszDirectory, $szFileName);
            }
            else
            {
                if ($this->checkFileName($szFileName))
                    array_push($this->m_aszFile, $szFileName);
            }
        }
        closedir($handle);

        $this->logFuncEnd(LOG_VERBOSE, "buildFileList() done.");
    }

    /**
     * Calculate a relative path from a absolute one.
     *
     * @param $szSrc Absolute path where we start calculating.
     * @param $szDst Absolute path where we should reach.
     *
     * @return relative path
     */
    function abs2rel($szSrc, $szDst)
    {
        /**
         * seperate both paths into segments
         */
        if (substr($szSrc, -1) == "/")
            $szSrc = substr($szSrc, 0, strlen($szSrc)-1);

        if (substr($szDst, -1) == "/")
            $szDst = substr($szDst, 0, strlen($szDst)-1);

        /// calculate smallest path
        $nMin = min(strlen($szSrc), strlen($szDst));

        /// Loop until paths are different
        for ($i=0; $i<$nMin; $i++)
        {
            if ($szSrc[$i] != $szDst[$i])
            {
                break;
            }
        }

        $szSrc = substr($szSrc, $i);
        $szDst = substr($szDst, $i);

        $aszSrc = explode("/", $szSrc);
        $aszDst = explode("/", $szDst);

        /// calculate how mush dir to go back
        $nBack = count($aszSrc);
        if ($aszSrc && $aszSrc[0] == "")
            $nBack--;

        /// Add ".."
        $aszTmpDst = array();
        for ($i=1; $i<=$nBack; $i++)
        {
            array_push($aszTmpDst, "..");
        }

        $aszDst = array_merge($aszTmpDst, $aszDst);
        $szDst = implode("/", $aszDst);

        if ($nBack < 1)
            $szDst = ".".$szDst;

        return $szDst;
    }

    /**
       Check if filename can be displayed
       according to current filter.

       @param szFileName File name to check.

       $return True if file can be displayed or false if not.
    */
    function checkFileName($szFileName)
    {
        $aszExtensions = explode(";", $this->m_szFilter);
        $aszExtensions = explode("|", $aszExtensions[0]);
        $aszExtensions = explode(",", $aszExtensions[1]);

        foreach ($aszExtensions as $szExtension)
        {
            $perl_ext = str_replace(".", "\.", $szExtension);
            $perl_ext = "^".str_replace("*", ".*", $perl_ext)."$";

            if (preg_match("/$perl_ext/i", $szFileName)==1)
                return true;
        }
        return false;
    }
}

$oBrowser = new Browser();

//this is a hack to stop a php notice that occurs when directories 
//are clicked in the file list
if (!(isset($http_form_vars["szCallBack"])))
{
    $http_form_vars["szCallBack"] = "";
}
$oBrowser->Initialize($http_form_vars["szCallBack"],    // Javascript callback func
                      $http_form_vars["szCurrentDir"],  // Selected item
                      $_SESSION[$http_form_vars['szRootDir']],// Root directory
                      $http_form_vars["szFilter"]);     // Filter
?>
