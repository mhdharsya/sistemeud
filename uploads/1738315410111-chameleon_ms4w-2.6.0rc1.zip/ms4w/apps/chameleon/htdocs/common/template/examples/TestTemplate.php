<?
include("template/Template.php");
include("Logger/logfile.php");

$xslFileName = "users.xsl";

$db_name = "DMSPM";
$db_conn = &ADONewConnection("mysql");
$db_conn->Connect("localhost", "root", "",  $db_name);

$oTemplate = new TemplateServices();

$oLogFile = new LogFile("test.log", LOG_TO_FILE, 0);
$oTemplate->setLogfile($oLogFile);

$oTemplate->AddMiscVariable("PageTitle", "This is a template test");
$oTemplate->AddMiscVariable("Author", "Sacha Fournier");

$sql = "SELECT * FROM users";
$res = &$db_conn->Execute($sql);

$oTemplate->SQLResultToXML($res, "User");

$oTemplate->TransformXMLdocument($xslFileName);
?>
