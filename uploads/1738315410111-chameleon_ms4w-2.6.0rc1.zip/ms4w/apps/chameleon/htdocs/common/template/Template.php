<?php
/**
 * Template services is a utility that help to produce XML data
 * for XSL template processing. Both functionality are in the
 * same class.
 *
 * Package(s) used: Logger, ADODB
 *
 * @author Sacha Fournier (sfournier@dmsolutions.ca)
 * @project PhpUtil
 * @revision $Id
 * @purpose Manage application interface template through XML data.
 * @copyright Copyright DM Solutions Group Inc 2002
 *
 */
/**
 * Check for a defined COMMON variable containing the absolute path.  If not 
 * found then check ../ then ./ else failure.
 */
if ( defined( "COMMON" ) && is_dir( COMMON ) )
{
    // check for closing "\" or "/"
    if ( substr( COMMON, strlen( COMMON )- 1, 1 ) == "\\" ||
         substr( COMMON, strlen( COMMON ) - 1, 1 ) == "/" )
    {
        include_once( COMMON."logger/logger.php");
        include_once( COMMON."adodb/adodb.inc.php");
    }
    else
    {
        include_once( COMMON."/logger/logger.php");
        include_once( COMMON."/adodb/adodb.inc.php");
    }
}
elseif (file_exists("../logger/logger.php"))
{
    include_once("../logger/logger.php");
    include_once("../adodb/adodb.inc.php");
}
else
{
    include_once("./logger/logger.php");
    include_once("./adodb/adodb.inc.php");
} 

/**
 * Template services are use by applications that need to seperate
 * data from interface (html). To achieve this, all php code must
 * produce a XML document that will be used by the interface.
 *
 * When the XML document is ready to be transform into HTML, we call
 * the parsing process with a file template. All tags in this template
 * are replaced by corret value from XML document. Syntax of template
 * file is XSL.
 *
 * For the momment, there is two way to adds some XML information.
 * You can call then AddMiscVariable(varName, varValue) that will add
 * a new XML tag named <varName> into <root> node. You can also add a
 * complete row set from ADODB services by calling SQLResultToXML.
 *
 */
class TemplateServices extends Logger
{
    var $szXMLDocument; /// contain XML document
    var $bClosed;       /// tell if current XML doc is closed.

    /**
     * Constructor here open a new XML document with
     * <root> node.
     */
    function TemplateServices()
    {
        $this->Logger("TemplateServices");
        $this->logFuncStart(LOG_VERBOSE, "TemplateServices() called.");

        $this->OpenXMLDocument();

        $this->logFuncEnd(LOG_VERBOSE, "TemplateServices() returning.");
    }

    /**
     * Start a new XML document.
     */
    function OpenXMLDocument()
    {
        $this->logFuncStart(LOG_VERBOSE, "OpenXMLDocument() called.");

        $this->bClosed = false;
        $this->szXMLDocument = "<root>\n";

        $this->logFuncEnd(LOG_VERBOSE, "OpenXMLDocument() returning.");
    }

    /**
     * Close XML document.
     */
    function CloseXMLDocument()
    {
        $this->logFuncStart(LOG_VERBOSE, "CloseXMLDocument() called.");

        $this->bClosed = true;
        $this->szXMLDocument.= "</root>\n";

        $this->logFuncEnd(LOG_VERBOSE, "CloseXMLDocument() returning.");
    }

    /**
     * This function add a array of value to
     * current XML document. XML will be formated this
     * way:
     * <szNodeNames>
     *    <NodeName>aszVal[0]</NodeName>
     *    <NodeName>aszVal[1]</NodeName>
     *    <NodeName>aszVal[2]</NodeName>
     *  and so on...
     * </szNodeNames>
     *
     * @param szNodeName - Node name used for XML output.
     * @param aszVal - array of values to add to document.
     *
     * @return
     */
    function AddArray($szNodeName, $aszVal)
    {
        $this->logFuncStart(LOG_QUIET, "AddArray($szNodeName, $aszVal) called.");

        if (!$this->bClosed)
        {
            $this->szXMLDocument .= "<".$szNodeName."s>\n";

            foreach ($aszVal as $szVal)
            {
                $this->szXMLDocument .= $this->BuildMiscVariable($szNodeName, $szVal);
            }

            $this->szXMLDocument .= "</".$szNodeName."s>\n";
        }
        else
        {
            // Warnig, tag will not be added since document is closed.
            $this->error(1, "WARNING: XML document closed. Can't add array.");
            return false;
        }

        $this->logFuncEnd(LOG_QUIET, "AddArray() returning.");
    }

    /**
     * This function add a simple XML tag
     * to current document.
     *
     * @param szNodeName - XML node used to create tag (<nodename>val</nodename>)
     * @param varValue - Value put in XML tag.
     *
     * @return false if current document is closed.
     */
    function AddMiscVariable($szNodeName, $varValue)
    {
        $this->logFuncStart(LOG_VERBOSE, "AddMiscVariable($szNodeName, $varValue) called.");

        // document must be open
        if (!$this->bClosed)
            $this->szXMLDocument.= $this->BuildMiscVariable($szNodeName, $varValue);
        else
        {
            // Warnig, tag will not be added since document is closed.
            $this->error(1, "WARNING: XML document closed. Can't add misc variable.");
            return false;
        }

        $this->logFuncEnd(LOG_VERBOSE, "AddMiscVariable() returning.");

        return true;
    }

    /**
     * Add a array of variable to XML document.
     * aszVarValue must have this form: var -> value.
     *
     * @param szNodeName - XML node used to create tag (<nodename(s)>val</nodename(s)>)
     * @param aszVarValue - Array of values to put in XML tag.
     *
     * @return false if current document is closed.
     */
    function AddMiscVariables($szNodeName, $aszVarValue)
    {
        $this->logFuncStart(LOG_QUIET, "AddMiscVariables($szNodeName, $aszVarValue) called.");

        if (!$this->bClosed)
        {
            $this->szXMLDocument .= "<$szNodeName>\n";

            $this->szXMLDocument .= $this->BuildMiscVariables($aszVarValue);

            $this->szXMLDocument .= "</$szNodeName>\n";
        }
        else
        {
            // Warnig, tag will not be added since document is closed.
            $this->error(1, "WARNING: XML document closed. Can't add misc variables.");
            return false;
        }

        $this->logFuncEnd(LOG_QUIET, "AddMiscVariables() returning.");
    }

    /**
     * This function return a simple XML tag.
     *
     * @param szNodeName - See AddMiscVariable
     * @param varValue - See AddMiscVariable
     *
     * @return A string with the XML tag.
     */
    function BuildMiscVariable($szNodeName, $varValue)
    {
        $this->logFuncStart(LOG_VERBOSE, "BuildMiscVariable($szNodeName, $varValue) called.");

        $szRes = "<$szNodeName>$varValue</$szNodeName>\n";

        $this->logFuncEnd(LOG_VERBOSE, "AddMiscVariable() returning.");

        return $szRes;
    }

    /**
     * Return a array of variable to XML document.
     * aszVarValue must have this form: var -> value.
     *
     * @param aszVarValue - Array of value to return into XML format.
     *
     * @resturn A string that conatain all values from array in XML format.
     */
    function BuildMiscVariables($aszVarValue)
    {
        $this->logFuncStart(LOG_QUIET, "BuildMiscVariables($aszVarValue) called.");

        $szRes = "";

        foreach ($aszVarValue as $szKey => $szValue)
        {
            $szRes .= $this->BuildMiscVariable($szKey, $szValue);
        }

        $this->logFuncEnd(LOG_QUIET, "BuildMiscVariables() returning.");

        return $szRes;
    }

    /**
     * Transform recordset $oResult to XML document.
     * Node name can be specified with $szNodeName.
     *
     * @param oResult - Record set to transform into XML.
     * @param szNodeName - XML Node name that encapsulate value of recordset.
     *
     * @return False if current document is closed.
     */
    function SQLResultToXML($oResult, $szNodeName = "recordset")
    {
        $this->logFuncStart(LOG_VERBOSE, "AddMiscVariables($oResult, $szNodeName) called.");

        // XML doc mus be open
        if (!$this->bClosed)
        {
            // array node name
            $this->szXMLDocument.= "<".$szNodeName."s NbOf$szNodeName=\"".$oResult->RowCount()."\">\n";

            while (!$oResult->EOF)
            {
                // node name
                $this->szXMLDocument.= "\t<$szNodeName>\n";

                // add all fields and values.
                for ($nFieldCount=0; $nFieldCount < $oResult->_numOfFields; $nFieldCount++)
                {
                    $field    = $oResult->fields[$nFieldCount];     // Get field value
                    $f        = $oResult->FetchField($nFieldCount);
                    $fld_name = $f->name;  // Get field name
                    $this->szXMLDocument.="\t\t<$fld_name>$field</$fld_name>\n";
                }

                // close node name
                $this->szXMLDocument.= "\t</$szNodeName>\n";

                $oResult->MoveNext();
            }
            // close array node name
            $this->szXMLDocument.= "</".$szNodeName."s>\n";
        }
        else
        {
            // Warnig, tag will not be added since document is closed.
            $this->error(1, "WARNING: XML document closed. Can't add row set.");
            return false;
        }

        $this->logFuncEnd(LOG_VERBOSE, "SQLResultToXML() returning.");
        return true;
    }

    /**
     * this function Apply a XSL style sheet to current
     * XML document and return the result as string. Parser
     * used is Sablotron. PHP must be compiled with this
     * extension (--with-sablot).
     *
     * @param szXSLFileName - XSL file name to use for transformation.
     *
     * @return HTML formated of current XML document.
     */
    function TransformXMLDocument($szXSLFileName)
    {
        $this->logFuncStart(LOG_VERBOSE, "TransformXMLDocument($szXSLFileName) called.");

        if (!$this->bClosed)
            $this->CloseXMLDocument();

        if (!file_exists($szXSLFileName))
        {
            //error
            $this->error(1, "XSL file does not exist.");
            return false;
        }

        // Open style sheet
        $szXSL = join('', file($szXSLFileName));
        //$szRes = false;

        $this->log( LOG_ALL, "creating xslt parser" );
        $xh = xslt_create( );

        $this->log( LOG_ALL, "transform ".$this->szXMLDocument );
        $this->log( LOG_ALL, "using ".$szXSL );

        $args = array( '/_xml' => $this->szXMLDocument, '/_xsl' => $szXSL );

        $szRes = xslt_process($xh, 'arg:/_xml', 'arg:/_xsl', NULL, $args);
        if ($szRes === false)
        {
            $this->error( 0, "XSL transform error ".xslt_error($xh) );
            echo xslt_error($xh);
            echo $szXSLFileName;
            echo realpath(".");
        }

        xslt_free( $xh );
        $this->logFuncEnd(LOG_VERBOSE, "TransformXMLDocument() returning.");

        return $szRes;
    }
}
?>
