<?PHP
//turn off cookies for propagating session ids
//ini_set( "session.use_cookies", "0" );

//name the session
//$sess_name = "sid";
//session_name( $sess_name );

//use passed session id or start a new one
//session_id(isset($_GET[$sess_name]) ? $_GET[$sess_name] :
//           (isset($_POST[$sess_name]) ? $_POST[$sess_name] : uniqid("")));

//start the session
//session_start();

include_once("../logger/logger.php");

class ColorPicker extends Logger
{
    var $m_szCallbackFunc;
    var $m_nRed;
    var $m_nGreen;
    var $m_nBlue;

    /**
     * ColorPicker constructor
     *
     * @param $szCallbackFunc Callback function call when user do something.
     * @param $nRed Starting red color (0-255).
     * @param $nGreen Starting green color (0-255).
     * @param $nBlue Starting blue color (0-255).
     */
    function ColorPicker($szCallbackFunc, $nRed=255, $nGreen=255, $nBlue=255)
    {
        $this->Logger("ColorPicker");
        $this->logFuncStart(LOG_VERBOSE, "ColorPicker($szCallbackFunc, $nRed, $nGreen, $nBlue) called.");

        if ($szCallbackFunc == "")
        {
            $this->error(ERR_WARNING, "No callback function specified. Using \"CallbackFunc\" as default.");

            $szCallbackFunc = "CallbackFunc";
        }

        $this->m_szCallbackFunc = $szCallbackFunc;

        /**
         * Validate each color components. If out of bound set
         * or equal nothing (empty string) set it to 255.
         */
        $this->m_nRed = ($nRed >=0 && $nRed <= 255 && $nRed != "") ? $nRed : 255;
        $this->m_nGreen = ($nGreen >=0 && $nGreen <= 255 && $nGreen != "") ? $nGreen : 255;
        $this->m_nBlue = ($nBlue >=0 && $nBlue <= 255 && $nBlue != "") ? $nBlue : 255;

        $this->logFuncEnd(LOG_ALL, "Done with ColorPicker().");
    }
}

$oColorPicker = new ColorPicker($_GET["CallBackFunc"], $_GET["red"], $_GET["green"], $_GET["blue"]);
?>
