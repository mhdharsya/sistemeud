Package AppContext:

This folder contains the appcontext module and a test script.  You will need to
copy appcontext.php, test_appcontext.php, testctxt.xml, and the logger files
to a single directory to run the test without modifying the files.  Alternately
you can modify the include paths.

See the extensive :) comments in appcontext.php for useage.  You can also check
the test script for a working example.

Support Information:

bug reports in bugzilla under PHP Utils or to php-utils-bugs@dmsolutions.ca
enhancement requests to bugzilla or php-utils@dmsolutions.ca
questions to php-utils@dmsolutions.ca