<?php

//test the AppContext class

include( "appcontext.php" );
include_once( "error_manager.php" );
include_once( "logfile.php" );

//initialize global objects
//$gLogFile = new LogFile( "d:/mapedit/php/testctxt.log", LOG_TO_FILE, true );
//$gLogFile->setMaxLogLevel( LOG_ALL );
//$gErrorManager = new ErrorManager();

$szFile = "d:/mapedit/php/testctxt.xml";
echo "using configuration file $szFile<br>\n";

$appContext = new AppContext( $szFile );
echo "initialized AppContext<br>\n";

$aszParams = array( "app_title", "directory", "allow_browsing", "root_directory",
                 "mapserver_version", "mapserver_cgi_name_location", 
				 "configuration_file", "template_file", "mapfileslist" );
				 
echo "<TABLE><TR><TD>PARAM</TD><TD>VALUE</TD><TD>DESCRIPTION</TD></TR>";
foreach( $aszParams as $szParam )
{
	echo "<TR>";
	echo "<TD>$szParam</TD>";
	echo "<TD>".$appContext->getContextValue( $szParam )."</TD>";
	echo "<TD>".$appContext->getContextDescription( $szParam )."</TD>";
	echo "</TR>";
}
echo "</TABLE>";
?>