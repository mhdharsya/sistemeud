<?php
/**
 * gzDecompress()
 *
 * Postcondition:  This function takes the given gzipped file and decompresses 
 *                 it to the given filename.
 * @param szSourceFile string - Path and filename of the gzipped file.
 * @param szDestinationFile string - Path and filename of the output file.
 * @return boolean
 * @desc Decompresses the given gz file
 */
function gzDecompress( $szSourceFile, $szDestinationFile )
{
    // load the zlib library if necessary
    if (PHP_OS == "WINNT" || PHP_OS == "WIN32")
    {
        if (!extension_loaded("zlib")) dl("php_zlib.dll");
    }
    else
    {
        if (!extension_loaded("zlib")) exit( "zlib support for PHP was not ".
                   "found.  You must include zlib support when compiling PHP." );
    }
    
    // open the gzipped file
    if ( !$zp = gzopen ( $szSourceFile, "r" ) )
        return false;
        //exit( "Unable to open: ".$szSourceFile );
    
    // delete the file if it exists
    if ( file_exists( $szDestinationFile ) )
        unlink( $szDestinationFile );
        
    // create a new file to write to
    if ( !$fp = fopen ( $szDestinationFile, "wb" ) )
        return false;
        //exit( "Unable to open: ".$szDestinationFile );

    // read the contents of the zipped file
    while($zp && !gzeof($zp))
    {
        // read
        if ( !$szContents = gzread( $zp, 4096 ) )
            return false;
            //exit( "Unable to read file: ".$szContents );
    
        // write the contents of the gz file to new file
        if ( !fwrite( $fp, $szContents ) )
            return false;
            //exit( "Unable to write to file: ".$szDestinationFile );
    }    
    
    // close the file pointers
    gzclose ( $zp );
    fclose( $fp );
    
    // return success
    return true;
}
?>