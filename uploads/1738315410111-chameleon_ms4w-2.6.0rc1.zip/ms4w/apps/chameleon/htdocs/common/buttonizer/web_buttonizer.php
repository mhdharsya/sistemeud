<?php
/**
 * create a button from a url
 */

$http_form_vars = (count($_POST) > 0) ? $_POST :
               ((count($_GET) > 0) ? $_GET : array() );

include_once( "buttonizer.php" );

//build parameters array
$aParams = array();

if (isset( $http_form_vars["debug"] ))
{
    if ($http_form_vars["debug"] == "true")
        $aParams["debug"] = true;
    else
        $aParams["debug"] = false;
}
else
{
    $aParams["debug"] = false;
}
if (isset( $http_form_vars["antialias"] ))
{
    if ($http_form_vars["antialias"] == "true")
        $aParams["antialias"] = true;
    else
        $aParams["antialias"] = false;
}
else
{
    $aParams["antialias"] = false;
}
setParameter( $aParams, "width", 0 );
setParameter( $aParams, "height", 0 );
setParameter( $aParams, "backgroundcolor", "-1-1-1" );
setParameter( $aParams, "border_tl_image", "" );
setParameter( $aParams, "border_t_image", "" );
setParameter( $aParams, "border_tr_image", "" );
setParameter( $aParams, "border_r_image", "" );
setParameter( $aParams, "border_br_image", "" );
setParameter( $aParams, "border_b_image", "" );
setParameter( $aParams, "border_bl_image", "" );
setParameter( $aParams, "border_l_image", "" );
setParameter( $aParams, "backgroundgraphic", "" );
setParameter( $aParams, "graphic", "" );
setParameter( $aParams, "label", "no label" );
setParameter( $aParams, "labelfont", "arialbd.ttf" );
setParameter( $aParams, "labelsize", "11" );
setParameter( $aParams, "labelcolor", "000000" );
setParameter( $aParams, "labelalign", "left" );
setParameter( $aParams, "padding", 0 );
setParameter( $aParams, "nudge", 0 );
setParameter( $aParams, "gd_module", "php_gd2" );
setParameter( $aParams, "freetype", "FreeType" );

buttonize( "", $aParams );

function setParameter( &$aParams, $szName, $mDefault )
{
    $aParams[$szName] = (isset( $GLOBALS["http_form_vars"][$szName] )) ?
                         $GLOBALS["http_form_vars"][$szName] : $mDefault;
}
?>