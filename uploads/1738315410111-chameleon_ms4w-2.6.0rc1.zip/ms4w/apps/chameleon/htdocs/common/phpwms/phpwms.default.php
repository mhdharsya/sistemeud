<?php
// Packages
define("EXTRACTABLE_LAYER", false);
define("LAYER_ABSTRACT", false);

if (isset($_SESSION['gbLayerStyle']))
{
  define("LAYER_STYLE", $_SESSION['gbLayerStyle']);
}
else
{
  define("LAYER_STYLE", false);
}

// Extra fields
$gaExtraFields = array(DB_SERVER => array(),
                       DB_STYLE => array(),
                       DB_THEME => array(),
                       DB_ALIAS => array(),
                       DB_LAYER => array(),
                       DB_FIELD => array(),
                       DB_CAPABILITIES => array(),
                       DB_BBOX => array());
?>