<html>
<body BGCOLOR="#E3F0F0" LEFTMARGIN="0" TOPMARGIN="0" MARGINWIDTH="0" MARGINHEIGHT="0">
<form>
<table width=100%>
<tr><td align=right>
  <input type=image src="./images/icon_txt_ok.gif" onclick="parent.close()">&nbsp;
<!--  <input type=image src="./images/icon_txt_ok.gif" onclick="parent.info.document.forms[0].submit()">&nbsp; -->
  <input type=image src="./images/icon_txt_close.gif" onclick="parent.close()">
</td></tr>
</table>
</form>
</body>
</html>
