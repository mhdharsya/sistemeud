<?php
$nStart = getmicrotime();
// make sure the url dont contain spaces
$szURL = str_replace(" ", "+", trim(urldecode($_GET['szTestURL'])));
$fh = @fopen($szURL, "r");
$nStop = getmicrotime();

if ($fh)
{
    $szFile = "";
    while(!feof($fh))
    {
        $szFile .= fread($fh, 1024);
    }
  
    $aszFile = explode("\n", $szFile);
    fclose($fh);
}

$fh = fopen("/tmp/runtest_workdir/".$_GET['szTestName'], "w");
fwrite($fh, "LOAD_TIME: ");
fwrite($fh, $nStop-$nStart."\n");

if (isset($aszFile) && is_array($aszFile) && count($aszFile) > 0)
    foreach($aszFile as $szFile)
    {
        fwrite($fh, $szFile);
    }

fclose($fh);

function getmicrotime()
{
    list($usec, $sec) = explode(" ",microtime()); 
    return ((float)$usec + (float)$sec); 
} 
?>