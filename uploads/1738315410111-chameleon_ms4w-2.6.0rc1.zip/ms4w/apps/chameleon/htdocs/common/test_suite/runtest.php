<?php
/**
 * This script help to test the Chameleon template system for W2GI
 * web site (DrivingDirections). To use it, just call at the prompt:
 *
 * $ php runtest.php
 *
 * By default, all tests listed in "listtest" file are done in
 * paralelle. A request is sent to the web server by using "wget"
 * utility. All requests are sent unsyncron. There's a random delay
 * between all request. This delay is set in the "MAX_WAIT" define.
 *
 * Most of the time, all requests are not finished when the script
 * have processed them all. The script will wait until ALL requests
 * are done.
 *
 * When all resquest are DONE, the script compare all request results
 * with it's own copy in "ValidationData" directory. A report will be
 * displayed at the end of the script execution telling the user wich
 * files had changed or not.
 *
 * D file1
 * D file2
 * I file3
 * D file4
 *
 * In this example only "file3" is identical. User should check if the
 * differences with file1,2 and 4 are trivial or not. If user find some
 * differences that are OK, then he should copy the more recent file in
 * "ValidationData" directory to make sure the next test will not see a 
 * difference.
 */

define("MAX_WAIT", "100000"); // Maximum random wait time (1/1000000sec) 
                              // between requests.


echo "Start all requests as background processes...\n";
$aszRequest = ExecuteRequests(MAX_WAIT);

echo "\nWait until all requests are done...\n";
WaitAllBackgroundRequests($aszRequest);

echo "\nCheck differences with request results and ValidationData...\n";
$aDiff = CheckDifferences();

echo "\nResults:\n";
ShowResults($aDiff);
echo "\n";
CheckForBroken();
echo "\nFinished\n\n";

function CheckForBroken()
{
    $handle=opendir("/tmp/runtest_workdir/");
    while ($file = readdir($handle))
    {
        if($file=='.'||$file=='..')
            continue;

        if(is_dir("/tmp/runtest_workdir/".$file))
            continue;
        else
        {
            $aszFile = file("/tmp/runtest_workdir/".$file);
            if (!is_array($aszFile) || count($aszFile) <= 1)
                echo $file." is broken.\n";
        }
    }
    closedir($handle);
}

function CheckDifferences()
{
    exec("rm diff.txt");

    system("diff -r /tmp/runtest_workdir ./ValidationData > diff.txt");

    // For each line of difference, check if it's really a difference
    $aszDiff = file("diff.txt");
    $nDiff = count($aszDiff);
    $aDiff=array();

    for($j=0;$j<$nDiff;$j++)
    {
        $szDiff = $aszDiff[$j];

        // If line start with "diff" parse the module name
        if (substr($szDiff, 0, 4) == "diff")
        {
            $aszTest = explode(" ", $szDiff);
            $szTest = substr($aszTest[2], 1+strrpos($aszTest[2], "/"));
            $aDiff[$szTest][0] = true;
        }
        else
        if (substr($szDiff, 0, 4) == "Only")
        {
            $aszTest = explode(" ", $szDiff);
            $szTest = trim($aszTest[3]);
            if ($szTest != "CVS")
                $aDiff[$szTest][0] = true;
        }
        else
        if (strstr($szDiff, "LOAD_TIME: ") !== false)
        {
            $aTime = explode(" ", $szDiff);
            $aDiff[$szTest][1] = trim($aTime[2]);
        }
        else
        if (substr($szDiff, 0, 1) == ">" || 
            substr($szDiff, 0, 1) == "<")
        {
            $aDiff[$szTest][0] = CheckExceptions($szDiff);
        }

        echo "\r[".str_repeat("=", (1+$j)*50/$nDiff).str_repeat(" ", 50-((1+$j)*50/$nDiff))."] % ". round((1+$j)*100/$nDiff);
    }

    echo "\n";

    return $aDiff;
}

function ShowResults($aDiff)
{
    // Show results
    foreach($aDiff as $szKey => $aVal)
    {
        if ($aVal[0])
            echo "D ".str_pad($szKey, 25).round($aVal[1],2)." secs\n";
        else
            echo "I ".str_pad($szKey, 25).round($aVal[1],2)." secs\n";
    }
    
    if (count($aDiff) == 0)
      echo "\nEverything is identical :)\n";
}

function CheckExceptions($szDiff)
{
    if (strpos($szDiff, "dummy") === false)
        if (strpos($szDiff, "sid=") === false)
            if (strpos($szDiff, "=sid") === false)
                if (strpos($szDiff, "LOAD_TIME:") === false)
                    return true;

    return false;
}

function WaitAllBackgroundRequests($aszRequest)
{
    $bWait = true;

    while ($bWait)
    {
        $bWait = false;
        clearstatcache();
        sleep(1);
        echo ".";

        foreach ($aszRequest as $szRequest)
        {
            if (!file_exists("/tmp/runtest_workdir/".$szRequest) || filesize("/tmp/runtest_workdir/".$szRequest) == 0)
              $bWait = true;
        }
    }
    echo "\n";
}

function ExecuteRequests($nElapseTime=1000000)
{
    // remove last test results
    exec("rm -f -r /tmp/runtest_workdir");

    // Make directory for test results
    exec("mkdir /tmp/runtest_workdir");

    // Open list of url to test
    $aszTests = file("listtests");
    $aszRequest = array();

    $nTest = count($aszTests);
    for($j=0;$j<$nTest;$j++)
    {
        $szTest = $aszTests[$j];
        
        if (trim($szTest) == "")
          continue;

        if (substr(trim($szTest),0,1) == "#")
          continue;

        usleep(rand(1, $nElapseTime));
        $aszTest = explode("|", $szTest);
        
        // make sure the url dont contain spaces
        $aszTest[1] = str_replace(" ", "+", $aszTest[1]);

        echo "\r[".str_repeat("=", (1+$j)*50/$nTest).str_repeat(" ", 50-((1+$j)*50/$nTest))."] % ". round((1+$j)*100/$nTest);
        
        // Get test url in background
        exec("php wget.php \"QUERY_STRING=&szTestName=".$aszTest[0].
             "&szTestURL=".urlencode($aszTest[1])."\" > out &");
        
        // Keep last test
        array_push($aszRequest, $aszTest[0]);
    }

    echo "\n";

    return $aszRequest;
}
?>
