// You can find instructions for this file here:
// http://www.treeview.net



foldersTree = gFld("<i>Bill's Demo</i>");
  aux1xx = insFld(foldersTree, gFld("Application example", "demoFramesetRightFrame.html"));
    aux2 = insFld(aux1xx, gFld("United States", "http://www.treeview.net/treemenu/demopics/beenthere_america.gif"));
      insDoc(aux2, gLnk("S", "Boston-duh", "javascript:goBob()"));
      insDoc(aux2, gLnk("S", "New York", "javascript:goBob()"));
      insDoc(aux2, gLnk("R", "Washington", "http://www.treeview.net/treemenu/demopics/beenthere_washington.jpg"));