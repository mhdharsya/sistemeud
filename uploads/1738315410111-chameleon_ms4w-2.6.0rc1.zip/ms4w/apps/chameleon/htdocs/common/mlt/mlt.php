<?php
/**
  _____________________________________________________________________________
 |
 | Multi-Lingual Translator Module
 |
 | @project     PHP Utilities
 | @revision    $Id: mlt.php,v 1.27 2006/04/13 14:38:08 jlacroix Exp $
 | @purpose     This file contains functions to support multiple language
 |              translations in php generated documents.
 | @author      William A. Bronsema, C.E.T. (wbronsema@dmsolutions.ca)
 | @copyright
 | <b>Copyright (c) 2001-2005 DM Solutions Group Inc.</b>
 | Permission is hereby granted, free of charge, to any person obtaining a
 | copy of this software and associated documentation files (the "Software"),
 | to deal in the Software without restriction, including without limitation
 | the rights to use, copy, modify, merge, publish, distribute, sublicense,
 | and/or sell copies of the Software, and to permit persons to whom the
 | Software is furnished to do so, subject to the following conditions:
 |
 | The above copyright notice and this permission notice shall be included
 | in all copies or substantial portions of the Software.
 |
 | THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 | IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 | FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 | THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 | LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 | FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 | DEALINGS IN THE SOFTWARE.
 |_____________________________________________________________________________

 **/

/**
  _____________________________________________________________________________
 |
 |  MLT Class
 |
 |  Postcondition:  This class provides the functionality to support any number of languages
 |                  in a php generated document.
 |
 |  @author William A. Bronsema, C.E.T. (wbronsema@dmsolutions.ca)
 |_____________________________________________________________________________

 **/

class MLT
{
    // define the current resource language (private).
    var $szLanguage;

    // define the current array of values to use for translation (private).
    var $aszMLT;

    // define Error Stack
    var $maszErrorStack;

   /**
      _________________________________________________________________________
     |
     |  MLT()
     |
     |  Postcondition:  This is the MLT class constructor funtion.  It will
     |                  construct a new MLT instance and initialize it.
     |
     |  @param szLanguage string - The language to return in the get function.
     |  @desc MLT class constructor.
     |  @return void.
     |_________________________________________________________________________

    **/
    function MLT( $szLanguage='' )
    {
        // initialize variables
        $this->szLanguage = preg_replace("/(\W)/", "_", $szLanguage );
        $this->aszMLT = array();
        $this->maszErrorStack = array();

    // end constructor
    }

   /**
      _________________________________________________________________________
     |
     |  setLanguage()
     |
     |  Postcondition:  This function sets the language to return.
     |
     |  @param szLanguage integer - The language to return.
     |  @desc Sets the language tp return.
     |  @return void.
     |_________________________________________________________________________

    **/
    function setLanguage( $szLanguage )
    {
        // set the current language
        $this->szLanguage =  preg_replace("/(\W)/", "_", $szLanguage );

    // end setLanguage function
    }

   /**
      _________________________________________________________________________
     |
     |  error()
     |
     |  Postcondition:  This function adds the given error message to the
     |                  stack of errors.
     |
     |  @param $szMessage string - Error message to add.
     |  @desc Adds given error message to stack.
     |  @return void.
     |_________________________________________________________________________

    **/
    function error( $szMessage )
    {
        array_push( $this->maszErrorStack, $szMessage );

    // end error() function
    }

   /**
      _________________________________________________________________________
     |
     |  get()
     |
     |  Postcondition:  This function returns the value for the key requested
     |                  in the language specified.
     |
     |  @param $szKey string - The key of the resource to return.
     |  @param $szDefault string - Optional string to return if function fails.
     |  @param $aszParams array - List of parameters that, when supplied,
     |                            will cause the resource string to be passed
     |                            through the vsprintf function using those
     |                            parameters.
     |  @desc Get the language string for the given key.
     |  @return string - The resource requested or the default string on
     |                   failure.
     |_________________________________________________________________________

    **/
    function get( $szKey, $szDefault = "", $aszParams = array() )
    {
        // check if the language has been set
        if ( !isset($this->szLanguage) )
        {
            // log error
            $this->error( "Notice: Language not set.  Cannot translate ".
                        "requested key[".$szKey."].  The default string[".
                        $szDefault."] will be returned" );

            // return default
            return $szDefault;
        }

        // check for resource in array
        $szResource = isset($this->aszMLT[$this->szLanguage][$szKey])?
                        $this->aszMLT[$this->szLanguage][$szKey] : $szDefault;

        // check if needs to pass through vsprintf
        if ( count( $aszParams ) > 0 )
        {
            // pass through the vsprintf function
            eval('$szResource = vsprintf( $szResource, $aszParams );');
        }

        // return results
        return $szResource;

    // end get() function
    }

// end MLT class
}

/**
  _____________________________________________________________________________
 |
 |  MLTdBase Class
 |
 |  This class extends the MLT class by allowing the loading of dBASE specific
 |  resources.
 |
 |  @author William A. Bronsema, C.E.T. (bronsema@dmsolutions.ca)
 |_____________________________________________________________________________

 **/
class MLTdBase extends MLT
{
    // define the resource file member variable
    var $mszResourceFile;

    /**
      _________________________________________________________________________
     |
     |  MLTdBase()
     |
     |  Postcondition:  This is the MLTdBase constrctor function.  It will
     |                  construct a new MLTdBase instance and initialize it.
     |
     |  @param szLanguage string - The language to return in the get function.
     |_________________________________________________________________________

     **/
    function MLTdBase( $szLanguage )
    {
        // ensure that the dbase mdoule is loaded
        if (!extension_loaded("dbase")) dl("php_dbase.".PHP_SHLIB_SUFFIX);

        // call the MLT constructor
        $this->MLT( strtoupper($szLanguage) );

    // end constructor
    }

    /**
      _________________________________________________________________________
     |
     |  loadResource()
     |
     |  Postcondition:  This function populates the aszMLT array with all
     |                  resources in the requested language(s).
     |
     |  @param $szName string - The path and filename of the dBase file to load.
     |  @param $mLang mixed - Optional language(s) to load.  If not given then
     |                        the current language will be used.  This
     |                        parameter can be a string or an array.
     |  @return boolean - True if successful, False if not.
     |  @desc load the requested language(s) into memory.
     |_________________________________________________________________________

     **/
    function loadResource( $szName, $mLang = "" )
    {
        // set the resource file
        $this->mszResourceFile = $szName;

        // check if there is a valid language to use
        if ( $mLang == "" )
        {
            // check if current language is set
            if ( $this->szLanguage == "" )
            {
                // give error and return
                $this->error( "Critical Error:  No langauge is set." );
                return false;
            }
        }

        // try to open the database (surpress error if open fails)
        $db = @dbase_open( $szName, 0 );

        // check for failure
        if ( $db == false )
        {
            // log error and return
            $this->error( "Critical Error:  Unable to open dBase file[".$szName.
                          "]." );
            return false;
        }

        if ($mLang != "" && !is_array($mLang))
        {
            $mLang = preg_replace("/(\W)/", "_", $mLang);
        }
        elseif ($mLang != "")
        {
            // if array size is 0, back to szLanguage
            if (sizeof($mLang) == 0)
            {
              $mLang = $this->szLanguage;
            }
            else
            {
              foreach ($mLang as $szKey => $szLang)
              {
                $mLang[$szKey] = preg_replace("/(\W)/", "_", $szLang);
              }
            }
        }

        // loop through each record and populate the array
        for ( $i=1; $i <= dbase_numrecords( $db ); $i++ )
        {
            // get next record
            $aRec = dbase_get_record_with_names($db, $i);

            // skip if this record is "deleted"
            if ( $aRec["deleted"] != 1 )
            {
                // check if the language was supplied
                if ( $mLang == "" )
                {
                    if(!isset($aRec[strtoupper($this->szLanguage)]))
                        $aRec[strtoupper($this->szLanguage)] = "";
                    // use current language
                    $this->aszMLT[strtoupper($this->szLanguage)][trim($aRec["KEY"])] =
                                         $aRec[strtoupper($this->szLanguage)];
                }
                elseif ( is_array( $mLang ) )
                {
                    foreach ( $mLang as $szLang )
                    {
                        if(!isset($aRec[strtoupper($szLang)]))
                            $aRec[strtoupper($szLang)] = "";
                        $this->aszMLT[strtoupper($szLang)][trim($aRec["KEY"])] =
                                                 $aRec[strtoupper($szLang)];
                    }
                }
                else
                {
                    if(!isset($aRec[strtoupper($mLang)]))
                        $aRec[strtoupper($mLang)] = "";
                    // use the given language
                    $this->aszMLT[strtoupper($mLang)][trim($aRec["KEY"])] = $aRec[strtoupper($mLang)];
                }

                // end deleted record check
            }

            // end for loop
        }

        // return success
        return true;

        // end loadResource function
    }

// end of MTLdBase class
}

/**
  _____________________________________________________________________________
 |
 |  MLTPHPInclude Class
 |
 |  This class extends the MLT class by allowing the loading textfile language
 |  resources.
 |
 |  @author William A. Bronsema, C.E.T. (wbronsema@dmsolutions.ca)
 |_____________________________________________________________________________

 **/
class MLTPHPInclude extends MLT
{
    // create the context mode member var
    var $mbContextMode;

    // create nocache member var
    var $mbNoCache;

    // create include dir member var
    var $mszIncludeFile;

    // create the language member var
    var $maszLanguage;

    // create the resource file member var
    var $mszResourceFile = '';
    
    /**
      _________________________________________________________________________
     |
     |  MLTPHPInclude()
     |
     |  Postcondition:  This is the MLTPHPInclude constrctor function.  It will
     |                  construct a new MLTPHPInclude instance and initialize
     |                  it.
     |
     |  @param $szIncludeFile string - Path and filename of the include file.
     |  @param $xLanguage mixed - Single or array of language files to load.
     |  @param $bContextMode boolean - Flag to indicate if the index should
     |                                 be appended to the translation.  This
     |                                 allows the user to see the translations
     |                                 in context.
     |  @param $bNoCache boolean - Flag to indicate if caching is to be used.
     |  @return void.
     |  @desc Constructor function to intialize the class.
     |_________________________________________________________________________

     **/
    function MLTPHPInclude( $szIncludeFile, $xLanguage, $bNoCache,
                                                        $bContextMode=false )
    {
        // call the parent constructor
        parent::MLT();

        // set the context mode
        $this->mbContextMode = $bContextMode;

        // set cache mode
        $this->mbNoCache = $bNoCache;

        // set include file
        $this->mszIncludeFile = $szIncludeFile;

        // check if language is an array
        if ( is_array( $xLanguage ) )
        {
            $aszLanguage = $xLanguage;
        }
        else
        {
            $aszLanguage = array();
            array_push( $aszLanguage,$xLanguage );
        }

        // set language
        $this->maszLanguage = $aszLanguage;
        if ( isset( $aszLanguage[0] ) ) $this->szLanguage = $aszLanguage[0];

        // check if the php file exists
        if ( file_exists( $szIncludeFile ) )
        {
            // only include the file if cache is on
            if ( !$bNoCache )
            {
                // include the php file(s)
                include( $szIncludeFile );
            }
        }

    // end MLTPHPInclude() function
    }

    /**
      _________________________________________________________________________
     |
     |  loadResource()
     |
     |  Postcondition:  This function loads the given resource file.
     |
     |  @param $szID string - Context id for the resource.
     |  @param $szResourceDir string - (Optional)Path containing resource files.
     |  @return void.
     |  @desc Load given resource.
     |_________________________________________________________________________

     **/
    function loadResource( $szID, $szResourceDir = './' )
    {
        // init vars
        $bSaveFile = false;

        $this->mszResourceFile = $szID;
        
        // loop through each language      
        $nCount = count( $this->maszLanguage );
        for ( $i=0; $i<$nCount; $i++ )
        {
            // check if the id is set in the array per language
            if ( !isset( $this->aszMLT[$szID][$this->maszLanguage[$i]] ) )
            {
                // add context item if nexessary
                if ( !isset( $this->aszMLT[$szID] ) )
                {
                    $this->aszMLT[$szID] = array();
                }

                // create entry for the language
                $this->aszMLT[$szID][$this->maszLanguage[$i]] = array();

                // build full file resource name
                $szResourceFile = str_replace( '\\', '/', $szResourceDir );
                $szResourceFile .= substr( $szResourceFile, -1 ) != '/'?'/':'';
                $szResourceFile .= $szID.'.'.$this->maszLanguage[$i].'.txt';

                // process the file into the array
                $this->processFile( $szResourceFile,
                            $this->aszMLT[$szID][$this->maszLanguage[$i]] );
                // set flag
                $bSaveFile = true;
            }
        }

        // save file as necessary
        if ( $bSaveFile && !$this->mbNoCache )
        {
            // write the MLT array to the include file
            $this->arrayToFile();
        }

    // end loadResource() function
    }

    /**
      _________________________________________________________________________
     |
     |  processFile()
     |
     |  Postcondition:  This function processes the given resource file into
     |                  the MLT array.
     |
     |  @param $szResourceFile string - Textfile input.
     |  @param $aszMLT array - resource array to populate.
     |  @return boolean - True if successful, false if not.
     |  @desc Process given resource file into the MLT array.
     |_________________________________________________________________________

     **/
    function processFile( $szResourceFile, &$aszMLT )
    {
        // check if resource file exists
        if ( !file_exists( $szResourceFile ) )
        {
            // give error
            $this->error( 'Critical:  Resource file ['.$szResourceFile.
                                                        '] does not exist' );
            return false;
        }

        // attempt to open the resource file
        if ( !( $fp = fopen( $szResourceFile, "r" ) ) )
        {
            // give error
            $this->error( 'Critical:  Unable to open esource file ['.
                                                    $szResourceFile.']' );
            return false;
        }

        // file is open so parse each entry
        while( $fp && !feof( $fp ) )
        {
            // get next line
            $line = fgets( $fp, 4096 );

            // trim() strips off whitespaces and \r and \n
            $line = trim( $line );
            if ( strlen( $line ) > 0 )
            {
                //  only process lines that start with the format "[index])"
                $aszPieces = explode( ')', $line );
                if ( count( $aszPieces ) > 1 && substr( $line, 0, 2 ) != '//' )
                {
                    // add to the array
                    $aszMLT[$aszPieces[0]] =
                                   substr( $line, strpos( $line, ')' ) + 1 );
                }
            }
        }

        // close the resource file
        fclose( $fp );

        // return success
        return true;

    // end processFile() function
    }

    /**
      _________________________________________________________________________
     |
     |  setLanguage()
     |
     |  Postcondition:  This function sets the language to return.
     |
     |  @param szLanguage integer - The language to return.
     |  @desc Sets the language tp return.
     |  @return void.
     |_________________________________________________________________________

    **/
    function setLanguage( $szLanguage )
    {
        // set the current language
        $this->szLanguage =  $szLanguage;

    // end setLanguage function
    }

   /**
      _________________________________________________________________________
     |
     |  get()
     |
     |  Postcondition:  This function returns the value for the key requested
     |                  in the language specified.
     |
     |  @param $szID string - The id of the resource to return.
     |  @param $szKey string - The key of the resource to return.
     |  @param $szDefault string - Optional string to return if function fails.
     |  @param $aszParams array - List of parameters that, when supplied,
     |                            will cause the resource string to be passed
     |                            through the vsprintf function using those
     |                            parameters.
     |  @desc Get the language string for the given key.
     |  @return string - The resource requested or the default string on
     |                   failure.
     |_________________________________________________________________________

    **/
    function get( $szID, $szKey = "", $szDefault = "", $aszParams = array(), 
                                                               $szLanguage='' )
    {
        // Validate the parameters to check if the call to get()
        // was formated to be for the MLTdBase
        // The old prototype is:
        // get( $szKey, $szDefault = "", $aszParams = array() )
        if(($szDefault == '' || is_array($szDefault)) && 
           count($aszParams) == 0 && $szLanguage == '')
        {
            // It's a dBase call if szID is a number (a key) and 
            // aszKey is a string (a default value)
            if(intval($szID) == $szID && 
               ($szKey == '' || intval($szKey) != $szKey))
            {
                if(is_array($szDefault))
                    $aszParams = $szDefault;
                $szDefault = $szKey;
                $szKey = $szID;
                // Set the ID from the parent class name
                $szID = $this->mszResourceFile;
            }
        }

        if($szKey == "")
            return $szDefault;

        // check if the language has been passed
        if ( $szLanguage == '' )
        {
            // get the string
            $szReturn =
                isset( $this->aszMLT[$szID][$this->szLanguage][$szKey] )?
                $this->aszMLT[$szID][$this->szLanguage][$szKey] :
                $szDefault;
        }
        else
        {
            $szReturn =
                isset( $this->aszMLT[$szID][$szLanguage][$szKey] )?
                $this->aszMLT[$szID][$szLanguage][$szKey] :
                $szDefault;
        }

        // check if needs to pass through vsprintf (urlencoded strings
        // prevented this from happening in parent::get())
        if ( count( $aszParams ) > 0 )
        {
            // pass through the vsprintf function
            eval('$szReturn = vsprintf( $szReturn, $aszParams );');
        }

        // check context mode
        $szReturn .= $this->mbContextMode?' ('.$szKey.')':'';

        // return value
        return $szReturn;

    // end get() function
    }

    /**
      _________________________________________________________________________
     |
     |  getAll()
     |
     |  Postcondition:  This function returns all resources for a given ID and
     |                  language.
     |
     |  @desc $szID string - ID to return values for.
     |  @desc $sLanguage string - Language to return values for.
     |  @desc Return array of resources for given ID and language.
     |  @return array - Array of resource values.
     |_________________________________________________________________________

    **/
    function getAll( $szID, $szLanguage )
    {
        // check if the ID has been set
        if ( isset( $this->aszMLT[$szID][$szLanguage] ) )
        {
            // return the array
            return $this->aszMLT[$szID][$szLanguage];
        }
        else
        {
            // given error
            $this->error( 'Error:  ID['.$szID.'] and/or language ['.$szLanguage.
                                            '] not found in getAll() request.' );

            // return
            return array();
        }

    // end getAll() function
    }

    /**
      _________________________________________________________________________
     |
     |  arrayToFile()
     |
     |  Postcondition:  This function converts the in memory MLT array to a
     |                  cached file.
     |
     |  @desc Creates cache file.
     |  @return boolean - True if successful, false if not.
     |_________________________________________________________________________

    **/
    function arrayToFile()
    {
        // init vars
        $szBuffer = '<?php'."\n";

        // loop through outer context dimension
        foreach ( $this->aszMLT as $szContextKey=>$aszContext )
        {
            // add entry
            $szBuffer .= '$this->aszMLT[\''.$szContextKey.'\'] = array();'."\n";

            // loop through each language dimension
            foreach ( $aszContext as $szLanguageKey=>$aszLanguage )
            {
                // add entry
                $szBuffer .= '$this->aszMLT[\''.$szContextKey.'\'][\''.
                                          $szLanguageKey.'\'] = array();'."\n";

                // loop through each resource
                foreach ( $aszLanguage as $szResourceKey=>$szResource )
                {
                    // add entry
                    $szBuffer .= '$this->aszMLT[\''.$szContextKey.'\'][\''.
                        $szLanguageKey.'\'][\''.$szResourceKey.'\'] = \''.
                        str_replace( array("\\","'"),
                                     array("\\\\", "\'"),
                                     $szResource ) .'\';'."\n";

                }
            }
        }

        // close buffer
        $szBuffer .= '?>'."\n";

        // open the include file and write
        if ( !( $fp = fopen( $this->mszIncludeFile, "w" ) ) )
        {
            // give error
            $this->error( 'Critical:  Unable to open or create file ['.
                                                 $this->mszIncludeFile.']' );
            return false;
        }

        // write the buffer to the file
        fwrite( $fp, $szBuffer );

        // close the file
        fclose( $fp );

        // return success
        return true;

    }

// end MLTPHPInclude Class
}

/**
  _____________________________________________________________________________
 |
 |  MLTPHPIncludeDefault Class
 |
 |  This class is used to return the default value and essentiall by-pass
 |  the translation process.  This is for speed purposes.
 |
 |  @author William A. Bronsema, C.E.T. (wbronsema@dmsolutions.ca)
 |_____________________________________________________________________________

 **/
class MLTPHPIncludeDefault extends MLT
{
    // create the context mode member var
    var $mbContextMode;

    // create nocache member var
    var $mbNoCache;

    // create include dir member var
    var $mszIncludeFile;

    // create the language member var
    var $maszLanguage;

    /**
      _________________________________________________________________________
     |
     |  MLTPHPIncludeDefault()
     |
     |  Postcondition:  This is the MLTPHPInclude constrctor function.  It will
     |                  construct a new MLTPHPInclude instance and initialize
     |                  it.
     |
     |  @param $szIncludeFile string - Path and filename of the include file.
     |  @param $xLanguage mixed - Single or array of language files to load.
     |  @param $bContextMode boolean - Flag to indicate if the index should
     |                                 be appended to the translation.  This
     |                                 allows the user to see the translations
     |                                 in context.
     |  @param $bNoCache boolean - Flag to indicate if caching is to be used.
     |  @return void.
     |  @desc Constructor function to intialize the class.
     |_________________________________________________________________________

     **/
    function MLTPHPIncludeDefault()
    {

    // end MLTPHPIncludeDefault() function
    }

    /**
      _________________________________________________________________________
     |
     |  loadResource()
     |
     |  Postcondition:  This function loads the given resource file.
     |
     |  @param $szID string - Context id for the resource.
     |  @param $szResourceDir string - (Optional)Path containing resource files.
     |  @return void.
     |  @desc Load given resource.
     |_________________________________________________________________________

     **/
    function loadResource( $szID, $szResourceDir = './' )
    {

    // end loadResource() function
    }

   /**
      _________________________________________________________________________
     |
     |  get()
     |
     |  Postcondition:  This function returns the value for the key requested
     |                  in the language specified.
     |
     |  @param $szID string - The id of the resource to return.
     |  @param $szKey string - The key of the resource to return.
     |  @param $szDefault string - Optional string to return if function fails.
     |  @param $aszParams array - List of parameters that, when supplied,
     |                            will cause the resource string to be passed
     |                            through the vsprintf function using those
     |                            parameters.
     |  @desc Get the language string for the given key.
     |  @return string - The resource requested or the default string on
     |                   failure.
     |_________________________________________________________________________

    **/
    function get( $szID, $szKey, $szDefault = "", $aszParams = array(),
                                                               $szLanguage='' )
    {
        // return default value
        return $szDefault;

    // end get() function
    }

// end MLTPHPIncludeDefault Class
}
?>
