<?php
    if (!extension_loaded("dbase")) dl("php_dbase.dll");
	define( "DBF_FILE", "resource.dbf" );
 	if ( file_exists( DBF_FILE ) ) unlink;
    $defs = array();
    array_push( $defs, array( "KEY",  "C", 25) );
	array_push( $defs, array( "EN-CA",  "C", 255) );
    array_push( $defs, array( "FR-CA",  "C", 255) );
 	dbase_create( DBF_FILE, $defs );
	echo "Process complete. ".date("[D.M.d.Y.G:i:s]");
?>