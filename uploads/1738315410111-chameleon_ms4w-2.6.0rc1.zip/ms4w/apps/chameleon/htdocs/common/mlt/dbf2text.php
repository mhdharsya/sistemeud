<?php
    // load extension
    if ( !extension_loaded( 'dbase' ) ) dl( 'php_dbase.'.PHP_SHLIB_SUFFIX );

    // check if a file has been passed
    if ( isset( $_REQUEST['txtDBFFile'] ) && isset( $_REQUEST['bUpdate'] ) &&
                                                    $_REQUEST['bUpdate'] == '1' )
    {
        // get file name
        $szFilename = rawurldecode( $_REQUEST['txtDBFFile'] );
      
        // open the dbase file
        $oDB = dbase_open( $szFilename, 0 );
        
        // get the number of records
        $nRecs = dbase_numrecords( $oDB );
        
        // only process if there are records
        if ( $nRecs > 0 )
        {
            // get the list of fields
            $aRec = dbase_get_record_with_names( $oDB, 1 );            
            
            // dump deleted and key fields
            array_pop( $aRec );
            array_shift( $aRec );

            // loop each language and build a text file
            foreach ( $aRec as $key=>$value )
            {
                // get the language name
                $szLanguage = strtolower( str_replace( '_', '-', $key ) );
                
                // build the new filename
                $szTextFile = substr( $szFilename, 0, -3 ).$szLanguage.'.txt';
               
                // loop and build textfile
                $szBuffer = '';
                for ( $i=1; $i<=$nRecs; $i++ )
                {
                    // get the next record
                    $aRec2 = dbase_get_record_with_names( $oDB, $i );
                    
                    // add record to file
                    $szBuffer .= trim( $aRec2['KEY'] ).')'.trim( $aRec2[$key] )."\n";
                }
                
                // open the file
                $fp = fopen( $szTextFile, "w" );
                
                // write the buffer to the file  
                fwrite( $fp, $szBuffer );
        
                // close the file
                fclose( $fp );
            }
        }
        
        // close dbase file
        dbase_close( $oDB );
        
        // done
        echo "Process complete. ".date("[D.M.d.Y.G:i:s]");
    }
   
?>

<html>
<head>
<script language="javascript">
function getFile()
{
    document.forms[0].txtDBFFile.value = escape(document.forms[0].txtBrowse.value);
    document.forms[0].bUpdate.value = 1;
    document.forms[0].submit();
}
</script>
</head>
<body>
<form name="main" method="POST" enctype="multipart/form-data">
  <input type="file" name="txtBrowse" size="80">
  <input type="hidden" name="txtDBFFile">
  <input type="hidden" name="bUpdate" value="0">
  <input type="button" name="txtSubmit" value="Go" onmouseup="javascript:getFile()" onkeyup="javascript:getFile()">
</form>
</body>
</html>