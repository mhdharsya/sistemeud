<?php
/**
 *
 * @project     Chameleon
 * @revision    $Id: $
 * @purpose     hit counter for chameleon installations
 * @author      Jacob Delfos
 * @copyright
 * <b>Copyright (c) 2004, Jacob Delfos</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */


# Constants for dbf field types
define ('BOOLEAN_FIELD',   'L');
define ('CHARACTER_FIELD', 'C');
define ('DATE_FIELD',      'D');
define ('NUMBER_FIELD',    'N');

# Constants for dbf file open modes
define ('READ_ONLY',  '0');
define ('WRITE_ONLY', '1');
define ('READ_WRITE', '2');




function doStats ()
{
    $db_file = COMMON."hitcounter/stats/accesslog.dbf";

    if (!extension_loaded("dbase"))
    dl("php_dbase.".PHP_SHLIB_SUFFIX);

    clearstatcache();
    if ( !file_exists($db_file) )
    {
        //echo "statistic file created";
        $dbase_definition = array (
        array ('host',  CHARACTER_FIELD,  18),  # string
        array ('identity',  CHARACTER_FIELD,  150),  # string
        array ('user',  CHARACTER_FIELD,  100),  # string
        array ('weekday',  CHARACTER_FIELD, 3),            # date yyymmdd
        array ('date',  CHARACTER_FIELD, 11),            # date yyymmdd
        array ('time',  CHARACTER_FIELD, 9),            # date yyymmdd
        //array ('count',  NUMBER_FIELD, 5, 0),   # number (length, precision)
        array ('browser',  CHARACTER_FIELD,  150),  # string
        array ('referrer',  CHARACTER_FIELD,  200)  # string
        );

        dbase_create($db_file, $dbase_definition);
    }

    $db = @ dbase_open ($db_file, READ_WRITE); // or die ("Could not open dbf file <i>$db_file</i>.");
    $referer = (isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : "");
    $remoteuser = (isset($_SERVER['REDIRECT_REMOTE_USER']) ? $_SERVER['REDIRECT_REMOTE_USER'] : "");
    $remotehost = (isset($_SERVER['REMOTE_HOST']) ? $_SERVER['REMOTE_HOST'] : "");
    $remoteIP = $_SERVER['REMOTE_ADDR'];
    //$localIP = strpos("127.0.0.1", $remoteIP);  //use this to prevent your own IP from showing up; put your IP addresses in the list


    $newrecord= array ($remoteIP, $remotehost, $remoteuser, date("D"), date("Y-m-d"), date("G:i:s"), $_SERVER["HTTP_USER_AGENT"], $referer);

    //if ($localIP === false) // prevent own IP from showing
    //{
    dbase_add_record ($db, $newrecord); // or die ("Could not add record to dbf file <i>$db_file</i>.");
    //}

    dbase_close($db);
}
?>