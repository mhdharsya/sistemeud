<?php

// test the logfile
include_once("../logfile.php");

// create new object
$oLogFile = new LogFile("/tmp/test.log", LOG_TO_FILE, 0);

// read log level
echo "Current log level: ".$oLogFile->getMaxLogLevel()."<BR>";

// set log level
$oLogFile->setMaxLogLevel(2);

// read log level
echo "New log level: ".$oLogFile->getMaxLogLevel()."<BR>";

// write an message to file
$oLogFile->logMessage(1, "Hello World");
echo "Wrote 'Hello World' to '/tmp/test.log'<BR>";

/*// create new object
$oLogFile = new LogFile("bronsema@sympatico.ca", LOG_TO_EMAIL, LOG_OFF);

// read log level
echo "Current log level: ".$oLogFile->getMaxLogLevel()."<BR>";

// set log level
$oLogFile->setMaxLogLevel(LOG_VERBOSE);

// read log level
echo "New log level: ".$oLogFile->getMaxLogLevel()."<BR>";

// write an message to file
$oLogFile->logMessage(LOG_QUIET, "Hello World");
echo "Wrote 'Hello World' to 'bronsema@sympatico.ca'<BR>";
*/

?>
