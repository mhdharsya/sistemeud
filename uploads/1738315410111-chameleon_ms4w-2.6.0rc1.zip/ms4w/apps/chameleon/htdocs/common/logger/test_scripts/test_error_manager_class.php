<?php

// test the error
include_once("../error_manager.php");

// create new object
$oErrorM = new ErrorManager();

// add some errors
$oErrorM->setError(1,"type one error message");
$oErrorM->setError(2,"type two error message");
$oErrorM->setError(3,"type three error message");
$oErrorM->setError(4,"type four error message");

// check the error count
echo "Error count should be 4 it is actually: ";
echo $oErrorM->nErrorCount."<BR>";

// report last error
$oError = $oErrorM->getLastError();
echo "Last error: Type = ".$oError->nErrorType." Message = ".$oError->szMessage.
     "<BR>";

// add more
echo "Add two more<BR>";
$oErrorM->setError(5,"type five error message");
$oErrorM->setError(6,"type six error message");

// report 5th error (zero based)
$oError = $oErrorM->getError(4);
echo "Fifth error: Type = ".$oError->nErrorType." Message = ".$oError->szMessage.
     "<BR>";

// pop last error
$oError = $oErrorM->popLastError();
echo "POP Last error: Type = ".$oError->nErrorType." Message = ".$oError->szMessage.
     "<BR>";
echo "New count: ".$oErrorM->nErrorCount."<BR>";
     
// reset
$oErrorM->reset();
echo "Reset.  Count now is: ".$oErrorM->nErrorCount."<BR>";
?>