<?php

// test the logfile
include_once("../logfile.php");
include_once("../logger.php");
include_once("../error_manager.php");

// create new logfile object
$oLogFile = new LogFile("D:/junk/test.log", LOG_TO_FILE, 0);

// create new logfile object
$oErrorManager = new ErrorManager();

// create new logger object
$oLogger = new Logger( "My_Test_Class" );

// set the logger logfile object
$oLogger->setLogFile( $oLogFile );

// set the max level
$oLogger->oLogFile->setMaxLogLevel( 4 );

// log away!
$oLogger->log ( 0, "Level 0 Message" );
$oLogger->log ( 1, "Level 1 Message" );
$oLogger->log ( 2, "Level 2 Message" );
$oLogger->log ( 3, "Level 3 Message" );
$oLogger->log ( 4, "Level 4 Message" );
$oLogger->log ( 5, "Level 5 Message" );
$oLogger->log ( 6, "Level 6 Message" );

// set the error manager in the logger
$oLogger->setErrorManager( $oErrorManager );

// set error message
$oLogger->error ( 0, "Level 0 Error" );
$oLogger->error ( 1, "Level 1 Error" );
$oLogger->error ( 2, "Level 2 Error" );
$oLogger->error ( 3, "Level 3 Error" );

// read last error
$oError = $oErrorManager->getLastError();
echo "Last error filed is: TYPE = ".$oError->nErrorType.
                      " MESSAGE = ".$oError->szMessage."<BR>";

// give message that something happened
echo "Done<BR>";

?>
