<?php
/**
 * Help Topics Classes
 * 
 * @project     php_utils
 * @revision    $Id: helptopics_class.php,v 1.2 2004/05/31 18:14:05 gdallaire Exp $
 * @purpose     Classes to manage help topic objects.
 * @author      William A. Bronsema, C.E.T. (bronsema@dmsolutions.ca)
 * @copyright
 * <b>Copyright (c) 2002, DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/******************************************************************************/

class HelpTopics
{
    // define class member variables
    var $m_anMajorIDs = array();  // array of major help topic IDs 
    var $m_aoTopic = array();     // array of help topic objects
    var $m_szTopicFile = "";      // path and filename of the topic textfile
    var $m_szTreeView = "";       // treeview string
    
    /**
     * Default constructor.
     *
     * @return void.
     **/
    function HelpTopics()
    {
       
        
    // end constructor HelpTopics()
    } 

// end class HelpTopics
}

class Topic
{
    // define class member variables
    var $m_nID;                 // unique identifier for this topic
    var $m_nParentID = -1;      // ID of the parent topic
    var $m_nChildID = -1;       // ID of the child topic following this one
    var $m_szURL = "";          // URL to be displayed
    var $m_szDisplayText = "";  // text to display
    var $m_szIconFile = "";     // path and filename of the icon to display
    
    /**
     * Default constructor.
     * 
     * @return void.
     **/
    function Topic()
    {
    // end constructor Topic()
    }
    
    
// end class Topic
}

class HelpTopics_Text extends HelpTopics
{
    /**
     * Precondition:   Each line of the given textfile is assummed to be of the
     *                 format: depth|icon file|label|url to display.
     * Postcondition:  This constructor sets the super class's member variables
     *                 based on the information found in the given text file.
     * 
     * @param $szFile string - The path and filename of the file to read.
     * @return void.
     **/
    function HelpTopics_Text( $szFile )
    {
        // define array to keep track of node paths
        $anDepths = array();
    
        // load file into an array, return if fail
        $aszTopicStrings = $this->readFileToArray( $szFile );
        if ( !$aszTopicStrings ) return;
        
        // loop through the array and build topic objects
        $nCount = count( $aszTopicStrings );
        $nPreviousID = -1;
        for( $i=0; $i<$nCount; $i++ )
        {
            // separate the string into array elements
            $aszTopic = explode( "|", $aszTopicStrings[$i] );
            
            // create a new Topic object and set properties
            $this->m_aoTopic[$i] = new Topic();
            $this->m_aoTopic[$i]->m_szTopicFile = $szFile;
            $this->m_aoTopic[$i]->m_nID = $i;
            $this->m_aoTopic[$i]->m_szIconFile = $aszTopic[1];
            $this->m_aoTopic[$i]->m_szDisplayText = $aszTopic[2];
            $this->m_aoTopic[$i]->m_szURL = $aszTopic[3];

            // count the depth chars to determine if is major
            $nPointCount = strlen( trim( $aszTopic[0] ) );
            if ( $nPointCount == 1 )
            {
                array_push( $this->m_anMajorIDs,$i ); 
                $szIsMajor = "&&1";
            }
            else
                $szIsMajor = "";
            
            //  set the parent
            if ( $nPointCount > 1 ) 
                $this->m_aoTopic[$i]->m_nParentID = $anDepths[$nPointCount - 1 ];
            
            // update the depth array
            $anDepths[$nPointCount] = $i;
                         
            // add to the tree menu string
            $this->m_szTreeView .= $aszTopic[0]."|".$aszTopic[1]."|".
                                       "@".$aszTopic[2]."&&".$i.$szIsMajor."\n";

        // end for loop
        }
         
    // end constructor HelpTopics()
    } 
    
    /**
     * Postcondition:  This function reads the given textfile to an array.
     * 
     * @param $szFile string - Path and filename of the textfile to read.
     * @return mixed - Array of values if successful, false if not.
     **/
    function readFileToArray( $szFile )
    {
        // define array variable
        $aszList = array();
    
        // attempt to open the file, return false if failed
        if (!($fp = fopen($szFile, "r"))) return false;
    
        // file is open so parse each entry
        while($fp && !feof($fp))
        {
            // get next line
            $line = fgets($fp, 4096);
    
            // trim() strips off whitespaces and \r and \n
            $line = trim($line);
            
            // if not empty add to array
            if (strlen($line) > 0) array_push($aszList, $line);
        
        // end while loop
        }
    
        // close the file
        fclose($fp);
    
        // return the array
        return $aszList;
    
    // end readFileToArray() function
    }    

// end class HelpTopics_Text
}

class HelpTopics_DBF extends HelpTopics
{
    // TO BE IMPLEMENTED AS NECESSARY
    
// end class HelpTopics_DBF
}
?>
