<?php
/**
 * This script generate a gif file representing
 * a color
 *
 * @project     MapEdit
 * @revision    $Id: color.php,v 1.1 2004/11/17 20:52:12 pspencer Exp $
 * @purpose     generate a color swatch
 * @author      Paul Spencer (spencer@dmsolutions.ca)
 * @copyright
 * <b>Copyright (c) 2002, DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/**
 * REMOVED SESSION SUPPORT FOR PERFORMANCE REASONS, PASS ALL VARIABLES AS GET
 *
 * VARIABLES USED:
 * red - red value (0-255), defaults to 255 if not set
 * green - green value (0-255), defaults to 255 if not set
 * blue - blue value (0-255), defaults 255 if not set
 * NOTE: if NO values set, draw a red X)
 * x - width, default 20 if not set
 * y - height, default 30 if not set
 * imagetype - one of GIF, PNG or JPG.  If not set or not valid, will use
 * first supported image type found in order of GIF, PNG, JPG
 */


/* -------------------------------------------------------------------- */
/*      Load required modules                                           */
/* -------------------------------------------------------------------- */
if (PHP_OS == "WINNT" || PHP_OS == "WIN32")
{
    if (!extension_loaded( "gd" ))
    {
        dl( "php_gd2.dll" );
    }
}
else
{
    if (!extension_loaded("gd"))
    {
        dl( "php_gd2.so" );
    }
}


//setup default values
$nRed = isset($_GET['red']) ? $_GET["red"] : -1;
$nGreen = isset($_GET['green']) ? $_GET["green"] : -1;
$nBlue = isset($_GET['blue']) ? $_GET["blue"] : -1;
$nX = isset($_GET["x"]) ? $_GET["x"] : 20;
$nY = isset($_GET["y"]) ? $_GET["y"] : 30;

//make sure the values are valid
if ($nRed == "") $nRed = -1;
if ($nBlue == "") $nBlue = -1;
if ($nGreen == "") $nGreen = -1;

//if all values are invalid, draw an X, else adjust the colors to be valid
if ($nRed == -1 && $nGreen == -1 && $nBlue == -1)
    $bDrawX = true;
else
{
    $bDrawX = false;
    if ($nRed == -1) $nRed = 255;
    if ($nGreen == -1) $nGreen = 255;
    if ($nBlue == -1) $nBlue = 255;
}

// Create the image
$nImgId = ImageCreate($nX, $nY);

//allocate drawing colors
$nXColor = ImageColorAllocate( $nImgId, 255, 0, 0);
$nFillColor = ImageColorAllocate ($nImgId, $nRed, $nGreen, $nBlue);
$nShadowColor = ImageColorAllocate( $nImgId, 153, 153, 153 );
$nHiliteColor = ImageColorAllocate( $nImgId, 255, 255, 255 );
$nFaceColor = ImageColorAllocate( $nImgId, 217, 217, 217 );
$nTriangleColor = ImageColorAllocate($nImgId, 0,0,0);
$nWhite = ImageColorAllocate($nImgId, 255, 255, 255 );

$nBorderColor = ImageColorAllocate($nImgId, 0,0,0);

//fill up the rectange with the face color and draw everything
//else on top
ImageFilledRectangle($nImgId, 0, 0, $nX - 1, $nY - 1, $nFaceColor);

//check if we have a valid color
if (!$bDrawX)
{
    //yes, draw the color
    ImageFilledRectangle($nImgId, 2, 2, $nX - 2, $nY - 2, $nFillColor);
}
else
{
    //no, draw a red X
    $nCX = intval(( $nX - 1 ) / 2);
    $nCY = intval(( $nY - 1 ) / 2);
    ImageFilledRectangle( $nImgId, 2, 2, $nX - 2, $nY - 2, $nWhite );
    ImageLine( $nImgId, $nCX-3, $nCY-3, $nCX+3, $nCY+3, $nXColor );
    ImageLine( $nImgId, $nCX-2, $nCY-3, $nCX+4, $nCY+3, $nXColor );
    ImageLine( $nImgId, $nCX+3, $nCY-3, $nCX-3, $nCY+3, $nXColor );
    ImageLine( $nImgId, $nCX+4, $nCY-3, $nCX-2, $nCY+3, $nXColor );

}

//draw the inside black border
ImageLine( $nImgId, 1, 1, $nX-2, 1, $nBorderColor);
ImageLine( $nImgId, 1, 1, 1, $nY-2, $nBorderColor);
ImageLine( $nImgId, $nX-2, 1, $nX-2, $nY-2, $nBorderColor);
ImageLine( $nImgId, 1, $nY-2, $nX-2, $nY-2, $nBorderColor);
//draw the outside shadow and hilite (appears inset)
ImageLine( $nImgId, 0, 0, $nX-1, 0, $nShadowColor);
ImageLine( $nImgId, 0, 0, 0, $nY-1, $nShadowColor);
ImageLine( $nImgId, $nX-1, 1, $nX-1, $nY-1, $nHiliteColor);
ImageLine( $nImgId, 1, $nY-1, $nX-1, $nY-1, $nHiliteColor);
//draw the corner button (appears beveled)
ImageLine( $nImgId, $nX-8, $nY-1, $nX-1, $nY-1, $nBorderColor);
ImageLine( $nImgId, $nX-1, $nY-8, $nX-1, $nY-1, $nBorderColor);
ImageLine( $nImgId, $nX-2, $nY-8, $nX-8, $nY-2, $nBorderColor);
ImageLine( $nImgId, $nX-2, $nY-7, $nX-7, $nY-2, $nHiliteColor);
ImageLine( $nImgId, $nX-2, $nY-6, $nX-2, $nY-2, $nShadowColor);
ImageLine( $nImgId, $nX-6, $nY-2, $nX-2, $nY-2, $nShadowColor);
ImageLine( $nImgId, $nX-3, $nY-5, $nX-5, $nY-3, $nFaceColor);
ImageLine( $nImgId, $nX-3, $nY-4, $nX-4, $nY-3, $nFaceColor);
ImageLine( $nImgId, $nX-3, $nY-3, $nX-3, $nY-3, $nFaceColor);


//draw the small face colored box for the drop down triangle
//ImageFilledRectangle($nImgId, $nX-8, $nY-6, $nX-1, $nY-1, $nFaceColor);

//ImageLine( $nImgId, 0, 0, $nX-1, 0, $nHiliteColor);
//ImageLine( $nImgId, 0, 0, 0, $nY-1, $nHiliteColor);
//ImageLine( $nImgId, $nX-1, $nY-1, $nX-1, 0, $nShadowColor);
//ImageLine( $nImgId, $nX-1, $nY-1, 0, $nY-1, $nShadowColor);
//ImageLine( $nImgId, 2, 2, 2, $nY - 3, $nShadowColor );
//ImageLine( $nImgId, 2, 2, $nX - 3, 2, $nShadowColor );
//ImageLine( $nImgId, $nX-3, 2, $nX-3, $nY-7, $nHiliteColor );
//ImageLine( $nImgId, 2, $nY-3, $nX-9, $nY-3, $nHiliteColor );
//ImageLine( $nImgId, $nX-9, $nY-7, $nX-3, $nY-7, $nHiliteColor );
//ImageLine( $nImgId, $nX-9, $nY-7, $nX-9, $nY-3, $nHiliteColor );

//$anPoints = array();
//$anPoints[0] = $nX - 7;
//$anPoints[1] = $nY - 5;
//$anPoints[2] = $nX - 3;
//$anPoints[3] = $nY - 5;
//$anPoints[4] = $nX - 5;
//$anPoints[5] = $nY - 3;
//ImageFilledPolygon( $nImgId, $anPoints, 3, $nTriangleColor);

//determine best output type.
$aszTypes = array( "GIF" => "GIF", "PNG" => "PNG", "JPG" => "JPEG", "WBMP" => "WBMP" );
$szImageType = "";
if (isset($_GET["imagetype"]))
{
    //try to use the passed type
    if (isset($aszTypes[ $_GET["imagetype"] ]))
    {
        eval( "\$bSupported = ImageTypes() & IMG_".$_GET["imagetype"].";" );
        if ($bSupported)
        {
            $szImageType = $szType;
        }
    }
}

//user didn't pass one, go through the list.
if (!in_array($szImageType, $aszTypes ))
{
    foreach( $aszTypes as $szType )
    {
        eval( "\$bSupported = ImageTypes() & IMG_$szType;" );
        if ($bSupported)
        {
            $szImageType = $szType;
            break;
        }
    }
}

//return the image
header("Content-type: image/$szImageType");
eval("Image$szImageType(\$nImgId);");

ImageDestroy($nImgId);
?>
