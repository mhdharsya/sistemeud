/* GetLayer(name) */
function GetLayer(name)
{
    var layer;
    if (isNav4) // Netscape 4
    {   
        if (document.layers[name])
        {
          return document.layers[name];
        }
        else
        {
          alert( "failed to get layer " + name );
          return null;
        }
    } 
    else if (isIE4) // IE
    {            
        if (eval('document.all.' + name) != null) 
        {
            layer = eval('document.all.' + name);
            return layer;
        } 
        else 
        {
            alert( "failed to get layer " + name );
            return null;
        }
    } 
    else if (isNav6) //Netscape 6
    {
        if (eval('document.getElementById("' + name + '")') != null)
        {
            layer = eval('document.getElementById("' + name + '")');
            return layer;
        } 
        else 
        {
            alert( "failed to get layer " + name );
            return null;
        }
    } 
    else // Don't know
    {                              
        alert( "failed to get layer " + name );
        return null;
    }
}


/* setClip(layer, l, r, t, b) */
function setClip(layer, l, r, t, b) 
{
    if(isNav4)
    {
        layer.clip.left = l; layer.clip.right = r;
        layer.clip.top = t;  layer.clip.bottom = b;
    } 
    else
    {
        layer.style.pixelWidth = r-l;
        layer.style.pixelHeight = b-t;
        layer.style.clip = "rect("+t+","+r+","+b+","+l+")";
    }
}


/* setClipHeight(layer, h) */
function setClipHeight(layer, h) 
{
    isNav4? layer.clip.height = h : layer.style.pixelHeight = h;
}


/* setClipWidth(layer, w) */
function setClipWidth(layer, w)
{
    if(isNav4) 
        layer.clip.width = w;
    else
    {
        layer.style.pixelWidth = w;
        setClip(layer, 0, layer.style.pixelWidth, 0, layer.style.pixelHeight);
    }
}


/* setLeft(layer, l) */
function setLeft(layer, l) 
{
    isNav4? layer.left = l : layer.style.left = l;
}


/* setTop(layer, t) */
function setTop(layer, t)
{
    isNav4? layer.top = t : layer.style.top = t;
}


/* setVisibility(layer, v) */
function setVisibility(layer, v) 
{
    isNav4? layer.visibility = v : layer.style.visibility = v;
}


/* setZIndex(layer, z) */
function setZIndex(layer, z) 
{
    isNav4? layer.zIndex = z : layer.style.zIndex = z;
}


/* getLeft(layer) */
function getLeft(layer)
{
    return isNav4? layer.left : layer.offsetLeft;
}


/* getTop(layer) */
function getTop(layer) 
{
    return isNav4? layer.top : layer.offsetTop;
}


/* setLayerBgcolor(layer, b) */
function setLayerBgcolor(layer, b)
{
    isNav4? layer.bgColor = b : layer.style.backgroundColor = b;
}


/* setLayerOpacity( layer, opacity ) */
function setLayerOpacity( layer, opacity )
{
    //opacity 0-100
    if (opacity == 0)
        opacity = 1;
        
    if (isNav6)
    {
        opacity = opacity / 100;
        layer.style.MozOpacity = opacity;
    }
    else if (isIE4)
    {
        layer.style.filter = "Alpha(opacity=" + opacity + ")";
    }
}


/* getHSV() */
function getHSV()
{
    var ar = new Array(3);
    ar.h = (360*(getLeft(GetLayer("thumbH")) - 95)/200)-1;
    ar.s = (getLeft(GetLayer("thumbS"))-95)/200;
    ar.v = (getLeft(GetLayer("thumbV"))-95)/200;
    return ar;
}


/* getRGB() */
function getRGB() 
{
    var ar = new Array(3);
    ar.r = Math.round((getLeft(GetLayer("thumbR"))-95)/200*255);
    ar.g = Math.round((getLeft(GetLayer("thumbG"))-95)/200*255);
    ar.b = Math.round((getLeft(GetLayer("thumbB"))-95)/200*255);
    return ar;
}


/* setHSV(h,s,v,format) */
function setHSV(h,s,v,format) 
{
    if(format != 1 && h != -1) setLeft(GetLayer("thumbH"), ((h/360)*200)+95);
    if(s != -1) setLeft(GetLayer("thumbS"), Math.round(s*200)+95);
    if(v != -1) setLeft(GetLayer("thumbV"), Math.round(v*200)+95);
}


/* setRGB(r,g,b) */
function setRGB(r,g,b) 
{
    if(r != -1) setLeft(GetLayer("thumbR"), Math.round(r/255*200)+95);
    if(g != -1) setLeft(GetLayer("thumbG"), Math.round(g/255*200)+95);
    if(b != -1) setLeft(GetLayer("thumbB"), Math.round(b/255*200)+95);
}
