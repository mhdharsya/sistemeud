<?php
function PostInstallation()
{
    // Update registry. We put category inside the registry.
    $GLOBALS['goRegistry']->UpdatePackage("PHP_Utils", array('category' => 'php_utils'));
}
?>