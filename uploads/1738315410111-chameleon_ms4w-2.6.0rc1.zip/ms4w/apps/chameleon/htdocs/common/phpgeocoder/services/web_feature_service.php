<?php
/**
 * WebFeatureService  Class
 *
 * @project     PHPGeoCoder
 * @revision    $Id:
 * @purpose     Class Client to a OGC:WFS
 * @author      Bart van den Eijnden (bartvde@xs4all.nl)
 * @copyright
 * <b>Copyright (c) 2002, DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/**
 * Check for a defined COMMON variable containing the absolute path.  If not
 * found then check ../ then ./ else failure.
 */
if ( defined( "COMMON" ) && is_dir( COMMON ) )
{
    // check for closing "\" or "/"
    if ( substr( COMMON, strlen( COMMON )- 1, 1 ) == "\\" ||
         substr( COMMON, strlen( COMMON ) - 1, 1 ) == "/" )
        include_once( COMMON."phpgeocoder/web_service.php");
    else
        include_once( COMMON."/phpgeocoder/web_service.php");
}
elseif (file_exists("../web_service.php"))
{
    include_once("../web_service.php");
}
else
{
    include_once("./web_service.php");
}

include_once( COMMON."../widgets/utils.php" );

/**
 * WebFeatureService
 */
class WebFeatureService extends WebSearchService
{
    var $bFound = false;
    var $szLastError = "";
    var $nLastError = "";
    var $szServiceUri = "";
    var $mszTypename = "";
    var $mszNamespace = "";
    var $mszSearchField = "";
    var $aUrlParts = array();
    var $nIndex;
    var $bConcat = false;
    var $mszMaxFeatures = "";

    function WebFeatureService($oGeoCoder, $szOnlineResource = "", $szTypename = "", $szSearchField = "", $szNamespace = "", $szMaxFeatures = "")
    {
        // the name of the WFS typename
        if( $szTypename != "" )
        {
            $this->mszTypename = $szTypename;
        }
        // optional, the namespace which is used by the WFS service
        if( $szNamespace != "" )
        {
            $this->mszNamespace = strtoupper($szNamespace);
        }
        // the fields to search on separated by a pipe character
        if( $szSearchField != "" )
        {
            $this->mszSearchField = $szSearchField;
        }
        // the online resource of the WFS service
        if( $szOnlineResource != "" )
        {
            $this->szServiceUri = $szOnlineResource;
        }
        if( $szMaxFeatures != "" )
        {
            $this->mszMaxFeatures = $szMaxFeatures;
        }
        // extract port and host from uri
        $this->aUrlParts = parse_url( $this->szServiceUri );

        parent::WebSearchService( "WFS", $oGeoCoder, $this->szServiceUri );

        $this->nIndex = 0;
    }

    // build PropertyIsEqualTo request based on a key and value
    function buildPropertyIsEqualTo( $szKey, $szValue)
    {
        return "<ogc:PropertyIsEqualTo><ogc:PropertyName>".$szKey."</ogc:PropertyName>"
              ."<ogc:Literal>".$szValue."</ogc:Literal></ogc:PropertyIsEqualTo>";
    }

    // build PropertyIsLike request based on a key and value
    function buildPropertyIsLike( $szKey, $szValue )
    {
      if (strpos($szValue, '*') === false)
      {
        // automatically add * to the end
        return "<ogc:PropertyIsLike wildCard='*' singleChar='^' escape='!'><ogc:PropertyName>".$szKey."</ogc:PropertyName>"
              ."<ogc:Literal>".$szValue."*</ogc:Literal></ogc:PropertyIsLike>";
      }
      else
      {
        return "<ogc:PropertyIsLike wildCard='*' singleChar='^' escape='!'><ogc:PropertyName>".$szKey."</ogc:PropertyName>"
              ."<ogc:Literal>".$szValue."</ogc:Literal></ogc:PropertyIsLike>";
      }
    }

    // build the propertyname, concat with namespace and : if necessary
    function buildPropertyName( $szPropertyName )
    {
      $szResult = "";
      if ($this->mszNamespace != "")
      {
        $szResult = $this->mszNamespace.':'.$szPropertyName;
      }
      else
      {
        // no namespace, just use the search field
        $szResult = $szPropertyName;
      }
      return strtoupper($szResult);
    }

    // actual function which does the searching
    function search()
    {
        $iNumProperties = 0;
        $szAllFilters = "";

        // Scan all attributes
        foreach ($this->oGeoCoder->aoSearchAttribute as $oAttribute)
        {
           if ($oAttribute->szValue != "")
           {
             if ($oAttribute->bWildcard == false)
             {
               if ( (strpos($oAttribute->szValue, '*') === false) )
               {
                 $szFilter = $this->buildPropertyIsEqualTo( $oAttribute->szName, $oAttribute->szValue );
               }
               else
               {
                 $szFilter = $this->buildPropertyIsLike( $oAttribute->szName, $oAttribute->szValue );
               }
             }
             else
             {
               $szFilter = $this->buildPropertyIsLike( $oAttribute->szName, $oAttribute->szValue );
             }
             if( $szFilter != "" )
             {
                $szAllFilters .= $szFilter;
                $iNumProperties += 1;
             }
           }
        }

        if( $iNumProperties > 1 )
        {
            $szAllFilters = "<ogc:And>".$szAllFilters."</ogc:And>";
        }

        if( $iNumProperties > 0 )
        {
            if ($this->mszMaxFeatures != "")
            {
              $szMaxFeatures = " maxFeatures=\"".$this->mszMaxFeatures."\"";
            }
            $this->szParameters = "<GetFeature service=\"WFS\" version=\"1.0.0\" xmlns=\"http://www.opengis.net/wfs\" xmlns:gml=\"http://www.opengis.net/gml\" xmlns:ogc=\"http://www.opengis.net/ogc\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://schemas.opengis.net/wfs/1.0.0 WFS-basic.xsd\"".$szMaxFeatures."><Query typeName=\"".$this->mszTypename."\">"
                        ."<ogc:Filter>"
                        .$szAllFilters
                        ."</ogc:Filter></Query></GetFeature>";

            if ( PHP_OS == "WINNT" || PHP_OS == "WIN32" )
              $szCURLModule = "php_curl.dll";
            else
              $szCURLModule = "php_curl.so";

            if (!extension_loaded("curl"))
              dl($szCURLModule);

            $header[] = "Accept: text/xml";
            $header[] = "Content-type: text/xml";
            $header[] = "Content-length: ".strlen($this->szParameters);

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL,$this->szBaseURL);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_TIMEOUT, 60);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST,'POST');
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $this->szParameters);

            // debug echo request
            //echo "<xmp>".$this->szParameters."</xmp>";

            $data = curl_exec($ch);
            if (curl_errno($ch))
            {
              echo curl_error($ch);
              exit;
            }
            else
            {
              curl_close($ch);
              $this->szRawResult = $data;
            }
            // debug echo response
            //echo "<xmp>".$data."</xmp>";

            if( $this->szRawResult == "" )
            {
                $this->error( ERR_NOTICE, "No search results\n" );
            }
            else
            {
                // ISO-8859-1
                $xml_parser = xml_parser_create('');
                xml_set_object( $xml_parser, $this );
                xml_set_character_data_handler( $xml_parser, "characterData" );
                xml_set_element_handler( $xml_parser, "startElement", "endElement" );

                if (!xml_parse($xml_parser, $this->szRawResult))
                {
                    die( sprintf( "XML error: %s at line %d",
                            xml_error_string(xml_get_error_code($xml_parser)),
                            xml_get_current_line_number($xml_parser)) );
                }

                xml_parser_free($xml_parser);
            }
        }

        // If an error occured, send the last error.
        // Dont send error if no record found.
        if( $this->nLastError != "" && $this->nLastError != "12010" )
        {
            $this->error(ERR_WARNING, $this->szLastError);
        }
    }

    function characterData($oParser, $szData)
    {
        if( $this->bConcat )
            $this->szLastValue .= "," . $szData;
        else
            $this->szLastValue = $szData;
    }

    // parse the returned GML
    function startElement($oParser, $szName, $szAttrs)
    {
        // new feature member
        if ($szName == "GML:FEATUREMEMBER")
        {
            $this->bFound = true;

            $oRes = new Result();
            array_push( $this->aoResult, $oRes );
            $this->nIndex = count( $this->aoResult ) - 1;
        }
    }

    // parse the returned GML
    function endElement($oParser, $szName)
    {
        if( $szName == "GML:FEATUREMEMBER" )
        {
            // end of feature member; add info to list
            $this->bFound = false;
        }

        $aszSearchField = explode("|", $this->mszSearchField);

        foreach ($aszSearchField as $szSearchField)
        {
          if( ($szName == $this->buildPropertyName($szSearchField)) && $this->bFound )
          {
            if (!isset($this->aoResult[$this->nIndex]))
                array_push($this->aoResult, new Result());

            $this->aoResult[$this->nIndex]->addAttribute( new SearchAttribute( $szName, $this->szLastValue ) );
            $this->bFound = true;
          }
        }
        // also add filteritem values if filter item differs from searchFields
        /*if( ($szName == $this->buildPropertyName($this->mszFilterItem)) && $this->bFound )
        {
          if (!isset($this->aoResult[$this->nIndex]))
              array_push($this->aoResult, new Result());

          $this->aoResult[$this->nIndex]->addAttribute( new SearchAttribute( $szName, $this->szLastValue ) );
          $this->bFound = true;
        }*/

        if( $szName == "GML:COORDINATES" && $this->bFound )
        {
            if (!isset($this->aoResult[$this->nIndex]))
                array_push($this->aoResult, new Result());
            $this->aoResult[$this->nIndex]->addAttribute( new SearchAttribute( $szName, $this->szLastValue ) );
            $this->bFound = true;
        }
    }
}
?>
