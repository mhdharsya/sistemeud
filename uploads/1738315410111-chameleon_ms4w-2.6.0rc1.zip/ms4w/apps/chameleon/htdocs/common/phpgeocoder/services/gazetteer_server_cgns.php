<?php
/**
 * GazeteerService   Class definition for Gazeteer search service
 *
 * @project     PHPGeoCoder
 * @revision    $Id:
 * @purpose     Class definition of Gazeteer search service.
 * @author      Sacha Fournier (sfournier@dmsolutions.ca)
 * @copyright
 * <b>Copyright (c) 2002, DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/**
 * Check for a defined COMMON variable containing the absolute path.  If not
 * found then check ../ then ./ else failure.
 */
if ( defined( "COMMON" ) && is_dir( COMMON ) )
{
    // check for closing "\" or "/"
    if ( substr( COMMON, strlen( COMMON )- 1, 1 ) == "\\" ||
         substr( COMMON, strlen( COMMON ) - 1, 1 ) == "/" )
        include_once( COMMON."phpgeocoder/web_service.php");
    else
        include_once( COMMON."/phpgeocoder/web_service.php");
}
elseif (file_exists("../web_service.php"))
{
    include_once("../web_service.php");
}
else
{
    include_once("./web_service.php");
}

class GazeteerServer extends WebSearchService
{
    var $nIndex;

    function GazeteerServer($oGeoCoder="")
    {
        parent::WebSearchService("GAZETTEER_SERVER", $oGeoCoder, "http://cgns.nrcan.gc.ca/wfs/cubeserv.cgi");

        $this->nIndex = 0;
    }

    function search()
    {
        $this->szParameters = "datastore=cgns&version=1.0.0&service=WFS&request=GetFeature&typename=GEONAMES";

        foreach ($this->oGeoCoder->aoSearchAttribute as $oAttribute)
        {
            if ($oAttribute->getName() == "PLACE_NAME")
            {
                $this->szParameters .= "&filter=<Filter><PropertyIsEqualTo><PropertyName>NAME_KEY</PropertyName><Literal>".urlencode(strtoupper($oAttribute->getValue()))."</Literal></PropertyIsEqualTo></Filter>";

                $bFound = true;
            }
            else
            {
                // put some error message as this is an empty query if we get here
                $bFound = true;
            }
        }

        if (parent::search())
        {
            // Parse respond
            $xml_parser = xml_parser_create();
            xml_set_object($xml_parser, $this);
            xml_set_character_data_handler($xml_parser, "characterData");
            xml_set_element_handler($xml_parser, "startElement", "endElement");

            if (!xml_parse($xml_parser, $this->szRawResult))
            {
                die(sprintf("XML error: %s at line %d",
                xml_error_string(xml_get_error_code($xml_parser)),
                xml_get_current_line_number($xml_parser)));
            }

            xml_parser_free($xml_parser);
        }
    }

    function characterData($oParser, $szData)
    {
        $this->szLastValue = utf8_decode($szData);
    }

    function startElement($oParser, $szName, $szAttrs)
    {
        if ($szName == "GML:FEATUREMEMBER")
        {
            $this->bFound = true;
            $oRes = new Result();
            array_push($this->aoResult, $oRes);
            $this->nIndex = count($this->aoResult) - 1;
        }
    }

    function endElement($oParser, $szName)
    {
        if ($szName == "GML:FEATUREMEMBER")
            $this->bFound = false;

        if ($szName == "GEONAMES.GEONAME" && $this->bFound)
            $this->aoResult[$this->nIndex]->addAttribute(new PlaceName($this->szLastValue));

        if ($szName == "GEONAMES.LOCATION" && $this->bFound)
            $this->aoResult[$this->nIndex]->addAttribute(new Entity($this->szLastValue));

        if ($szName == "GEONAMES.REGION_CODE" && $this->bFound)
        {
            if ($this->szLastValue == "48")
                $regionCode = "AB";
            if ($this->szLastValue == "59")
                $regionCode = "BC";
            if ($this->szLastValue == "46")
                $regionCode = "MB";
            if ($this->szLastValue == "13")
                $regionCode = "NB";
            if ($this->szLastValue == "10")
                $regionCode = "NL";
            if ($this->szLastValue == "61")
                $regionCode = "NT";
            if ($this->szLastValue == "12")
                $regionCode = "NS";
            if ($this->szLastValue == "62")
                $regionCode = "NV";
            if ($this->szLastValue == "35")
                $regionCode = "ON";
            if ($this->szLastValue == "11")
                $regionCode = "PE";
            if ($this->szLastValue == "24")
                $regionCode = "QC";
            if ($this->szLastValue == "47")
                $regionCode = "SK";
            if ($this->szLastValue == "60")
                $regionCode = "YK";

            $this->aoResult[$this->nIndex]->addAttribute(new StateProvince($regionCode));
        }

        if ($szName == "GML:COORDINATES" && $this->bFound)
        {
            $aszLatLong = explode(",", $this->szLastValue);
            $this->aoResult[$this->nIndex]->addAttribute(new LatLong($aszLatLong[0], $aszLatLong[1]));
        }
    }
}
?>
