<?php
class Profiler
{
    var $aoFunction;

    /**
     * Main constructor. Initialization.
     */
    function Profiler()
    {
        $aoFunction = array();
    }

    /**
     * This function start a timer for szFuncName. If
     * more than one call is made for a specific 
     * szFuncName, all time will be added at the end
     * amd a counter will be updated to show how much time
     * the function was called.
     *
     * @param szFuncName Function name binded to the timer.
     */
    function StartFunction($szFuncName)
    {
        if (!isset($this->aoFunction[$szFuncName]))
        {
            $this->aoFunction[$szFuncName] = array();
            $this->aoFunction[$szFuncName]["instances"] = array();
            $this->aoFunction[$szFuncName]["tot_instance"] = 0;
        }
        
        array_push($this->aoFunction[$szFuncName]["instances"], $this->getmicrotime());
        $this->aoFunction[$szFuncName]["tot_instance"]++;
    }

    /**
     * This function stop the timer binded to szFuncName.
     *
     * @param $szFuncName Fucntion to stop.
     */
    function EndFunction($szFuncName)
    {
        if (isset($this->aoFunction[$szFuncName]))
        {
            $nEndTime   = $this->getmicrotime();
            $nStartTime = array_pop($this->aoFunction[$szFuncName]["instances"]);
            $nDiffTime  = $nEndTime - $nStartTime;
echo $nDiffTime."\n";
            $this->aoFunction[$szFuncName]["total"] += $nDiffTime;
        }
    }

    /**
     * Dump a report of all functions with their process
     * time and how much time they was called.
     */
    function ShowReport()
    {
	if (is_array($this->aoFunction))
        foreach($this->aoFunction as $szKey => $aFunction)
        {
            echo "$szKey called: ".$aFunction["tot_instance"]." time(s) and taked: ".$aFunction["total"]." second(s)\n";
        }
    }

    /**
     * Internal class function
     */
    function getmicrotime()
    { 
        list($usec, $sec) = explode(" ",microtime()); 
        return ((float)$usec + (float)$sec); 
    } 
}

$gProfiler = new Profiler();
?>
