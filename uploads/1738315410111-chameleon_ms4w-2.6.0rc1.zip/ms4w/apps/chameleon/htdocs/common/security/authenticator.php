<?php
/*
 * Security services is a utility that help to authentificate
 * and check access of a user.
 *
 */

// include necessary files
if ( !defined( "COMMON" ) ) define( "COMMON", "../" );
$szCommon = str_replace( "\\", "/", realpath( COMMON ) )."/";
include( $szCommon."security/user_connection.php" );

/**
 * This specific class is a abstract class that must be generalized.
 * 
 * Package(s) used: UserConnection, Logger
 * 
 * @author Sacha Fournier (sfournier@dmsolutions.ca)
 * @project PhpUtil
 * @revision $Id
 * @purpose Manage application security.
 * @copyright Copyright DM Solutions Group Inc 2002
 * 
*/
class Authenticator
{
	// define member variables
	var $oErrorManager;
	
    function Authenticator()
    {
    }
    
    function Login( $szUserName, $szPassword )
    {
    }
    
    function Logout()
    {
    }
    
    /**
     * error()
     *
     * Postcondition:  This method will log errors if the instatiating 
     *				   application sets the error manager.
     * @param $nCode integer - Error code.
     * @param $szMessage string - Error message.
     * @return void.
     * @desc Log error.
     **/
    function error( $nCode, $szMessage )
    {
    	// check if an error manager is set
    	if ( isset( $this->oErrorManager ) )
    	{
    		$this->oErrorManager->error( $nCode, $szMessage );
    	}
    }
}
?>
