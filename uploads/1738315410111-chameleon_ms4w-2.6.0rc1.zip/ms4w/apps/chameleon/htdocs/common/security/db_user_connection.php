<?php
/**
 * Security services is a utility that help to authentificate
 * and check access of a user.
 *
 */

// include necessary files
if ( !defined( "COMMON" ) ) define( "COMMON", "../" );
$szCommon = str_replace( "\\", "/", realpath( COMMON ) )."/";
include_once( $szCommon."security/db_name_abstraction.php" );
include_once( $szCommon."security/db_priv_code.php" );
include_once( $szCommon."adodb/adodb.inc.php" );


/**
 * This specific class is a generalization of UserConnection. It is
 * database specific. UserPrivileges are loaded from "tblUserPrivileges"
 * table. See visio doc for structure.
 * 
 * Package(s) used: UserConnection, DBPrivCode, adodb
 * 
 * @author Sacha Fournier (sfournier@dmsolutions.ca)
 * @project PhpUtil
 * @revision $Id
 * @purpose Manage application security.
 * @copyright Copyright DM Solutions Group Inc 2002
 * 
*/
class DBUserConnection extends UserConnection
{
    var $oADODBConnection;

    /**
     * Since this class is database specif,
     * we must specify a database connection.
     * 
     * @param oADODBConnection - Database connection that this class must use.
     * 
     * @return
     */
    function DBUserConnection($oADODBConnection)
    {
         // call parent
        parent::UserConnection();

        $this->oADODBConnection = $oADODBConnection;
    }

    /**
     * This function check if current connection
     * have access to szProgId.
     *
     * WARNING: ProgId are not PrivCode.
     * 
     * @param $szProgId - ProgId to check. ProgId format => (something.somewhere.somehow)
     * 
     * @return True if current connection has acces to the szProgId.
     */
    function HasAccessTo($szProgId)
    {
        $res = false;
                
        // Create a new privCode from szProgId
        $oPrivCode = new DBPrivCode($this->oADODBConnection);
        //$oPrivCode->setLogFile($this->oLogFile);
        if ($oPrivCode->Create($szProgId) != false)
        {
            // call parent.
            $res = parent::HasAccessTo($oPrivCode);
        }
        
        return $res;
    }

    /*
     * UserConnection pure virtual functions are
     * defined at this point.
     */
    
    /**
     * Load all privileges for a user.
     * Privileges a group by group name @#$@#^%^
     * So we load all group privileges for all
     * user groups.
     */
    function LoadUserPrivileges()
    {
        // retrieve a PrivCode
/*        $sql = "SELECT * FROM ".TBL_USERS." as u, ".TBL_GROUP_PRIV.
                " as g WHERE u.".FLD_USERS_ID."=".$this->nUserId." AND u.".
                FLD_USERS_GROUPID."=g.".FLD_GROUP_PRIV_ID;*/
        $sql = "SELECT * FROM ".TBL_USERS_PRIV." as u, ".TBL_GROUP_PRIV.
                " as g WHERE u.".FLD_USERS_PRIV_USERID."=".$this->nUserId." AND u.".
                FLD_USERS_PRIV_GROUPID."=g.".FLD_GROUP_PRIV_ID;                
 
        $res = $this->oADODBConnection->Execute($sql);
        
        if ( $res !== false )
        {
            // insert priv code into array.
            while($row = $res->FetchNextObject(false))
            {
                $oUserPrivCode = new DBPrivCode($this->oADODBConnection);
                eval( "\$oUserPrivCode->szPrivCode = \$row->".FLD_GROUP_PRIV_CODE.";" );
                
                array_push($this->aoUserPrivCode, $oUserPrivCode);
            }
        }
        else 
        {
            $this->error( 1, "Invalid database structure.  Privileges table is inaccessable" );
        }
    }
    
    /**
     * This function read a UserConnection object from 
     * Database. szSessionId is the key
     * 
     * @param $szSessionId - Session to restore.
     */
    function Restore($szSessionId)
    {
        $sql = "SELECT StoredClass FROM tblUserConnections WHERE SessionId=\"$szSessionId\"";
        
        $res = $this->oADODBConnection->Execute($sql);
        
        if (!$res || $res->RowCount() == 0)
        {
            $this->error(1, "Session ($szSessionId) does not exist anymore.");
            
            return false;
        }
        
        $szClass = stripslashes($res->fields[0]);
            
        $oTmpUserConn = unserialize($szClass);
            
        $this->szSessionId = $szSessionId;
        $this->szUserName  = $oTmpUserConn->szUserName;
        $this->nUserId     = $oTmpUserConn->nUserId;
        $this->axProperties  = $oTmpUserConn->axProperties;
        $this->nExpTime    = $oTmpUserConn->nExpTime;
        $this->aoPrivCode  = $oTmpUserConn->aoPrivCode;
        $this->aszHistory  = $oTmpUserConn->aszHistory;
        
        return true;
    }
    
    /**
     * This function save current Userconnection obj
     * to database. Key is base on szSessionId.
     */
    function Store()
    {
        //$this->logFuncStart(LOG_VERBOSE, "UserConnection::Store() called.");

        if (strlen($this->szSessionId) < 1)
        {
            $this->error(1, "Can't save object when szSessionId is null.");
            return false;
        }

        $szClass = addslashes(serialize($this));

        $sql = "SELECT * FROM tblUserConnections WHERE SessionId=\"$this->szSessionId\"";
        
        $res = $this->oADODBConnection->Execute($sql);
        
        if ($res && $res->RowCount() == 1)
        {
            // Update row
            $sql = "UPDATE tblUserConnections SET StoredClass=\"$szClass\" WHERE SessionId=\"$this->szSessionId\"";
            
            $this->oADODBConnection->Execute($sql);
        }
        else
        {
            // insert new row
            $sql = "INSERT INTO tblUserConnections VALUES(\"$this->szSessionId\", \"$szClass\")";
            
            $this->oADODBConnection->Execute($sql);            
        }
                              
        return true;        
    }
    
}
?>
