# phpMyAdmin MySQL-Dump
# version 2.4.0
# http://www.phpmyadmin.net/ (download page)
#
# Host: localhost
# Generation Time: Sep 18, 2003 at 02:49 PM
# Server version: 4.0.12
# PHP Version: 4.3.2RC3
# Database : `newadmin`
# --------------------------------------------------------

#
# Table structure for table `com_profile`
#

CREATE TABLE com_profile (
  id int(11) NOT NULL auto_increment,
  user_name varchar(50) NOT NULL default '',
  password varchar(25) NOT NULL default '',
  address1 varchar(50) NOT NULL default '',
  address2 varchar(50) NOT NULL default '',
  city varchar(30) NOT NULL default '',
  first_name varchar(30) NOT NULL default '',
  last_name varchar(50) NOT NULL default '',
  UNIQUE KEY id (id)
) TYPE=MyISAM;
# --------------------------------------------------------

#
# Table structure for table `sec_groupprivileges`
#

CREATE TABLE sec_groupprivileges (
  id int(11) NOT NULL default '0',
  group_id int(11) NOT NULL default '0',
  code varchar(50) NOT NULL default ''
) TYPE=MyISAM;
# --------------------------------------------------------

#
# Table structure for table `sec_groups`
#

CREATE TABLE sec_groups (
  id int(11) NOT NULL default '0',
  name varchar(50) NOT NULL default ''
) TYPE=MyISAM;
# --------------------------------------------------------

#
# Table structure for table `sec_privileges`
#

CREATE TABLE sec_privileges (
  id int(11) NOT NULL default '0',
  name varchar(50) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;
# --------------------------------------------------------

#
# Table structure for table `sec_userprivileges`
#

CREATE TABLE sec_userprivileges (
  id int(11) NOT NULL default '0',
  user_id int(11) NOT NULL default '0',
  group_id int(11) NOT NULL default '0'
) TYPE=MyISAM;

