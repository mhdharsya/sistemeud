<?php
/**
 * php_utils security module
 *
 * @project     PHP_UTILS
 * @revision    $Id: admin.php,v 1.2 2003/09/18 19:40:54 bronsema Exp $
 * @purpose     This is the privilege admin page.
 * @author      William A. Bronsema, C.E.T. (dev@dmsolutions.ca)
 * @copyright
 * <b>Copyright (c) 2003, DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 **/
 
// include the database abstratction file
include_once( "../db_name_abstraction.php" );

// include the adodb files
include_once( "../../adodb/adodb.inc.php" );

// include the connection information
if ( !defined( "CONNECTION_FILE" ) )
	define( "CONNECTION_FILE", "./connect.inc.php" );
include_once( CONNECTION_FILE );

function connect( $szConType, $szConHost, $szConUser, $szConPassword, 
															$szConDatabase )
{
	// make new connection
	$dbConn = ADONewConnection( $szConType );
	$dbConn->Connect( $szConHost, $szConUser, $szConPassword, $szConDatabase );
	
	// return connection
	return $dbConn;
}

function addPrivilege( $oDbHandle, $szPrivName )
{
	// check if the name exists
	$szSQL = "SELECT ".FLD_PRIV_NAME." FROM ".TBL_PRIV." WHERE ".
												FLD_PRIV_NAME."='".$szPrivName."'";
	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// verify results
	if ( $oResult !== false && $oResult->RowCount() > 0 )
	{
		//  give error message
		echo "Group privilege exists, update aborted.";
		return false;
	}
	
	// determine the max id
	$szSQL = "SELECT max( ".FLD_PRIV_ID." ) AS count FROM ".TBL_PRIV;
	
	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// verify results
	if ( $oResult !== false && $oResult->RowCount() > 0)
	{
		// set the next index
		$oRow = $oResult->FetchObject( false );
		$nCounter = $oRow->count;
	}
	else
	{
		// default the index
		$nCounter = 0;	
	}
	
	// increment the counter
	$nCounter++;
	
    // create the sql statement to add the new code
    $szSQL = "INSERT INTO ".TBL_PRIV." ( ".FLD_PRIV_ID." , ".FLD_PRIV_NAME.
    			" ) VALUES (".$nCounter.", '".$szPrivName."');";
	
	// execute sql
	$oResult = $oDbHandle->Execute( $szSQL );
	
    // verify results
	return $oResult !== false;
}

function deletePrivilege( $oDbHandle, $szPrivName )
{	
	// determine the id for the priv
	$szSQL = "SELECT * FROM ".TBL_PRIV." WHERE ".FLD_PRIV_NAME.
    			" = '".$szPrivName."';";
	// execute sql
	$oResult = $oDbHandle->Execute( $szSQL );
	
    // verify results
	if ( $oResult !== false && $oResult->RowCount() > 0 )
	{
		// record the id
		$oRow = $oResult->FetchObject( false );
		eval( "\$nID = \$oRow->".FLD_PRIV_ID.";" );
	}
	else
	{
		// give error
		echo "Privilege(".$szPrivName.
									") was not found.  Deletion was aborted.";
		return false;
	}
	
	// create the sql statement to remove the code
    $szSQL = "DELETE FROM ".TBL_PRIV." WHERE ".FLD_PRIV_NAME.
    			" = '".$szPrivName."';";
    			
	// execute sql
	$oResult = $oDbHandle->Execute( $szSQL );
	
    // verify results
	if ( $oResult !== false )
	{
		// remove any group priv assignments that contain the code
		$szSQL = "SELECT * FROM ".TBL_GROUP_PRIV.";";
		
		// execute the statement
		$oResult = $oDbHandle->Execute( $szSQL );
		
		// process results
		if ( $oResult !== false && $oResult->RowCount() > 0 )
		{
			// get object data
			$szRowsToDelete = "";
			while ( $oRow = $oResult->FetchNextObject( false ) )
			{
				// separate out the codes
				eval( "\$anCodes = explode( \".\", \$oRow->".FLD_GROUP_PRIV_CODE." );" );
				if ( in_array( $nID, $anCodes ) )
				{
					// add to the string of id's to delete
					eval( "\$nTmpId = \$oRow->".FLD_GROUP_PRIV_UNIQUEID.";" );
					$szRowsToDelete .= FLD_GROUP_PRIV_UNIQUEID."='".$nTmpId."' OR ";
				}
			}
			
			// build delete query if necessary
			if ( strlen( $szRowsToDelete ) > 0 )
			{
				// remove trailing " OR "
				$szRowsToDelete = substr( $szRowsToDelete, 0, -4 );
				
				// build query
				$szSQL = "DELETE FROM ".TBL_GROUP_PRIV." WHERE ".
														$szRowsToDelete.";";
														
				// execute the statement
				$oResult = $oDbHandle->Execute( $szSQL );
				
				// process results
				if ( $oResult !== false )
				{
					// return success
					return true;
				}
				else
				{
					// give error
					echo "Unable to delete privilege assigned to groups.";
					return false;
				}
			}
		}
	}
	else
	{
		// give error message
		echo "An error occurred removing the privilege(".$szPrivName.")";
		return false;
	}
}

function addGroup( $oDbHandle, $szName )
{
	// check if the name exists
	$szSQL = "SELECT ".FLD_GROUP_NAME." FROM ".TBL_GROUP." WHERE ".
												FLD_GROUP_NAME."='".$szName."'";
	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// verify results
	if ( $oResult !== false && $oResult->RowCount() > 0 )
	{
		//  give error message
		echo "Group name exists, update aborted.";
		return false;
	}
		
	// determine the max id
	$szSQL = "SELECT max( ".FLD_GROUP_ID." ) AS count FROM ".TBL_GROUP;
	
	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// verify results
	if ( $oResult !== false && $oResult->RowCount() > 0)
	{
		// set the next index
		$oRow = $oResult->FetchObject( false );
		$nCounter = $oRow->count;
	}
	else
	{
		// default the index
		$nCounter = 0;	
	}
	
	// increment the counter
	$nCounter++;
	
    // create the sql statement to add the new group
    $szSQL = "INSERT INTO ".TBL_GROUP." ( ".FLD_GROUP_ID." , ".FLD_GROUP_NAME.
    			" ) VALUES (".$nCounter.", '".$szName."');";
	
	// execute sql
	$oResult = $oDbHandle->Execute( $szSQL );
	
    // verify results
	return $oResult !== false;
}

function deleteGroup( $oDbHandle, $szName )
{	
	// build SQL to get index for given group
	$szSQL = "SELECT ".FLD_GROUP_ID." AS groupid FROM ".TBL_GROUP." WHERE ".FLD_GROUP_NAME."='".$szName."';";
	
	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// verify results
	if ( $oResult !== false && $oResult->RowCount() > 0)
	{
		// get id
		$oRow = $oResult->FetchObject( false );
		$nGroupId = $oRow->groupid;
		
		// delete all links to users for this group
		$szSQL = "DELETE FROM ".TBL_USERS_PRIV." WHERE ".FLD_USERS_PRIV_GROUPID.
				 "=".$nGroupId.";";
				 
		// execute the statement
		$oResult = $oDbHandle->Execute( $szSQL );
		
		// verify results
		if ( $oResult !== false )
		{
			
			// delete all links to users for this group
			$szSQL = "DELETE FROM ".TBL_GROUP_PRIV." WHERE ".FLD_GROUP_PRIV_ID.
					 "=".$nGroupId.";";
					 
			// execute the statement
			$oResult = $oDbHandle->Execute( $szSQL );
			
			// verify results
			if ( $oResult !== false )
			{
				// build SQL to delete the group itself
			    $szSQL = "DELETE FROM ".TBL_GROUP." WHERE ".FLD_PRIV_NAME.
			    			" = '".$szName."';";
			    			
				// execute sql
				$oResult = $oDbHandle->Execute( $szSQL );
				
			    // verify results
				return $oResult !== false;
			}
			else
			{
				// give error
				echo "Unable to remove group privileges.  Delete request ".
					"had a partial failure.  Please check database integrity.";
				return false;
			}
		}
		else 
		{
			// give error
			echo "Unable to remove group privileges for user.  Delete request failed.";
			return false;
		}
	}
	else
	{
		//give error
		echo "Error: Group name not found.  Delete was unsucessful.";
		return false;
	}

}

function assignPrivilegeToGroup( $oDbHandle, $szPrivCode, $szGroup )
{
	// check if group exists
	$szSQL = "SELECT * FROM ".TBL_GROUP." WHERE ".
									FLD_GROUP_NAME."='".$szGroup."'";
	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// verify results
	if ( $oResult === false || $oResult->RowCount() <= 0 )
	{
		// give error
		echo "Group(".$szGroup.") does not exist.";
		return false;
	}
	else
	{
		// record the id for the group
		$oRow = $oResult->FetchObject( false );
		eval( "\$nGroupId = \$oRow->".FLD_GROUP_ID.";");
	}

	// initialize parallel array for code index
	$anPrivId = array();
	
	// divide priv up into pieces
	$aszPrivCode = explode( ".", $szPrivCode );
	
	// loop and check to see if each code exists
	$szCodeNotFound = ""; 
	foreach( $aszPrivCode as $szCode )
	{
		// check if the wildcard is used
		if ( $szCode == "*" )
		{
			// add to code array
			$anPrivId[$szCode] = "*";
			continue;
		}
		
		// get code
		$szSQL = "SELECT * FROM ".TBL_PRIV." WHERE ".
										FLD_PRIV_NAME."='".$szCode."'";
		// execute the statement
		$oResult = $oDbHandle->Execute( $szSQL );
		
		// verify results
		if ( $oResult === false || $oResult->RowCount() <= 0 )
		{
			// set flag and exit loop
			$szCodeNotFound = $szCode;
			break;
		}
		else
		{
			// push the id onto the new array
			$oRow = $oResult->FetchObject( false );
			eval( "\$anPrivId[\$szCode] = \$oRow->".FLD_PRIV_ID.";");
		}
	}
	
	// check if all codes were found
	if ( $szCodeNotFound != "" )
	{
		// give error
		echo "The requested code(".$szCodeNotFound.
		") was not found in the database.  Privilege assignment was aborted.";
		return false;
	}
	
	// loop and build new id code string
	$szCodeId = "";
	foreach( $aszPrivCode as $szCode )
	{
		$szCodeId .= $anPrivId[$szCode].".";
	}
	$szCodeId = substr( $szCodeId, 0, -1 );

	// check if the privilege exists for this group
	$szSQL = "SELECT * FROM ".TBL_GROUP_PRIV."  INNER JOIN ".TBL_GROUP.
		" ON ".TBL_GROUP_PRIV.".".FLD_GROUP_PRIV_ID."=".TBL_GROUP."."
		.FLD_GROUP_ID." WHERE ".TBL_GROUP.".".FLD_GROUP_NAME."='".$szGroup.
		"' AND ".TBL_GROUP_PRIV.".".FLD_GROUP_PRIV_CODE."='".$szCodeId."'";

	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// verify results
	if ( $oResult !== false && $oResult->RowCount() > 0 )
	{
		//  give error message
		echo "Privilege exists for this group, update aborted.";
		return false;
	}
	
	// assign the group the privilege
    $szSQL = "INSERT INTO ".TBL_GROUP_PRIV." ( ".FLD_GROUP_PRIV_ID." , ".
    	FLD_GROUP_PRIV_CODE." ) VALUES ('".$nGroupId."', '".$szCodeId."');";
	
	// execute sql
	$oResult = $oDbHandle->Execute( $szSQL );
	
    // verify results
	return $oResult !== false;
}

function removePrivilegeFromGroup( $oDbHandle, $szPrivCode, $szGroup )
{
	// check if group exists
	$szSQL = "SELECT * FROM ".TBL_GROUP." WHERE ".
									FLD_GROUP_NAME."='".$szGroup."'";
	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// verify results
	if ( $oResult === false || $oResult->RowCount() <= 0 )
	{
		// give error
		echo "Group(".$szGroup.") does not exist.";
		return false;
	}
	else
	{
		// record the id for the group
		$oRow = $oResult->FetchObject( false );
		eval( "\$nGroupId = \$oRow->".FLD_GROUP_ID.";");
	}

	// initialize parallel array for code index
	$anPrivId = array();
	
	// divide priv up into pieces
	$aszPrivCode = explode( ".", $szPrivCode );
	
	// loop and check to see if each code exists
	$szCodeNotFound = ""; 
	foreach( $aszPrivCode as $szCode )
	{
		// check if the wildcard is used
		if ( $szCode == "*" )
		{
			// add to code array
			$anPrivId[$szCode] = "*";
			continue;
		}
		
		// get code
		$szSQL = "SELECT * FROM ".TBL_PRIV." WHERE ".
										FLD_PRIV_NAME."='".$szCode."'";
		// execute the statement
		$oResult = $oDbHandle->Execute( $szSQL );
		
		// verify results
		if ( $oResult === false || $oResult->RowCount() <= 0 )
		{
			// set flag and exit loop
			$szCodeNotFound = $szCode;
			break;
		}
		else
		{
			// push the id onto the new array
			$oRow = $oResult->FetchObject( false );
			eval( "\$anPrivId[\$szCode] = \$oRow->".FLD_PRIV_ID.";");
		}
	}
	
	// check if all cods were found
	if ( $szCodeNotFound != "" )
	{
		// give error
		echo "The requested code(".$szCodeNotFound.
		") was not found in the database.  Privilege removal was aborted.";
		return false;
	}
	
	// loop and build new id code string
	$szCodeId = "";
	foreach( $aszPrivCode as $szCode )
	{
		$szCodeId .= $anPrivId[$szCode].".";
	}
	$szCodeId = substr( $szCodeId, 0, -1 );

	// check if the privilege exists for this group
	$szSQL = "SELECT * FROM ".TBL_GROUP_PRIV."  INNER JOIN ".TBL_GROUP.
		" ON ".TBL_GROUP_PRIV.".".FLD_GROUP_PRIV_ID."=".TBL_GROUP."."
		.FLD_GROUP_ID." WHERE ".TBL_GROUP.".".FLD_GROUP_NAME."='".$szGroup.
		"' AND ".TBL_GROUP_PRIV.".".FLD_GROUP_PRIV_CODE."='".$szCodeId."'";

	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// verify results
	if ( $oResult !== false && $oResult->RowCount() > 0 )
	{
		// remove the group the privilege
	    $szSQL = "DELETE FROM ".TBL_GROUP_PRIV." WHERE ".FLD_GROUP_PRIV_ID.
	    	"='".$nGroupId."' AND ".FLD_GROUP_PRIV_CODE."='".$szCodeId."';";

		// execute sql
		$oResult = $oDbHandle->Execute( $szSQL );
		
	    // verify results
		return $oResult !== false;
	}
	else 
	{
		// give error
		echo "Privilege does not exist for this group.  Removal not required.";
	}
	
	// return false
	return false;
}

function assignGroupToUser( $oDbHandle, $szUserName, $szGroup )
{
	// check if user exists
	$szSQL = "SELECT * FROM ".TBL_USERS." WHERE ".
									FLD_USERS_NAME."='".$szUserName."'";
	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// verify results
	if ( $oResult === false || $oResult->RowCount() <= 0 )
	{
		// give error
		echo "User(".$szUserName.") does not exist.";
		return false;
	}
	else
	{
		// record the id for the user
		$oRow = $oResult->FetchObject( false );
		eval( "\$nUserId = \$oRow->".FLD_USERS_ID.";");
	}
	
	// check if group exists
	$szSQL = "SELECT * FROM ".TBL_GROUP." WHERE ".
									FLD_GROUP_NAME."='".$szGroup."'";
	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// verify results
	if ( $oResult === false || $oResult->RowCount() <= 0 )
	{
		// give error
		echo "Group(".$szGroup.") does not exist.";
		return false;
	}
	else
	{
		// record the id for the group
		$oRow = $oResult->FetchObject( false );
		eval( "\$nGroupId = \$oRow->".FLD_GROUP_ID.";");
	}

	// check if the group exists for this user
	$szSQL = "SELECT * FROM ".TBL_USERS_PRIV." WHERE ".FLD_USERS_PRIV_USERID.
			"='".$nUserId."' AND ".FLD_USERS_PRIV_GROUPID."='".$nGroupId."'";

	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// verify results
	if ( $oResult !== false && $oResult->RowCount() > 0 )
	{
		//  give error message
		echo "User already belongs to this group, update aborted.";
		return false;
	}
	
	// assign the group to the user
    $szSQL = "INSERT INTO ".TBL_USERS_PRIV." ( ".FLD_USERS_PRIV_USERID." , ".
    	FLD_USERS_PRIV_GROUPID." ) VALUES ('".$nUserId."', '".$nGroupId."');";
	
	// execute sql
	$oResult = $oDbHandle->Execute( $szSQL );
	
    // verify results
	return $oResult !== false;
}

function removeGroupFromUser( $oDbHandle, $szUserName, $szGroup )
{
	// check if user exists
	$szSQL = "SELECT * FROM ".TBL_USERS." WHERE ".
									FLD_USERS_NAME."='".$szUserName."'";
	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// verify results
	if ( $oResult === false || $oResult->RowCount() <= 0 )
	{
		// give error
		echo "User(".$szUserName.") does not exist.";
		return false;
	}
	else
	{
		// record the id for the user
		$oRow = $oResult->FetchObject( false );
		eval( "\$nUserId = \$oRow->".FLD_USERS_ID.";");
	}
	
	// check if group exists
	$szSQL = "SELECT * FROM ".TBL_GROUP." WHERE ".
									FLD_GROUP_NAME."='".$szGroup."'";
	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// verify results
	if ( $oResult === false || $oResult->RowCount() <= 0 )
	{
		// give error
		echo "Group(".$szGroup.") does not exist.";
		return false;
	}
	else
	{
		// record the id for the group
		$oRow = $oResult->FetchObject( false );
		eval( "\$nGroupId = \$oRow->".FLD_GROUP_ID.";");
	}

	// check if the group exists for this user
	$szSQL = "SELECT * FROM ".TBL_USERS_PRIV." WHERE ".FLD_USERS_PRIV_USERID.
			"='".$nUserId."' AND ".FLD_USERS_PRIV_GROUPID."='".$nGroupId."'";

	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// verify results
	if ( $oResult !== false && $oResult->RowCount() > 0 )
	{
		// assign the group to the user
	    $szSQL = "DELETE FROM ".TBL_USERS_PRIV." WHERE ".
	    	FLD_USERS_PRIV_USERID."='".$nUserId."' AND ".
	    	FLD_USERS_PRIV_GROUPID."='".$nGroupId."';";
		
		// execute sql
		$oResult = $oDbHandle->Execute( $szSQL );
		
	    // verify results
		return $oResult !== false;
	}
	else
	{
		// give error
		echo "Group(".$nUserId.") does not exist for this user(".$szGroup.").";
	}
	
	// return false
	return false;
}

function addUser( $oDbHandle, $szUserName, $szPassword )
{
	// check if user exists
	$szSQL = "SELECT * FROM ".TBL_USERS." WHERE ".
									FLD_USERS_NAME."='".$szUserName."'";
	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// verify results
	if ( $oResult !== false && $oResult->RowCount() > 0 )
	{
		// give error
		echo "User(".$szUserName.") already exists.";
		return false;
	}
	
	// determine the max id
	$nCounter = 0;
	$szSQL = "SELECT max( ".FLD_USERS_ID." ) AS count FROM ".TBL_USERS;
	
	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// verify results
	if ( $oResult !== false && $oResult->RowCount() > 0)
	{
		// set the next index
		$oRow = $oResult->FetchObject( false );
		$nCounter = $oRow->count;
	}
	
	// increment the counter
	$nCounter++;

	// add user and password
	$szSQL = "INSERT INTO ".TBL_USERS." (".FLD_USERS_ID.",".
		FLD_USERS_NAME.",".FLD_USERS_PASSWORD.") VALUES ('".
		$nCounter."','".$szUserName."','".$szPassword."');";
		
	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// return results
	return $oResult;
}

function deleteUser( $oDbHandle, $nId )
{
	// check if user exists
	$szSQL = "SELECT * FROM ".TBL_USERS." WHERE ".
									FLD_USERS_ID."='".$nId."'";
	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// verify results
	if ( $oResult === false || $oResult->RowCount() <= 0 )
	{
		// give error
		echo "User(".$nId.") does not exist. Delete aborted";
		return false;
	}

	// delete user and password
	$szSQL = "DELETE FROM ".TBL_USERS." WHERE ".FLD_USERS_ID."='".
																$nId."';";
		
	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// verify results
	if ( $oResult !== false )
	{
		// remove any group assignments for this user
		$szSQL = "DELETE FROM ".TBL_USERS_PRIV." WHERE ".
									FLD_USERS_PRIV_USERID."='".$nId."';";
		// execute the statement
		$oResult = $oDbHandle->Execute( $szSQL );
		
		// return results
		return $oResult;
	}
	else
	{
		// give error
		echo "Unable to delete user(".$nId.").";
		return false;
	}
}

function showTable( $oDbHandle, $szTableName )
{
	// get the contents oof the table
	$szSQL = "SELECT * FROM ".$szTableName.";";
	
	// execute the statement
	$oResult = $oDbHandle->Execute( $szSQL );
	
	// display results
	if ( $oResult !== false && $oResult->RowCount() > 0 )
	{
		// start table
		echo "<table border='1' cellpadding='2' cellspacing='2'>\n";
		
		// set border flag
		$bIsTitle = true;
		
		// get object data
		while ( $oRow = $oResult->FetchNextObject( false ) )
		{	
			// get array of parameters
			$aszParameters = get_object_vars( $oRow );
			
			// add title if not done
			if ( $bIsTitle )
			{
				// start a new row
				echo "<tr>\n";				
				
				// add title cell
				foreach( $aszParameters as $key=>$value )
					echo "<td><b>".$key."</b></td>\n";
					
				// close row
				echo "</tr>\n";
					
				// reset title flag
				$bIsTitle = false;
			}
			
			// start a new row
			echo "<tr>\n";
			
			// create new cell for each item
			foreach( $aszParameters as $key=>$value )
			{
				// add new cell
				if ( strlen( trim( $value ) ) == 0 ) $value = "&nbsp;";
				echo "<td>".$value."</td>\n";
			}

			// close row
			echo "</tr>\n";
		}
		
		// close table
		echo "</table>";
	}
	else
	{
		//give error
		echo "Cannot access table(".$szTableName.").";
		return false;
	}
}
?>