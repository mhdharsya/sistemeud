<?php
/**
 * Security services is a utility that help to authentificate
 * and check access of a user.
 *
 */

/**
 * This is the abstract class
 * This specific class is a abstract class. It only specify interface
 * to implement. For example, there can be a generalization of this 
 * class to represent a user privilege code from a database or a XML
 * file.
 * 
 * Package(s) used: 
 * 
 * @author Sacha Fournier (sfournier@dmsolutions.ca)
 * @project PhpUtil
 * @revision $Id
 * @purpose Manage application security.
 * @copyright Copyright DM Solutions Group Inc 2002
 * 
 */
class PrivCode
{
	// define member variables
	var $oErrorManager;    
    var $szPrivCode;

    /**
     * Very useful constructor... Not !
     */
    function PrivCode()
    {
        $this->szPrivCode = "";
    }
    
    /**
     * This function check if user priv code
     * is part of this->privcode.
     * 
     * @param oUserPrivCode - Priv code to check
     * 
     * $return True if user priv code is part of privcode
     */
    function IsIn($oUserPrivCode)
    {
        /**
         * If current privcode contain a "*"
         * we remove it and trunk user privcode
         * to the same size.
         */
        if (strchr($this->szPrivCode, "*")) // if it contain a "*"
        {
            // remove "*"
            $szTmpUserPrivCode = substr($this->szPrivCode, 0, strlen($this->szPrivCode)-1);
            
            // Trunk UserPrivCode to the same size of current priv code
            $szTmpPrivCode = substr($oUserPrivCode->szPrivCode, 0, strlen($this->szPrivCode)-1);
        }
        else // nothing to do...
        {
            $szTmpUserPrivCode = $oUserPrivCode->szPrivCode;
            $szTmpPrivCode = $this->szPrivCode;
        }

        // Check if is in.
        if (strstr($szTmpPrivCode, $szTmpUserPrivCode) != false)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
   
    /*
     * Pure virtual function(s)
     */
    
    /**
     * Create depends on media used. For this reason it
     * must be defined by other classes.
     */
    function Create($szProgId)
    {
    }
    
    /**
     * error()
     *
     * Postcondition:  This method will log errors if the instatiating 
     *				   application sets the error manager.
     * @param $nCode integer - Error code.
     * @param $szMessage string - Error message.
     * @return void.
     * @desc Log error.
     **/
    function error( $nCode, $szMessage )
    {
    	// check if an error manager is set
    	if ( isset( $this->oErrorManager ) )
    	{
    		$this->oErrorManager->error( $nCode, $szMessage );
    	}
    }
}
?>
