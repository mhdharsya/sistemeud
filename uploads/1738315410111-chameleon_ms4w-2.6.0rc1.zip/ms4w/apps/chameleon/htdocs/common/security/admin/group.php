<?php
/**
 * PHP_UTILS
 *
 * @project     PHP_UTILS
 * @revision    $Id: group.php,v 1.1 2003/09/17 19:38:16 bronsema Exp $
 * @purpose     This is the user information page.
 * @author      William A. Bronsema, C.E.T. (dev@dmsolutions.ca)
 * @copyright
 * <b>Copyright (c) 2003, DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 **/

// include the admin functions
include( "./admin.php" );
 
/* ============================================================================
 * Get form variables independant of GET or POST.
 * ========================================================================= */
$_FORM = array_merge($_GET, $_POST);

/* ============================================================================
 * Connect to database
 * ========================================================================= */
if ( !$oConn = connect( $szConnType, $szConnHost, $szConnUser, $szConnPassword, 
															$szConnDatabase ) )
	exit( "Connection failed" );

/* ============================================================================
 * Process add group request
 * ========================================================================= */
if ( isset( $_FORM["butAddGroup"] ) )
{
	// add user
	if ( !addGroup( $oConn, $_FORM["txtAGroupName"] ) )
	{
		// give error message
		echo "<br>An error occurred adding the group to the database.<br>";
	}
}

/* ============================================================================
 * Process delete group request
 * ========================================================================= */
if ( isset( $_FORM["butDeleteGroup"] ) )
{
	// delete user
	if ( !deleteGroup( $oConn, $_FORM["txtDGroupName"] ) )
	{
		// give error message
		echo "<br>An error occurred deleting the group from the database.<br>";
	}
}
?>