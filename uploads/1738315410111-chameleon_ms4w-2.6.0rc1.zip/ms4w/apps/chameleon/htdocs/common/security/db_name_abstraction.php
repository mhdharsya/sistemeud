<?php
/**
 * PHP_UTILS
 *
 * @project     PHP_UTILS
 * @revision    $Id: db_name_abstraction.php,v 1.7 2003/09/18 18:59:40 bronsema Exp $
 * @purpose     This is the global preferences page.
 * @author      William A. Bronsema, C.E.T. (dev@dmsolutions.ca)
 * @copyright
 * <b>Copyright (c) 2003, DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 **/

/* ============================================================================
 * Define the table names and fields
 * ========================================================================= */
// users table name
define( "TBL_USERS", "com_profile" );

// users table field names
define( "FLD_USERS_ID", "id" );
define( "FLD_USERS_NAME", "user_name" );
define( "FLD_USERS_PASSWORD", "password" );

// group table name
define( "TBL_GROUP", "sec_groups" );

// group table field names
define( "FLD_GROUP_ID", "id" );
define( "FLD_GROUP_NAME", "name" );

// privileges table name
define( "TBL_PRIV", "sec_privileges" );

// privileges table field names
define( "FLD_PRIV_ID", "id" );
define( "FLD_PRIV_NAME", "name" );

// group privileges table name
define( "TBL_GROUP_PRIV", "sec_groupprivileges" );

// group privileges table field names
define( "FLD_GROUP_PRIV_UNIQUEID", "id" );
define( "FLD_GROUP_PRIV_ID", "group_id" );
define( "FLD_GROUP_PRIV_CODE", "code" );

// user privileges table name
define( "TBL_USERS_PRIV", "sec_userprivileges" );

// user privileges table field names
define( "FLD_USERS_PRIV_ID", "id" );
define( "FLD_USERS_PRIV_USERID", "user_id" );
define( "FLD_USERS_PRIV_GROUPID", "group_id" );

?>