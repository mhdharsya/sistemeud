<?php
/*
 * Security services is a utility that help to authentificate
 * and check access of a user.
 * 
 */

// include necessary files
if ( !defined( "COMMON" ) ) define( "COMMON", "../" );
$szCommon = str_replace( "\\", "/", realpath( COMMON ) )."/";
include_once( $szCommon."security/db_name_abstraction.php" );

/**
 * UserConnection is a base class that should be generalized.
 * This specific class is a abstract class. It only specify interface
 * to implement. For example, there can be a generalization of this 
 * class to manage a user connection over a database or XML files.
 * 
 * Package(s) used: 
 * 
 * @author Sacha Fournier (sfournier@dmsolutions.ca)
 * @project PhpUtil
 * @revision $Id
 * @purpose Manage application security.
 * @copyright Copyright DM Solutions Group Inc 2002
 * 
 */
class UserConnection 
{
	// define member variables
	var $oErrorManager;    
    var $szSessionId; /// Store a unique ID in string format
    var $szUserName;  /// User name used on login page
    var $nUserId;     /// Can be useful
    var $axProperties;  // array of availble field values
    var $nExpTime;    /// This is when the UserConnection obj becode invalid
    var $aoUserPrivCode; /// Array of user privileges.
    var $aszHistory; /// User session history

    /**
     * Not very useful constructor...
     */
    function UserConnection()
    {
        $this->aszHistory = array();
        $this->aoUserPrivCode = array();
    }
    
    /*
     * This function populate mandatory variable for a conection.
     * Some variables like szSessionId and nExpTime are defined
     * in this function.
     *
     * @param $szTmpUserName  - USer name used when login.
     * @param $nTmpUserId - UserId of current user.
     * @param $axProperties - Array of fields in user table
     *
     * @return
     **/
    function Create($szTmpUserName, $nTmpUserId, $axProperties)
    {
        // Generae a unique id
        $this->szSessionId = md5(uniqid(getmypid(), true));
        
        // Some user defined variables
        $this->szUserName  = $szTmpUserName;
        $this->nUserId     = $nTmpUserId;
        $this->axProperties  = $axProperties;
        
        // Set expiration time to one hour starting now.
        $this->nExpTime    = time() + 3660;

        $this->LoadUserPrivileges();

        // Save it
        $this->Store();
    }
    
    /**
     * this function check if "$oPrivCode"
     * is valid for at least one of UserPrivileges.
     * 
     * $param $oPrivCode = PrivCode object to check if user have access to.
     * 
     * @return True if user have access.
     */
    function HasAccessTo($oPrivCode)
    {
        // If session expired
        if (!$this->IsExpired())
        {
            // if not, set it to an hour
            $this->nExpTime  = time() + 3660;

            /*
             * Look all user privileges in array
             */
            foreach($this->aoUserPrivCode as $oUserPrivCode)
            {
                // Check if $oPrivCode is in $oUserPrivCode
                if ($oUserPrivCode->IsIn($oPrivCode))
                {
                    return true;
                }
            }
        }
        else
        {
            // error
            $this->error(1, "Session no more valid.");
            
            return false;
        }
        
        return false;
    }

    /**
     * Add a record in user session history.
     * 
     * @param $szHistory - Something to log into history.
     * 
     * @return 
     */
    function AddHistory($szHistory)
    {
        array_push($this->aszHistory, date("[M d Y : H:i:s]", time()) . "  $szHistory");
        $this->Store();
    }
    
    /**
     * Only check if current session is expired.
     * 
     * @return true of false (if session is expired).
     */
    function IsExpired()
    {
        if ($this->nExpTime < time())
           $bRes = true;
        else
           $bRes = false;
        return $bRes;
    }
    
    /*
     * Next functions are pure virtual functions. That
     * mean that Classes based on this class, MUST define
     * theese functions.
     */
    
    /**
     * Pure virtual function.
     * must be defined.
     */
    function LoadUserPrivileges()
    {
    }
    
    /**
     * Pure virtual function.
     * must be defined.
     */    
    function Restore()
    {
    }
    
    /**
     * Pure virtual function.
     * must be defined.
     */    
    function Store()
    {
    }
    
    /**
     * error()
     *
     * Postcondition:  This method will log errors if the instatiating 
     *				   application sets the error manager.
     * @param $nCode integer - Error code.
     * @param $szMessage string - Error message.
     * @return void.
     * @desc Log error.
     **/
    function error( $nCode, $szMessage )
    {
    	// check if an error manager is set
    	if ( isset( $this->oErrorManager ) )
    	{
    		$this->oErrorManager->error( $nCode, $szMessage );
    	}
    }
}
?>
