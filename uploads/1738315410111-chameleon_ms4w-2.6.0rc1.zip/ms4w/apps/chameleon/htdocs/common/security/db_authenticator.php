<?php
/*
 * Security services is a utility that help to authentificate
 * and check access of a user.
 */

// include necessary files
if ( !defined( "COMMON" ) ) define( "COMMON", "../" );
$szCommon = str_replace( "\\", "/", realpath( COMMON ) )."/";
include_once( $szCommon."security/db_name_abstraction.php" );
include_once( $szCommon."security/authenticator.php" );
include_once( $szCommon."security/db_user_connection.php" );
//include( $szCommon."adodb/adodb.inc.php" );

/**
 *
 * This specific class is a generalization of Authentification
 * abstract class. It is database specific. This class check if
 * user exist in database and create a new userconnection obj.
 * 
 * Package(s) used: Authentification, DBUserConnection, adodb
 * 
 * @author Sacha Fournier (sfournier@dmsolutions.ca)
 * @project PhpUtil
 * @revision $Id
 * @purpose Manage application security.
 * @copyright Copyright DM Solutions Group Inc 2002
 * 
*/
class DBAuthenticator extends Authenticator
{
    var $oADODBConnection; /// Connection that object must use.
    
    /**
     * Set database connection
     */
    function DBAuthenticator($oTmpADODBConnection)
    {
        // call parent
        parent::Authenticator();

        $this->oADODBConnection = $oTmpADODBConnection;
    }
    
    /**
     * Check if user exist in tblUsers table
     * if so create a new DBUserConnection object.
     * 
     * @param szUserName - user name
     * @param szPassword - Password
     * 
     * @return New UserConnection
     */
    function Login($szUserName, $szPassword)
    {
        // call parent
        parent::Login($szUserName, $szPassword);
        
        // Look for a user and password.
        $sql = "SELECT * from ".TBL_USERS." WHERE ".FLD_USERS_NAME."=\"".$szUserName."\" AND ".FLD_USERS_PASSWORD."=\"".$szPassword."\"";
        
        $res = $this->oADODBConnection->Execute($sql);
        
        if (!$res || $res->RowCount() == 0)
        {
            $this->error(1, "User does not exist or bad password.");
            
            return false;
        }
        
        // Login OK !!!
        
        // Now we must create a UserConnection obj
        // With all required fields.
        
        // Get UserId and Full name
        $row = $res->FetchObject(false);
        eval( "\$nUserId = \$row".'->'.FLD_USERS_ID.";" );

        $oUserConnection = new DBUserConnection($this->oADODBConnection);
        $oUserConnection->Create($szUserName, $nUserId, $row);
        return $oUserConnection;
    }
    
    /**
     * Logout connection
     */
    function Logout()
    {
        parent::Logout();
        return true;
    }
}
?>
