<?php
/*
 * Security services is a utility that help to authentificate
 * and check access of a user.
 *
*/

// include necessary files
if ( !defined( "COMMON" ) ) define( "COMMON", "../" );
$szCommon = str_replace( "\\", "/", realpath( COMMON ) )."/";
include_once( $szCommon."security/db_name_abstraction.php" );
include_once( $szCommon."security/priv_code.php" );
include_once( $szCommon."/adodb/adodb.inc.php");

/**
 * This specific class is a generalization of PrivCode abstract class. 
 * It is database specific. Is represend a Privilege code.
 * 
 * Package(s) used: PrivCode, adodb
 *
 * @author Sacha Fournier (sfournier@dmsolutions.ca)
 * @project PhpUtil
 * @revision $Id
 * @purpose Manage application security.
 * @copyright Copyright DM Solutions Group Inc 2002
 * 
 */
class DBPrivCode extends PrivCode
{
    var $oADODBConnection;

    /**
     * Set database connection.
     */
    function DBPrivCode($oADODBConnection)
    {
        // call parent
        parent::PrivCode();

        $this->oADODBConnection = $oADODBConnection;
    }

    //////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////
    
    /*
     * Pure virtal function(s) are define
     * at this point.
     */
    
    /**
     * Create the new privcode from szProgId
     */
    function Create($szProgId)
    {
        // Seperate all prog id
        $aProgId = explode(".", $szProgId);

        // for each part of progId
        foreach($aProgId as $szTmpProgId)
        {
            // Look into tblPrivileges for numeric
            // value.
            $sql = "SELECT ".FLD_PRIV_ID." FROM ".TBL_PRIV." WHERE ".FLD_PRIV_NAME."=\"".$szTmpProgId."\"";
            $res = $this->oADODBConnection->Execute($sql);
         
            // Build the new string (privCode)
            if ($res && $row = $res->FetchNextObject( false ) )
                eval ( "\$this->szPrivCode .= \"\$row->".FLD_PRIV_ID.".\";");
            else
            {
                //error
                $this->error(1, "No PrivName (".$szTmpProgId.") in ".TBL_PRIV." table." );
                
                return false;
            }
        }
        
        if (strlen($this->szPrivCode) > 0)
          $this->szPrivCode = substr($this->szPrivCode, 0, strlen($this->szPrivCode)-1);
        else
        {
            //error
            $this->error(1, "No PrivCode generated.");
            
            return false;
        }
        
        return true;
    }
}
?>
