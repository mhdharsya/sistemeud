<?php

// define the common folder
define( "COMMON","../../" );

include_once( COMMON."security/db_authenticator.php" );
include_once( COMMON."adodb/adodb.inc.php" );

$dbConn = ADONewConnection("mysql");
$dbConn->Connect("localhost", "", "", "newadmin");

$oAuth = new DBAuthenticator($dbConn);
//$oAuth->setLogFile($logFile);

$conn = $oAuth->Login("bill", "bob");

if ($conn !== false)
{
   
    echo "Hello ".$conn->axProperties->first_name." ".$conn->axProperties->last_name."<br>";
    echo "You have the following privileges:<br>";
    foreach ( $conn->aoUserPrivCode as $userCode )
        echo $userCode->szPrivCode."<br>";

    if ($conn->HasAccessTo("MyProg.MyFunc.edit") == 1)
      echo "Access granted";
    else
      echo "Access denied";
}
else
    echo "Connection failed";

?>
