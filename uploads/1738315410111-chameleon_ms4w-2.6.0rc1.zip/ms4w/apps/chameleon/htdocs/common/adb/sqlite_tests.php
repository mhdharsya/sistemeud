<?php
/* test cases for adb sqlite */
$db = '/tmp/sqlitedb';

include( 'adb_sqlite.php' );
report('creating new dbSqlite instance on '.$db);

clearstatcache();
if (file_exists($db)) unlink($db);
$oDB = new dbSqlite($db);

report('initializing dbSqlite instance');
if (!$oDB->initialize())
{
    report( $oDB->lastError() );
    exit;
}
testSQL( 'CREATE TABLE (1)', 'CREATE TABLE foo (bar varchar(10))' );
testSQL( 'DROP TABLE(1)', 'DROP TABLE foo' );

$szSQL = <<<EOT
CREATE TABLE users ( 
     userid INTEGER PRIMARY KEY, 
     username VARCHAR(30) NOT NULL UNIQUE,
     password VARCHAR(32) NOT NULL,
     disabled VARCHAR(255) DEFAULT '');
EOT;
testSQL( 'CREATE TABLE(2)', $szSQL );

$szUser = 'pspencer';
$szPassword = md5("test");
$szSQL = <<<EOT
INSERT INTO users (userid, username, password) VALUES (null,'{$szUser}','{$szPassword}');
EOT;
testSQL( 'INSERT USER(1)', $szSQL );

$szUser = 'jfournier';
$szPassword = md5("test2");
$szSQL = <<<EOT
INSERT INTO users (userid, username, password) VALUES (null,'{$szUser}','{$szPassword}');
EOT;
testSQL( 'INSERT USER(2)', $szSQL );

$szUser = 'fwarnock';
$szPassword = md5("test3");
$szSQL = <<<EOT
INSERT INTO users (userid, username, password) VALUES (null,'{$szUser}','{$szPassword}');
EOT;
testSQL( 'INSERT USER(3)', $szSQL );

testSQL( 'SELECT USER', "select * from users" );

testSQL( 'SELECT USER by NAME', "select * from users where username = 'jfournier'" );
testSQL( 'SELECT USER by NAME and PASSWORD', "select * from users where username='jfournier' and password='".md5('test2')."'" );

testSQL( 'SELECT USER by NAME and PASSWORD - FAIL', "select * from users where username='jfournier' and password='".md5('test1')."'" );

testSQL( 'DROP TABLE(2)', 'DROP TABLE users' );


function testSQL($szTestTitle, $szSQL)
{
    global $oDB;
    report("test ".$szTestTitle);
    report("executing: ".$szSQL );
    $oRS = $oDB->execute($szSQL);
    if($oRS === false)
    {
        report($oDB->lastError());
        exit;
    }
    else
    {
        report($szTestTitle." passed!");
    }
    if (is_object($oRS) && $oRS->numRows() > 0)
    {
        echo "<table>\n";
        echo "<tr>\n";
        for($i=0;$i<$oRS->numFields();$i++)
            echo "<td>".$oRS->fieldName($i)."</td>\n";
        echo "</tr>\n";
        for($i=0;$i<$oRS->numRows();$i++)
        {
            $oRec = $oRS->getNext();
            echo "<tr>\n";
            foreach($oRec->asArray() as $k=>$v)
            {
                echo "<td>$v</td>\n";
            }
            echo "</tr>\n";
        }
        echo "</table>\n";
    }
    elseif (is_object($oRS))
    {
        echo "no rows found!<br>\n";
    }
    else
    {
        echo $oRS." rows affected<br>\n";
    }
}

function report($szMessage)
{
    echo "$szMessage.<BR>\n";
}
?>