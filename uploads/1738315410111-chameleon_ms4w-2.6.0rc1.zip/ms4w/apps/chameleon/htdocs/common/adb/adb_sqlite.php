<?php
/**
 *
 * @project     Chameleon
 * @revision    $Id: adb_sqlite.php,v 1.2 2005/03/15 14:13:24 pspencer Exp $ 
 * @purpose     sqlite adb concrete class
 * @author      DM Solutions Group (pspencer@dmsolutions.ca)
 * @copyright
 * <b>Copyright (c) 2002, DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
include_once('adb.php');

if (!extension_loaded('sqlite'))
{
    $s = 'php_sqlite.'.PHP_SHLIB_SUFFIX;
    if (!@dl($s))
    {
        $s = 'sqlite.'.PHP_SHLIB_SUFFIX;
        if (!@dl($s))
        {
            echo "FATAL ERROR: could not load sqlite extension.  I tried php_sqlite.".PHP_SHLIB_SUFFIX." and sqlite.".PHP_SHLIB_SUFFIX;
            exit;
        }
    }
}

class dbSqlite extends dbAbstractDatabase 
{
    var $mszFilename = '';
    var $mnMode = 0666;
    var $mszError = '';
    
    function dbSqlite($filename)
    {
        $this->mszFilename = $filename;
    }
    
    function initialize()
    {
        $error = '';
        $this->hDB = sqlite_open( $this->mszFilename, $this->mnMode, $error );
        if (!$this->hDB)
        {
            $this->mszError = $error;
            return false;    
        }
        else
        {
            /* turn on short column names.  Without this, slqite
             * will return tablename.columnname as the key in 
             * associative array results
             */
            sqlite_exec($this->hDB, 'PRAGMA short_column_names = ON');
            sqlite_exec($this->hDB, 'PRAGMA full_column_names = OFF');
            return true;
        }
    }
    
    
    function execute($szSQL)
    {
        if (!$this->hDB)
        {
            $this->mszError = 'database not initialized.  Query failed.';
            return false;
        }
        //make sure that the SQL is safe ...
        //$szSQL = sqlite_escape_string($szSQL);
        /* distinguish between select and all other query types */
        if (stristr($szSQL, 'SELECT' ) !== false)
        { 
            $h = sqlite_query($this->hDB, $szSQL);
            if (!$h)
            {
                $this->mszError = sqlite_error_string(sqlite_last_error($this->hDB));
                return false;
            }
            else 
            {
                return new dbSqliteRecordset( $this, $h );
            }
        }
        else 
        {
            $h = sqlite_exec($this->hDB, $szSQL);
            if (!$h)
            {
                $this->mszError = sqlite_error_string(sqlite_last_error($this->hDB));
                return false;    
            }
            else 
            {
                return sqlite_changes($this->hDB);
            }
        }
    }
    
    /**
     * returns the error message from the last operation, if any.
     *
     * @return string the last error message, empty string if no error
     */
    function lastError()
    {
        return $this->mszError;
    }
    
    function lastid()
    {
        return sqlite_last_insert_rowid($this->hDB);
    }
}

class dbSqliteRecordset extends dbRecordset 
{
    function dbSqliteRecordset( $oDB, $hRecordset )
    {
        parent::dbRecordset($oDB, $hRecordset);
        $this->mnRows = sqlite_num_rows($hRecordset);
        $this->mnFields = sqlite_num_fields($hRecordset);
        for($i=0;$i<$this->mnFields;$i++)
            $this->maszFieldNames[$i] = sqlite_field_name($hRecordset, $i);
    }
    
    function getNext()
    {
        $a = sqlite_fetch_array($this->hRecordset, SQLITE_ASSOC);
        if ($a!==null && $a!==false)
            return new dbRecord( $a );
        else
            return null;
    }
}
?>