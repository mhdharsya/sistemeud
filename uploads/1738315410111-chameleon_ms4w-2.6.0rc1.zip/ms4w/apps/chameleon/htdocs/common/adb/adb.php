<?php
/**
 *
 * @project     Chameleon
 * @revision    $Id: adb.php,v 1.1 2005/02/21 20:49:39 pspencer Exp $ 
 * @purpose     Generic database wrappers
 * @author      DM Solutions Group (pspencer@dmsolutions.ca)
 * @copyright
 * <b>Copyright (c) 2002, DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/**
 * dbAbstractDatabase is an abstract base class that defines the general
 * characteristics of a database connection.  It is expected that concrete
 * sub-classes of dbAbstractDatabase will implement the dbAbstractDatabase
 * API and that developers can develop against just the dbAbstractDatabase
 * API.
 *
 */
class dbAbstractDatabase
{
    /**
     * a handle to the database.  Null until initialized.
     *
     * @var handle
     */
    var $hDB = null;
    
    /**
     * default constructor, does nothing in the abstract base class
     *
     * @return dbAbstractDatabase
     */
    function dbAbstractDatabase()
    {
    }
    
    /**
     * place holder for an initialization function to be implemented
     * in concrete sub-classes.
     * @return boolean true if initialization was successful, false otherwise
     */
    function initialize()
    {
        return false;
    }
    
    /**
     * execute an sql statement and return a recordset object or the number of
     * of rows affected if the query is not a SELECT query.  Returns false
     * if the query failed.  Note that this function can return 0 as a valid
     * result if a non-SELECT query is run and no rows are affected, so you
     * MUST use exact tests for false i.e. 
     * $h = $oDB->execute( $szSQL );
     * if ($h !== false) { //query succeeded }
     * if ($h === false) { //query failed }
     *
     * @param string $szSQL
     * @return dbRecordset a recordset object for accessing the results, and
     *         integer or false
     */
    function execute($szSQL)
    {
        return false;
    }
    
    
    /**
     * returns the id form the last INSERT query if the table inserted
     * into contains an autoincrement field.
     *
     * @return integer the id from the last INSERT
     */
    function lastid()
    {
        return null;
    }
}

class dbRecordset
{
    var $moAdb = null;
    var $hRecordset = null;
    var $mnRows = 0;
    var $mnColumns = 0;
    var $maszFieldNames = array();
    
    function dbRecordset( $oDB, $hRecordset )
    {
        $this->moAdb = $oDB;
        $this->hRecordset = $hRecordset;
    }
    
    function getNext()
    {
        return null;
    }
    
    function numRows()
    {
        return $this->mnRows;
    }
    
    function numFields()
    {
        return $this->mnFields;
    }
    
    function fieldName($i)
    {
        return isset( $this->maszFieldNames[$i] ) ? $this->maszFieldNames[$i] : '';
    } 
}

/**
 * A single result from a recordset, wrapped as an object
 * for convenience.
 *
 */
class dbRecord
{
    var $maRecord;
    
    /**
     * construct a new record object
     *
     * @param array an associative array of fields and values
     * @return dbRecord
     */
    function dbRecord($aRecord)
    {
        $this->maRecord = $aRecord;
    }
    
    /**
     * get an individual result from the record
     *
     * @param string a field name to retrieve
     * @return mixed the value of the requested field or null if not set.
     */
    function get($szField)
    {
        return isset($this->maRecord[$szField])?$this->maRecord[$szField]:null;
    }
    
    /**
     * return the entire record as an associative array
     *
     * @return array an associative array of all fields
     */
    function asArray()
    {
        return $this->maRecord;
    }
}
?>