// Mod: Journal for Xin Calendar 2X (In-Page/Popup-Window)
// Copyright 2004  Xin Yang    All Rights Reserved.

function xc_cy(date){var ft=xcLinkBasePath+xcLinkPrefix+xc_bz(this.il,this.month,date,xcLinkDateFormat)+xcLinkSuffix;if(xcLinkTargetWindow){return ['window.open("'+ft+'","'+xcLinkTargetWindow+'","'+xcLinkTargetWindowPara+'");',0]}else{return ['location.href="'+ft+'";',0]}};
