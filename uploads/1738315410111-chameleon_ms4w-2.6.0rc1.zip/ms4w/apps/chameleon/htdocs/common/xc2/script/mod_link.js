// Mod: Date Link for Xin Calendar 2X (In-Page/Popup-Window)
// Copyright 2004  Xin Yang    All Rights Reserved.

function addDateLink(ca,cg,ch,dn,date,ib){var gt=xc_cj(date,dn||xcDateFormat);xc_dv(ca,"dr",gt[0]+xc_bx(gt[1]+1)+xc_bx(gt[2]),[cg||co[0],ch||co[1],ib],0)};var co=xcCSSDaySpecial;function xc_cy(date){var fh=xc_bf(this,date);if(fh){if(xcLinkTargetWindow){return ['window.open("'+xcLinkBasePath+fh[2]+'","'+xcLinkTargetWindow+'","'+xcLinkTargetWindowPara+'");',0]}else{return ['location.href="'+xcLinkBasePath+fh[2]+'";',0]}}else{return ["",1]}};function xc_db(date){var fh=xc_bf(this,date);if(fh){return 'this.title="'+xcLinkBasePath+fh[2]+'";'}else{return ""}};function xc_bf(bb,date){return bb.ff("dr",xc_bx(bb.il)+xc_bx(bb.month+1)+xc_bx(date))};xc_en[xc_en.length]=xc_bf;
