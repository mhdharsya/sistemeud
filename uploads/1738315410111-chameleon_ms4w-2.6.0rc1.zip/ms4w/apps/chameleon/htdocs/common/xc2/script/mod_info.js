// Mod: Date Info for Xin Calendar 2X (In-Page/Popup-Window)
// Copyright 2004  Xin Yang    All Rights Reserved.

function addDateInfo(ca,cd,cf,ce,dn,date,fq,fz){var gt=getDateNumbers(date,dn||xcDateFormat);xc_dv(ca,"dq",(fz?gt[0]:"")+gt[1]+gt[2],[cd||co[0],cf||co[1],ce||"",fq],0)};var co=xcCSSDaySpecial;function xc_bm(style,cb,width,et){if(this.date!=0){var fg=this.ff("dq",xc_bx(this.il)+xc_bx(this.month+1)+xc_bx(this.date))||this.ff("dq",xc_bx(this.month+1)+xc_bx(this.date));if(fg){cb+=xcDIV(fg[2],fg[3],"")}};return xc_eq(style,cb,width,et)};function xc_be(bb,date){return bb.ff("dq",xc_bx(bb.il)+xc_bx(bb.month+1)+xc_bx(date))||bb.ff("dq",xc_bx(bb.month+1)+xc_bx(date))};xc_en[xc_en.length]=xc_be;
