// Xin Calendar 2X (Popup Window Core/Window Control)
// Copyright 2004  Xin Yang    All Rights Reserved.

// Web Site: yxScripts.com
// Email: m_yangxin@hotmail.com

var xc_fl=null;function xc_ch(){return(window.opener&&!window.opener.closed&&window.opener.xcCore&&window.opener.xcCore==2)?window.opener:null};function xc_di(fo,dy){xc_fl=xc_ch();if(xc_fl){xc_fl.xc_di(fo,dy)}};function xc_dh(fo,dm){xc_fl=xc_ch();if(xc_fl){xc_fl.xc_dh(fo,dm)}};function xc_az(fo){xc_fl=xc_ch();if(xc_fl){xc_fl.xc_az(fo)}};function xc_ds(fo,date){xc_fl=xc_ch();if(xc_fl){xc_fl.xc_ds(fo,date)}};function xc_ef(fo){xc_fl=xc_ch();if(xc_fl){xc_fl.xc_ef(fo)}};function xc_cm(fo){xc_fl=xc_ch();if(xc_fl){xc_fl.xc_cm(fo)}};function xc_eg(fo,y){xc_fl=xc_ch();if(xc_fl){xc_fl.xc_eg(fo,y)}};function xc_ee(fo,m){xc_fl=xc_ch();if(xc_fl){xc_fl.xc_ee(fo,m)}};function xc_ei(){xc_fl=xc_ch();if(xc_fl){xc_fl.xc_ei(this.fo)}};function xc_dy(){xc_fl=xc_ch();if(xc_fl){xc_fl.xc_dy(this.fo)}};function xc_cc(id){return id==""?null:document.getElementById(id)};function xc_eh(e,fo,name){xc_fl=xc_ch();var l=xc_cc("xcPopup");if(l&&xc_fl){var go=location.search.substring(1);var id=fo?fo:/^id=(xc\d+)\&/.test(go)?(RegExp.$1):(window.name||"");document.fo=id;document.onmouseover=xc_dy;document.onmouseout=xc_ei;document.title=unescape(name||go.substring(go.indexOf("title=")+6));xc_fl.xc_cp(l,id)}};window.onload=xc_eh;
