<?php
include_once("session.php");

installSessionDirectoryHandler();
initializeSession("sid", "/tmp/");

echo "TEST: Session Started<br>";
echo "Now waiting 10 seconds. Session won't be close before this time.<br>";
echo "start time is ".time()."<BR>";
sleep(10);
if (!isset($_SESSION["test"]))
{
    $_SESSION["test"] = 0;
}
else
    $_SESSION["test"] = $_SESSION["test"] + 1;
echo "TEST: test is ".$_SESSION["test"]."<BR>";
echo "final time is ".time()."<BR>";
//session_write_close();
//echo "TEST: Session closed";
?>
