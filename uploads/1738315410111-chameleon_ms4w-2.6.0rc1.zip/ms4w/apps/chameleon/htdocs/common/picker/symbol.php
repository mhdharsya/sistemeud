<?php
/*
 * Symbolizer is a script to create a preview image of a style object
 * It requires access to a mapserver symbol file.
 *
 * Package(s) used: PHPMapscript, gd.
 *
 * @author Sacha Fournier (sfournier@dmsolutions.ca)
 * @project Chameleon
 * @revision $Id: symbol.php,v 1.2 2004/11/23 18:43:29 pspencer Exp $
 * @purpose Symbolizer is a script to create a preview image of a style object
 *          based on symbolizer from studio
 *
 *          Symbol file must be specified in a registered variable.
 *
 *          The PHP mapscript module name can be specified by the
 *          $gszPHPMapScriptModName variable. If not specified, default
 *          name is used.
 *
 * @copyright
 * <b>Copyright (c) 2002, DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 *
 */
error_reporting(E_ALL );
include_once( "../logger/error_manager.php" );
include_once( "../logger/logger.php" );

if (isset($_GET['SID']) && !isset($_GET['sid']))
{
    $_GET['sid'] = $_GET['SID'];
}

include_once("../session/session.php");
include_once("../wrapper/map_session.php" );
installSessionDirectoryHandler();
initializeSession();
/* -------------------------------------------------------------------- */
/*      Load required modules                                           */
/* -------------------------------------------------------------------- */
if (!isset($_SESSION["gszMapscriptModule"]))
    $_SESSION["gszMapscriptModule"] = "php_mapscript.".PHP_SHLIB_SUFFIX;

if (!extension_loaded("MapScript"))
    if (!(@dl(  $_SESSION["gszMapscriptModule"] )))
    {
        echo "unable to load mapscript module ".$_SESSION["gszMapscriptModule"];
        exit;
    }
    

if (!extension_loaded("gd"))
    if (!(@dl( "php_gd2.".PHP_SHLIB_SUFFIX )))
    {
        echo "unable to load GD extension for PHP.";
        exit;
    }// create a new map session object
if ($_SESSION['gnMapSessionMode'] == "1")
{
    $oMapSession = new MapSession_RW;
}
else
{
    $oMapSession = new MapSession_R;
}

// set the global log file and error manager
$oMapSession->setLogFile( $gLogFile );
$oMapSession->setErrorManager( $_SESSION["gErrorManager"] );

// set the temp directory for the map session
$oMapSession->setTempDir( $_SESSION['gszTmpPath'] );


/* ============================================================================
* Re-instate the previous map state
* ========================================================================= */
$oMapSession->restoreState( $_SESSION["gszCurrentState"], $_SESSION['gszMapName'],dirname( $_SESSION['gszMapName'] ) );




// build an array with the HTTP GET or POST parameters
$http_form_vars = (count($_POST) > 0) ?
                  $_POST : ((count($_GET) > 0) ? $_GET : array() );

//keep track of errors.
$bError = false;

/* -------------------------------------------------------------------- */
/*      Find image types for output                                     */
/* -------------------------------------------------------------------- */

// check for common image format
if (strpos( ms_GetVersion(), "OUTPUT=PNG") > 0 &&
        (ImageTypes() & IMG_PNG))
{
    $szGDImageType = "PNG";
}
elseif (strpos( ms_GetVersion(), "OUTPUT=GIF") > 0 &&
    (ImageTypes() & IMG_GIF))
{
    $szGDImageType = "GIF";
}
elseif (strpos( ms_GetVersion(), "OUTPUT=JPEG") > 0 &&
        (ImageTypes() & IMG_JPG))
{
    $szGDImageType = "JPEG";
}
elseif (strpos( ms_GetVersion(), "OUTPUT=WBMP") > 0 &&
        (ImageTypes() & IMG_WBMP))
{
    $szGDImageType = "WBMP";
}
else //no common ones, look for at least a GD format
{
    $_SESSION["gErrorManager"]->setError( ERR_WARNING,
                "No common image formats found between MapScript and GD" );
    $szGDImageType = false;
    $bError = true;
    if (ImageTypes() & IMG_PNG)
    {
        $szGDImageType = "PNG";
    }
    elseif (ImageTypes() & IMG_GIF)
    {
        $szGDImageType = "GIF";
    }
    elseif (ImageTypes() & IMG_JPG)
    {
        $szGDImageType = "JPEG";
    }
    elseif (ImageTypes() & IMG_WBMP)
    {
        $szGDImageType = "WBMP";
    }
    else
    {
        echo "NO SUPPORTED GD IMAGE TYPES AVAILABLE";
        $_SESSION["gErrorManager"]->setError( ERR_WARNING,
                "NO SUPPORTED GD IMAGE TYPES AVAILABLE" );
        exit;
    }
}

$nSymX = isset($_GET['width']) ? $_GET['width'] : 100;
$nSymY = isset($_GET['height']) ? $_GET['height'] : 60;

/**
 * debug values
 */
/*
$gszTmpMapPath = "/tmp/";
$gszMapName = "/mapfile/52.map";
$gszMap = file($gszMapName);
*/

//file symbol file 'relative' to map file
$szSymbolFile = $oMapSession->oMap->symbolsetfilename;
if ($szSymbolFile == '')
{
    //guess
    $szSymbolFile = realpath($_SESSION['gszMapPath']."/../etc/symbols.sym");
}
else if ($szSymbolFile[0] == "/" || preg_match('/^(\w:)/', $szSymbolFile))
{
    //absolute path
}
else 
{
    //relative path
    $szSymbolFile = realpath($_SESSION['gszMapPath']."/".$szSymbolFile);
}

//okay, if bError is set then something went wrong.  Just draw a red x
if ($bError || !isset($_GET['nSymbolName']) || trim($_GET['nSymbolName']) == "")
{
	$nImgSym = imageCreate($nSymX, $nSymY);
	$nWhite = imageColorAllocate( $nImgSym, 255, 255, 255 );
	$nXColor = imageColorAllocate( $nImgSym, 255, 0, 0 );
	$nCX = intval(( $nSymX - 1 ) / 2);
	$nCY = intval(( $nSymY - 1 ) / 2);
	ImageFilledRectangle( $nImgSym, 0, 0, $nSymX, $nSymY, $nWhite );
	ImageLine( $nImgSym, $nCX-3, $nCY-3, $nCX+3, $nCY+3, $nXColor );
	ImageLine( $nImgSym, $nCX-2, $nCY-3, $nCX+4, $nCY+3, $nXColor );
	ImageLine( $nImgSym, $nCX+3, $nCY-3, $nCX-3, $nCY+3, $nXColor );
	ImageLine( $nImgSym, $nCX+4, $nCY-3, $nCX-2, $nCY+3, $nXColor );
}
else
{

    /*
     * Build a map object from scratch using the symbolset path and
     * image path/url from the session.
     * Then create a layer, add a class with symbolization.
     */
    /*
    $oMap = ms_newMapObj( "" );
    $oMap->setSymbolSet( $szSymbolFile );
    
    actually, this breaks inline symbols.  Use the real map object instead
    */
    $oMap = $oMapSession->oMap;
    $oMap->web->set( 'imagepath', $_SESSION['gszTmpImgPath'] );
    $oMap->web->set( 'imageurl', $_SESSION['gszTmpWebPath'] );
    $oMap->selectOutputFormat( $szGDImageType );
    $oMap->set('width', $nSymX);
    $oMap->set('height', $nSymY);
    $oMap->setextent(0, 0, 100, 60);
    $oMap->set( "status", MS_ON );
        
    //turn off all layers so they don't interfer with drawing ...
    for ($i=0;$i<$oMap->numlayers;$i++)
    {
        $oLayer = $oMap->getLayer($i);
        $oLayer->set( "status", MS_OFF );
    }
    
    $oLayer = ms_newLayerObj( $oMap );
    $oLayer->set('status', MS_ON);

    $oClass = ms_newClassObj( $oLayer );
    //a shape to make a phony preview
    $oShape = ms_newShapeObj(MS_SHAPE_POLYGON);
    $oPoint = ms_newPointObj();
    
    //hard coded data
    $aoPoints = array();
    $aoPolygon = array();
    $aoLine = array();
    
    if (isset($http_form_vars['szclasstype']))
    {
        $szLayerType = $http_form_vars['szclasstype'];
    }
    else
    {
        $szLayerType = 'Point';
    }
    
    switch ($szLayerType)
    {
        case '2'://'Polygons':
            $aoPolygon[0] = ms_newLineObj();
            $aoPolygon[0]->addXY(20,10);
            $aoPolygon[0]->addXY(10,20);
            $aoPolygon[0]->addXY(10,40);
            $aoPolygon[0]->addXY(20,50);
            $aoPolygon[0]->addXY(30,50);
            $aoPolygon[0]->addXY(50,40);
            $aoPolygon[0]->addXY(60,40);
            $aoPolygon[0]->addXY(70,50);
            $aoPolygon[0]->addXY(80,50);
            $aoPolygon[0]->addXY(88,40);
            $aoPolygon[0]->addXY(90,30);
            $aoPolygon[0]->addXY(80,20);
            $aoPolygon[0]->addXY(80,10);
            $aoPolygon[0]->addXY(70,10);
            $aoPolygon[0]->addXY(40,20);
            $oShape->add($aoPolygon[0]);
            $oLayer->set("type", MS_LAYER_POLYGON);
        break;
        case '1'://'LineObjs':
            $aoLine[0] = ms_newLineObj();
            $aoLine[1] = ms_newLineObj();
            $aoLine[0]->addXY(20,10);
            $aoLine[0]->addXY(10,20);
            $aoLine[0]->addXY(10,40);
            $aoLine[0]->addXY(20,50);
            $aoLine[0]->addXY(30,50);
            $aoLine[0]->addXY(50,40);
            $aoLine[0]->addXY(60,40);
            $aoLine[1]->addXY(70,50);
            $aoLine[1]->addXY(80,50);
            $aoLine[1]->addXY(88,40);
            $aoLine[1]->addXY(90,30);
            $aoLine[1]->addXY(80,20);
            $aoLine[1]->addXY(80,10);
            $aoLine[1]->addXY(70,10);
            $aoLine[1]->addXY(40,20);
            $oShape->add($aoLine[0]);
            $oShape->add($aoLine[1]);
            $oLayer->set("type", MS_LAYER_LINE);
        break;
        default: //points
            $aoPoints[0] = ms_newLineObj();
	        $aoPoints[0]->addXY(40,40);
            foreach ($aoPoints as $oPoint)
            {
                $oShape->add($oPoint);
            }
            // for layer to point
            $oLayer->set("type", MS_LAYER_POINT);
        break;
    }

    $oLayer->addFeature($oShape); 


/**
 *  parse multiple styles from url.
 */
    $aszSymbolName = array( 0 );
    $aszSymbolSize = array( 10 );
    $aszSymbolColor = array( '0_0_0' );
    $aszSymbolOutlineColor = array( '0_0_0' );
    $aszSymbolBackgroundColor = array( '255_255_255' );

    if (isset($http_form_vars['nSymbolName']))
    {
        $aszSymbolName = explode(',', $http_form_vars['nSymbolName']);
    }
    if (isset($http_form_vars['nSymbolSize']))
    {
        $aszSymbolSize = explode(',', $http_form_vars['nSymbolSize']);
    }
    if (isset($http_form_vars['nSymbolColor']))
    {
        $aszSymbolColor = explode(',', $http_form_vars['nSymbolColor']);
    }
    if (isset($http_form_vars['nSymbolOutlineColor']))
    {
        $aszSymbolOutlineColor = explode(',', $http_form_vars['nSymbolOutlineColor']);
    }
    if (isset($http_form_vars['nSymbolBackgroundColor']))
    {
        $aszSymbolBackgroundColor = explode(',', $http_form_vars['nSymbolBackgroundColor']);
    }
    
    $nPreviewStyles = count($aszSymbolName);
    for ($i=0; $i < $nPreviewStyles; $i++)
    {    
        $oStyle = ms_newStyleObj( $oClass );
    
        if ($_GET['nSymbolName'] == '')
            $_GET["nSymbolName"] = 0;
    
        if (is_object($oStyle))//:TODO: test url derived values instead
        {
            // Set style symbol
            if (is_numeric($aszSymbolName[$i]))
            {
                $oStyle->set("symbol", $aszSymbolName[$i]);
            }
            else
            {
                $oStyle->set("symbolname", $aszSymbolName[$i]);
            }
    
            // use input size or default to 15
            if ($aszSymbolSize[$i] > 0)
            {
                $oStyle->set("size", $aszSymbolSize[$i]);
            }
            else
            {
                $oStyle->set("size", 15);
            }
            // force color to transparent if not set
            if (isset($aszSymbolColor[$i]))
            {
                $anColor = explode('_', $aszSymbolColor[$i]);
                $oStyle->color->setRGB($anColor[0],
                                       $anColor[1],
                                       $anColor[2]);
            }
            else
            {
                $oStyle->color->setRGB(-1,-1,-1);
            }
            
            // force outlinecolor to transparent if not set.
            if (isset($aszSymbolOutlineColor[$i]))
            {
    
                $anColor = explode('_', $aszSymbolOutlineColor[$i]);
                $oStyle->outlinecolor->setRGB($anColor[0],
                                       $anColor[1],
                                       $anColor[2]);
            }
            else
            {
                $oStyle->outlinecolor->setRGB(-1,-1,-1);
            }
            
            // force background color to transparent if not set.
            if (isset($aszSymbolBackgroundColor[$i]))
            {
                $anColor = explode('_', $aszSymbolBackgroundColor[$i]);
                $oMap->imagecolor->setRGB($anColor[0],
                                       $anColor[1],
                                       $anColor[2]);
                                       
            }
        }
        else// couldn't create image
        {
            $_SESSION["gErrorManager"]->setError(ERR_WARNING,
                    "Can't display symbol preview due to an error in creating the styles.");
            $bError = true;
        }
    }
    //create the preview image
    $oImage = $oMap->prepareimage();
    $oLayer->draw($oImage);
    
    $szUrl = $oImage->saveWebImage();

    $szPath = $oMap->web->imagepath."/".basename($szUrl);
    
    //:TODO: does this have to be an eval?
    eval( "\$nImgSym = imageCreateFrom$szGDImageType(\$szPath);");
}

//draw the gray picker button
$nX = imageSX($nImgSym);// + 12;
$nY = imageSY($nImgSym);// + 6;
$nImgId = imageCreate($nX, $nY);
imagepalettecopy($nImgId, $nImgSym);
//allocate drawing colors
$nShadowColor = ImageColorAllocate( $nImgId, 153, 153, 153 );
$nHiliteColor = ImageColorAllocate( $nImgId, 255, 255, 255 );
$nFaceColor = ImageColorAllocate( $nImgId, 217, 217, 217 );
$nTriangleColor = ImageColorAllocate($nImgId, 0,0,0);
$nWhite = ImageColorAllocate($nImgId, 255, 255, 255 );

$nBorderColor = ImageColorAllocate($nImgId, 0,0,0);

//draw the face color
ImageFilledRectangle($nImgId, 0, 0, $nX - 1, $nY - 1, $nFaceColor);
ImageFilledRectangle($nImgId, 0, 0, $nX - 1, $nY - 1, $nWhite );

//copy the symbol image into the result image
imageCopy( $nImgId, $nImgSym, 3, 3, 1, 1,
                   imageSX($nImgSym), imageSY($nImgSym));

//draw the inside black border
ImageLine( $nImgId, 1, 1, $nX-2, 1, $nBorderColor);
ImageLine( $nImgId, 1, 1, 1, $nY-2, $nBorderColor);
ImageLine( $nImgId, $nX-2, 1, $nX-2, $nY-2, $nBorderColor);
ImageLine( $nImgId, 1, $nY-2, $nX-2, $nY-2, $nBorderColor);
//draw the outside shadow and hilite (appears inset)
ImageLine( $nImgId, 0, 0, $nX-1, 0, $nShadowColor);
ImageLine( $nImgId, 0, 0, 0, $nY-1, $nShadowColor);
ImageLine( $nImgId, $nX-1, 1, $nX-1, $nY-1, $nHiliteColor);
ImageLine( $nImgId, 1, $nY-1, $nX-1, $nY-1, $nHiliteColor);
//draw the corner button (appears beveled)
ImageLine( $nImgId, $nX-8, $nY-1, $nX-1, $nY-1, $nBorderColor);
ImageLine( $nImgId, $nX-1, $nY-8, $nX-1, $nY-1, $nBorderColor);
ImageLine( $nImgId, $nX-2, $nY-8, $nX-8, $nY-2, $nBorderColor);
ImageLine( $nImgId, $nX-2, $nY-7, $nX-7, $nY-2, $nHiliteColor);
ImageLine( $nImgId, $nX-2, $nY-6, $nX-2, $nY-2, $nShadowColor);
ImageLine( $nImgId, $nX-6, $nY-2, $nX-2, $nY-2, $nShadowColor);
ImageLine( $nImgId, $nX-3, $nY-5, $nX-5, $nY-3, $nFaceColor);
ImageLine( $nImgId, $nX-3, $nY-4, $nX-4, $nY-3, $nFaceColor);
ImageLine( $nImgId, $nX-3, $nY-3, $nX-3, $nY-3, $nFaceColor);

//return the image
header("Content-type: image/$szGDImageType");
eval("Image$szGDImageType(\$nImgId);");

// Destroy
ImageDestroy($nImgSym);
ImageDestroy($nImgId);
?>
