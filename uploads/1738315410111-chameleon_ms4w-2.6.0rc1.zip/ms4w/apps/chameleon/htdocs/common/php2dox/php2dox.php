#!/var/www/cgi-bin/php -q
<?php
/*
 * Usage :
 *    php -q php2dox.php [php_file] > result.php
 *
 * Read php file and convert it to a more readable 
 * doxygen file and pipe then into result.php.
 * 
 */

global $argv, $argc;

$nArgs = $argc;

if ($nArgs == 1)
{
    echo "Usage:\n     php -q php2dox.php [php_file] > result.php";
    exit;
}

$szFile = $argv[1];

if (!file_exists($szFile))
{
    echo "ERROR: File dont exist.";
    exit;
}

$ext = strrchr($szFile,'.');

if ($ext != ".php")
{
    echo "ERROR: Not a .PHP file.\n";
    exit;
}
        
$aszPhpFile = file($szFile);

//echo "void main(int){\n";

foreach ($aszPhpFile as $szPhpFile)
{
    $szPhpFile = str_replace("<?php", "", $szPhpFile);
    $szPhpFile = str_replace("<?php", "", $szPhpFile);
    $szPhpFile = str_replace("?>", "", $szPhpFile);
    $szPhpFile = str_replace("include_once", "include", $szPhpFile);
    $szPhpFile = str_replace("?>", "", $szPhpFile);
    
    // replace include directive
    $szPhpFile = preg_replace("/^include *[(]* *\"([a-z,A-Z,\W,_]*)\" *[)];/", "#include \"\\1\"",  $szPhpFile);
    
    // replace define directive
    $szPhpFile = preg_replace("/^define *[(] *\"([a-z,A-Z,_]*)\" *[\W] *(\w)[)];/", "#define \\1 \\2",  $szPhpFile);    
    
    $szPhpFile = str_replace("extends", ":", $szPhpFile);
    
    $szPhpFile = str_replace("}", "};", $szPhpFile); 
    
    echo $szPhpFile;
}
//echo "}";
?>


