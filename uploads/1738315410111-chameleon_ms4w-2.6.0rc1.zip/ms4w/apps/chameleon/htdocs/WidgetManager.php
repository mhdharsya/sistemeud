<?php
/**
 * Widget Manager
 *
 * @project     CWC2
 * @revision    $Id: WidgetManager.php,v 1.44 2007/09/06 14:14:17 jlacroix Exp $
 * @purpose     Utility class that create/register widgets
 * @author      DM Solutions Group (assefa@dmsolutions.ca)
 * @copyright
 * <b>Copyright (c) 2002, DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

//pre-include all the files likely to be needed by widgets
$aIncludeList = array(
  "widgets/Button.php",
  "widgets/Popup.php",
  "widgets/Label.php",
  "widgets/NavTool.php",
  "widgets/Widget.php" );

foreach ($aIncludeList as $szInclude)
{
    include_once( $szInclude );
}
/*
if (@require_once 'PEAR/Registry.php')
    $GLOBALS['gbPear']=true;
else
*/
    $GLOBALS['gbPear']=false;

/*
 * global mapping array for widgets that change their name
 *
 * widgets that get their name changed can be registered here to ensure
 * backwards compatibility for several versions
 *
 * array uses old name as a key with new name and three version numbers:
 * version 1 - the version that the name changed
 * version 2 - the version at which warnings should appear
 * version 3 - the version at which errors should appear
 *
 * at version 2, widgets will still work under the old name but a warning will
 * be logged in the error manager
 *
 * at version 3, widgets will cease to work and will appear in RED in the template.
 *
 * example:
 * $GLOBALS['gaszRenamedWidgets']['MapDHTMLWidget'] =
 *     array( "MapDHTML", "1.99", "2.2", "2.4" );
 *
 * NOTE that only the MAJOR and MINOR numbers are used in this comparison
 */

$GLOBALS['gaszRenamedWidgets'] = array();

//bug MT 632: rename MapDHTML widget
$GLOBALS['gaszRenamedWidgets']['MapDHTMLWidget'] =
    array( "MapDHTML", "1.99", "2.2", "2.4" );

//bug MT 377: rename PrintWidget
$GLOBALS['gaszRenamedWidgets']['PrintWidget'] =
    array( "PrintProduction", "1.99", "2.2", "2.4" );

/// Factory for creating widgets from tags found in a Chameleon template.
/**
 * class WidgetManager is a factory for creating widgets from tags found in
 * a Chameleon template.  The WidgetManager creates new instances of widgets
 * from widget tag
 * \code
 * $oWidgetMgr = WidgetManager( array( "c:/mywidgets" ) );
 * $oWidget = $oWidgetMgr->CreateWidgetUsingTag( '<CWC2 type="Title"/>" );
 * \endcode
 * The WidgetManager only loads widget classes on demand to optimize
 * performance.
 *
 * The WidgetManager also maintains an array of SharedResource widgets and
 * ensures that every widget created has a *reference* to this array.
 */
class WidgetManager
{
    /// the array of shared resources available to all widgets
    var $maSharedResourceWidgets = array();

    /// directories that can be used to load widgets from
    var $maszWidgetDirectories = array();

    /// packages that can be used to load widgets from (PEAR installed)
    var $maszWidgetPackages = array();

    // needed to pass the correct MLT resource dir
    var $mszCurrentWidgetDir;

    /**
     * Initialize the widget manager, optionally taking an array of
     * directories that can be used to find widgets as required
     * @param aszExtraWidgetDir - an array of directory names to search
     *        for widgets in.
     */
    function WidgetManager($aszExtraWidgetDir = array())
    {
        // Register pear widgets
        if ($GLOBALS['gbPear'] && is_writable("../"))
        {
            $oRegistry = new PEAR_Registry("../");
            $aszPackages = $oRegistry->listPackages();

            foreach($aszPackages as $szPackage)
            {
                $aPackage = $oRegistry->packageInfo($szPackage);
                foreach ($aPackage['filelist'] as $szFileName => $aFileInfo)
                {
                    if (substr($szFileName, -11) == ".widget.php" &&
                        !in_array(dirname($aFileInfo['installed_as']), $this->maszWidgetDirectories))
                    {
                        $szVersion = substr(dirname($aFileInfo['installed_as']), -3);
                        $szVersion = implode(".", explode("_", $szVersion));
                        $this->maszWidgetPackages[substr(basename($szFileName), 0, -11)][$szVersion] = dirname($aFileInfo['installed_as']);
                    }
                }
            }
        }

        //register widgets
        array_push( $this->maszWidgetDirectories,
                    realpath( dirname(__FILE__).'/widgets' ));
        $this->maszWidgetDirectories = array_merge( $aszExtraWidgetDir, $this->maszWidgetDirectories);
    }

    /**
     * ensure that a widget's class definition is available by 'include'ing
     * the widget's php file if necessary.
     * @param szWidget the widget to load
     * @param szVersion the widget version to load
     * @return boolean true if the widget is loaded, false if an error occured
     */
    function LoadWidget($szWidget, $szVersion="")
    {
        if (isset($GLOBALS['gaszRenamedWidgets'][$szWidget]))
        {
            //first case, silently rename widget
            list( $major, $minor ) = explode( ".", $GLOBALS['gaszRenamedWidgets'][$szWidget][1]);
            if ($major > CHAMELEON_MAJOR_VERSION ||
               ($major == CHAMELEON_MAJOR_VERSION && $minor >= CHAMELEON_MINOR_VERSION))
            {
                $szWidget = $GLOBALS['gaszRenamedWidgets'][$szWidget][0];
            }
            else
            {
                //second case, rename widget with a warning
                list( $major, $minor ) = explode( ".", $GLOBALS['gaszRenamedWidgets'][$szWidget][2]);
                if ($major > CHAMELEON_MAJOR_VERSION ||
                   ($major == CHAMELEON_MAJOR_VERSION && $minor >= CHAMELEON_MINOR_VERSION))
                {
                    $_SESSION['gErrorManager']->setError( ERR_WARNING, "WARNING: $szWidget has been renamed to ".
                                                        $GLOBALS['gaszRenamedWidgets'][$szWidget][0].".  Please update your template." );
                    $szWidget = $GLOBALS['gaszRenamedWidgets'][$szWidget][0];
                }
                else
                {
                    //final case, error and widget won't be found
                    list( $major, $minor ) = explode( ".", $GLOBALS['gaszRenamedWidgets'][$szWidget][3]);
                    if ($major > CHAMELEON_MAJOR_VERSION ||
                       ($major == CHAMELEON_MAJOR_VERSION && $minor >= CHAMELEON_MINOR_VERSION))
                    {
                        $_SESSION['gErrorManager']->setError( ERR_CRITICAL, "ERROR: $szWidget has been renamed to ".
                                                            $GLOBALS['gaszRenamedWidgets'][$szWidget][0].".  You must update your template." );
                    }
                }
            }
        }
        if (!class_exists($szWidget))
        {
            // If a version is specified, don't look in widget directories.
            if ($szVersion == "")
            {
                $i=-1;
                $nDirectories = count($this->maszWidgetDirectories);
                while( ++$i < $nDirectories )
                {
                    $szFile = $this->maszWidgetDirectories[$i].'/'.$szWidget.'/'.$szWidget.'.widget.php';
                    if (file_exists( $szFile ))
                    {
                        $this->mszCurrentWidgetDir = $this->maszWidgetDirectories[$i];
                        include( $szFile );
                        return $szWidget;
                    }
                }
            }

            //ini_set('include_path', ini_get('include_path').':/home/sacha/proj/chameleon/htdocs/widgets/');

            foreach ($this->maszWidgetPackages as $szName => $aszPackage)
            {
                if ($szWidget == $szName)
                {
                    if ($szVersion != "")
                    {
                        include($aszPackage[$szVersion].'/'.$szWidget.'/'.$szWidget.'.widget.php');
                        return $szWidget;
                    }
                    else
                    {
                        $szTmpVersion = "";
                        foreach($aszPackage as $szVersion => $aPackage)
                        {
                            if ($szTmpVersion < $szVersion)
                                $szTmpVersion = $szVersion;
                        }
                        include($aszPackage[$szTmpVersion].'/'.$szWidget.'/'.$szWidget.'.widget.php');
                        return $szWidget;
                    }
                }
            }
            return false;
        }
        return $szWidget;
    }

    /**
     * Create a new instance of a widget from the widget's tag.
     *
     * @param nWidgetID the unique id to give to the widget
     * @param szWidgetTag the tag to create the widget from
     *
     * @return the reference to the newly created widget or false
     */
    function &CreateWidgetUsingTag($nWidgetID, &$szWidgetTag)
    {
        $szClassName = $this->ExtractClassName($szWidgetTag);
        if ($szClass = $this->LoadWidget($szClassName))
        {
            $szEval = "\$oWidget = new $szClass();";
            eval($szEval);

            //if the class is not the classname then the widget has been mapped
            //to a new name.  We should probably use a regexp to ensure that we
            //only replace type="$szClassName" with type="$szClass" but that
            //seems like a lot of work :)
            if ($szClass != $szClassName)
            {
                $szWidgetTag = str_replace( $szClassName, $szClass, $szWidgetTag );
            }

            $oWidget->SetUniqueId($nWidgetID);
            $bResult = $oWidget->InitUsingTag($szWidgetTag);

            if (!$bResult)
            {
                $_SESSION['gErrorManager']->setError(ERR_WARNING,
                'ERROR: Initialization for '.$szClassName.' failed with an invalid attribute value.');
                return false;
            }

            $oWidget->mszWidgetName = $szClass;

            $this->moApp =& GetChameleonApplication();

            // pass a copy of the application MLT object to the widget
            $this->moMLT = &$this->moApp->moGlobalMLT;


            // load the resourcre file into memory
            if ( is_object( $this->moMLT ) )
            {
                $this->moMLT->loadResource( $oWidget->mszWidgetName,
                  $this->mszCurrentWidgetDir.'/'.$oWidget->mszWidgetName );
            }

            if ($szClass == 'SharedResource')
            {
                $this->maSharedResourceWidgets[$oWidget->maParams['NAME']] =& $oWidget;
            }
            else
            {
                $oWidget->SetSharedResourceWidgets($this->maSharedResourceWidgets);
            }
            return $oWidget;
        }
        else
        {
            $szSearchPath = implode( ",", $this->maszWidgetDirectories );
            $_SESSION['gErrorManager']->setError(ERR_WARNING,
            'ERROR: Widget Definition for class \''.$szClassName.'\' not found (tag is '.htmlentities($szWidgetTag).').');
            $_SESSION['gErrorManager']->setError(ERR_WARNING, $szSearchPath );
        }
        $oWidget = false;
        return $oWidget;
    }

    /**
     * extract the widget registry name from a tag
     * @param $szWidgetTag the tag to inspect
     * @return string the widget type
     */
    function ExtractClassName(&$szWidgetTag)
    {
        $szStart = substr(stristr($szWidgetTag, "type=\""), 6);

        return trim(substr($szStart, 0, strpos($szStart, "\"")));
    }

    /**
     * Get a list of all available widgets
     *
     * @return array - String array of widget names.
     */
    function GetAvailableWidgets()
    {
        $aResult = array();

        $i=-1;
        $nDirectories = count($this->maszWidgetDirectories);
        while( ++$i < $nDirectories )
        {
            $fh = dir($this->maszWidgetDirectories[$i].'/');
            while (false !== ($szEntry = $fh->read()))
            {
                // skip '.'and '..'
                if ( $szEntry == '.' || $szEntry == '..' )
                {
                    continue;
                }

                // widgets are now nested in their own subdirectories
                // so check if the entry is a directory
                if ( is_dir( $this->maszWidgetDirectories[$i].'/'.$szEntry ) )
                {
                    // loop through the directory looking for widgets
                    $fp = dir( $this->maszWidgetDirectories[$i].'/'.$szEntry.'/' );
                    while ( false !== ( $szSubEntry = $fp->read() ) )
                    {
                        // check for widget
                        if (substr($szSubEntry, -11) == '.widget.php')
                        {
                            array_push($aResult, array(substr($szSubEntry, 0, -11), '',
                                $this->maszWidgetDirectories[$i].'/'.$szEntry.'/'));
                        }
                    }
                }

                // check if a widget still exists at this level
                if (substr($szEntry, -11) == '.widget.php')
                {
                    array_push($aResult, array(substr($szEntry, 0, -11), '',
                                            $this->maszWidgetDirectories[$i].'/'));
                }
            }
        }

        //ini_set('include_path', ini_get('include_path').':/home/sacha/proj/chameleon/htdocs/widgets/');

        foreach ($this->maszWidgetPackages as $szName => $aszPackage)
        {
            foreach ($aszPackage as $szVersion => $szDir)
                array_push($aResult, array($szName, $szVersion, $szDir));
        }

        return $aResult;
    }
}//end of class
