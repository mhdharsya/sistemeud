<?php
header( "Location: cwc2.php?TEMPLATE=test.html&CONTEXT=gmap_context.xml" );
?>

