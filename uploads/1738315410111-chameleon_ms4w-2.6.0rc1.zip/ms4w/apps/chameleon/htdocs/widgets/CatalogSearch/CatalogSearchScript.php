<?php
include_once("CatalogSearch.php");

include_once("../session.inc.php");

$nServiceId = $_GET['serviceId'];
$szFormat = $_GET['szFormat'];
$bCachedLayer = false;
$aszSessionLayer = array();
$szSessionKey = "";

// Get the current layer with cached information (if any)
if( isset( $_SESSION['CatalogSearchEmbeded_RESULT'] ) && 
    isset($_SESSION['CatalogSearchEmbeded_RESULT']) && 
    isset($_SESSION['CatalogSearchEmbeded_RESULT']['CatalogSearchResult']) && 
    isset($_SESSION['CatalogSearchEmbeded_RESULT']['CatalogSearchResult']['layers']) &&
    isset($_SESSION['CatalogSearchEmbeded_RESULT']['CatalogSearchResult']['layers']['LAYER']) &&
    is_array($_SESSION['CatalogSearchEmbeded_RESULT']['CatalogSearchResult']['layers']['LAYER']) )
{
    $aLayers = $_SESSION['CatalogSearchEmbeded_RESULT']['CatalogSearchResult']['layers']['LAYER'];

    foreach($aLayers as $key => $aLayer)
    {
        if( isset($aLayer['serviceId']) && $aLayer['serviceId'] == $nServiceId)
        {
            $aszSessionLayer =& $_SESSION['CatalogSearchEmbeded_RESULT']['CatalogSearchResult']['layers']['LAYER'][$key];
            $szSessionKey = $key;
            if( isset($aLayer['cached']) && $aLayer['cached'] )
            {
                $bCachedLayer = true;
            }
        }
    }
}

if( !$bCachedLayer )
{
    $szGetServiceIdURL = "http://ceomap2.ccrs.nrcan.gc.ca/cgi-bin/cslt/wes/service_manager/catquery?RS=XML&ESN=f&DOCID=$nServiceId&DOIT=Get+Service";
    $fh = fopen($szGetServiceIdURL, "r");
    $szXMLDoc = "";
    while ($szString = fread($fh, 1024))
    {
        $szXMLDoc .= $szString;
    }

    if ($szXMLDoc != "")
    {
        $parser = xml_parser_create();
        xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
        xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE,   1);
        xml_parse_into_struct($parser, $szXMLDoc, $aVals, $index);
        xml_parser_free($parser);

        $oXMLDoc =  xml_get_children($aVals);
    }

    if (!isset($oXMLDoc->searchResponse->value->searchStatus->attributes['numberOfRecords']) ||
        $oXMLDoc->searchResponse->value->searchStatus->attributes['success'] == false ||
        $oXMLDoc->searchResponse->value->searchStatus->attributes['numberOfRecords'] <= 0)
    {
?>
<script language="javascript" type="text/javascript">
var aszLayerAttributes = new Array("","","","","","","","");
parent.catalogSearchCallback("", aszLayerAttributes );
</script>
<?php
        exit;
    }

    // Get result count
    $oRes =& $oXMLDoc->searchResponse->value->searchResults->value->ISO19119->value;

    // Get the connection string
    // if DCP is a array, take the first one
    if (is_array($oRes->operationMetadata->value->DCP))
        $szLayerConnectString = $oRes->operationMetadata->value->DCP[0]->value->connectPoint->value->linkage->attributes['xlink:href'];
    else
        $szLayerConnectString = $oRes->operationMetadata->value->DCP->value->connectPoint->value->linkage->attributes['xlink:href'];

    // Get layer title
    $szLayerTitle = $oRes->citation->value->title->value;

    // Get layer name
    $szLayerName = $oRes->citation->value->alternateTitle->value;

    // Get server version
    $szServerVersion = $oRes->serviceTypeVersion->value;

    // Get Abstract
    $szLayerAbstract = $oRes->abstract->value;

    // Get bounding box
    $szBBox = str_replace(",", " ", substr(substr($oRes->typeProperty->value->typeValue->value->instanceValue->value->value->value, 1), 0, -1));


    // Get styles, formats and SRSs
    // ( $szLayerSRSs, $szLayerStyles and $szLayerFormats )
    // Get parameter count
    $nbParam = count($oRes->operationMetadata->value->parameter);
    for($j=0;$j<$nbParam;$j++)
    {
        // Get parameter object
        $oParam =& $oRes->operationMetadata->value->parameter[$j];
        
        // If parameter is a STYLE
        if ($oParam->value->parameterName->value->nameValue->value == "STYLES")
        {
            $szLayerStyles = "";
            // Is there more than one style ?
            if (is_array($oParam->value->permittedValues->value->enumValues->value->valueTitle))
            {
                // Yes, then get style objects count
                $nbStyle = count($oParam->value->permittedValues->value->enumValues->value->valueTitle);
                for($k=0;$k<$nbStyle;$k++)
                {
                    // Get style title
                    $szTitle = $oParam->value->permittedValues->value->enumValues->value->valueTitle[$k]->value;
                    // Get style online resource
                    $szOnlineRes = $oParam->value->permittedValues->value->enumValues->value->valueOnLineResource[$k]->value->linkage->attributes['xlink:href'];
                    
                    // add them to layer info string.
                    $szLayerStyles .= $szTitle.">,<   ".$szOnlineRes.">;<";
                }
            }
            else
            {
                // Get style title
                $szTitle = $oParam->value->permittedValues->value->enumValues->value->valueTitle->value;
                // Get style online resource
                $szOnlineRes = $oParam->value->permittedValues->value->enumValues->value->valueOnLineResource->value->linkage->attributes['xlink:href'];
                
                // add them to layer info string.
                $szLayerStyles .= $szTitle.">,<   ".$szOnlineRes.">;<";
            }
            
            $szLayerStyles = substr($szLayerStyles, 0, -3);
        }
        else
        if ($oParam->value->parameterName->value->nameValue->value == "FORMAT")
        {
            $szLayerFormat = "";
            // Is there more than one format ?
            if (is_array($oParam->value->permittedValues->value->enumValues->value->valueTitle))
            {
                // Yes, then get format objects count
                $nbFormat = count($oParam->value->permittedValues->value->enumValues->value->valueTitle);
                for($k=0;$k<$nbFormat;$k++)
                {
                    // Get format title
                    $szTitle = $oParam->value->permittedValues->value->enumValues->value->valueTitle[$k]->value;
                    // Get format value
                    $szValue = $oParam->value->permittedValues->value->enumValues->value->value[$k]->value;
                    
                    // add them to layer info string.
                    $szLayerFormats .= $szValue.",";
                }
            }
            else
            {
                // Get format title
                $szTitle = $oParam->value->permittedValues->value->enumValues->value->valueTitle->value;
                // Get format value
                $szValue = $oParam->value->permittedValues->value->enumValues->value->value->value;
                
                // add them to layer info string.
                $szLayerFormats .= $szValue.",";
            }
            
            $szLayerFormats = substr($szLayerFormats, 0, -1);
        }
        else
        if ($oParam->value->parameterName->value->nameValue->value == "SRS")
        {
            $szLayerSRSs = "";
            // Is there more than one srs
            if (is_array($oParam->value->permittedValues->value->enumValues->value->valueTitle))
            {
                // Yes, then get srs objects count
                $nbSRS = count($oParam->value->permittedValues->value->enumValues->value->valueTitle);
                for($k=0;$k<$nbSRS;$k++)
                {
                    // Get SRS title
                    $szTitle = $oParam->value->permittedValues->value->enumValues->value->valueTitle[$k]->value;
                    
                    // add them to layer info string.
                    $szLayerSRSs .= $szTitle." ";
                }
            }
            else
            {
                // Get SRS title
                $szTitle = $oParam->value->permittedValues->value->enumValues->value->valueTitle->value;
                // add them to layer info string.
                $szLayerSRSs .= $szTitle." ";
            }

            $szLayerSRSs = substr($szLayerSRSs, 0, -1);
        }
    }

    // Then put all this in the session to cache the information.
    if( count($aszSessionLayer) > 0 )
    {
        $aszSessionLayer["cached"] = true;
        $aszSessionLayer["name"] = $szLayerName;
        $aszSessionLayer["title"] = $szLayerTitle;
        $aszSessionLayer["abstract"] = $szLayerAbstract;
        $aszSessionLayer["server_version"] = $szServerVersion;
        $aszSessionLayer["connection_string"] = $szLayerConnectString;
        $aszSessionLayer["bbox"] = $szBBox;
        $aszSessionLayer["cached_styles"] = $szLayerStyles;
        $aszSessionLayer["cached_formats"] = $szLayerFormats;
        $aszSessionLayer["cached_srs"] = $szLayerSRSs;
    }
}
else
{
    // Retreive cached information
    $szLayerName = $aszSessionLayer["name"];
    $szLayerTitle = $aszSessionLayer["title"];
    $szLayerAbstract = $aszSessionLayer["abstract"];
    $szServerVersion = $aszSessionLayer["server_version"];
    $szLayerConnectString = $aszSessionLayer["connection_string"];
    $szBBox = $aszSessionLayer["bbox"];
    $szLayerStyles = $aszSessionLayer["cached_styles"];
    $szLayerFormats = $aszSessionLayer["cached_formats"];
    $szLayerSRSs = $aszSessionLayer["cached_srs"];
}

//Build URL to get preview.
$szURL = "";

$szURL = $szLayerConnectString;

// build the WMS connection string
if (strpos($szURL, '?') === false)
{
    //need to add ?
    $szURL = $szURL . "?";
}
else if (substring($szURL, -1) != "&" )
{
    //need to add &
    $szURL .= "&";
}

$szURL .= "service=WMS&";
$szURL .= "version=" . $szServerVersion . "&";
$szURL .= "request=GetMap&";
if (isset($_GET['SRS']))
    $szURL .= "SRS=".$_GET['SRS']."&";
else
    $szURL .= "SRS=EPSG:4326&";
if (isset($_GET['BBOX']))
{
    $szURL .= "BBOX=".$_GET['BBOX']."&";
}
else 
{
    
    $aszTmpBBox = explode(" ", $szBBox); // BBox is minx, maxx, maxy, miny
    $szTmpBBox = implode(",", array($aszTmpBBox[0], $aszTmpBBox[3], 
                                    $aszTmpBBox[1], $aszTmpBBox[2]));
    $szURL .= "BBOX=". $szTmpBBox ."&";
}

$szURL .= "width=220&";
$szURL .= "height=220&";
$szURL .= "layers=" . $szLayerName . "&";
$szURL .= "format=" . $szFormat . "&"; // From the server
$szURL .= "exceptions=application/vnd.ogc.se_inimage";

?>
<script language="javascript" type="text/javascript">

// Here we should handle the load WMS layer
aszLayerAttributes = new Array();
aszLayerAttributes[0] = '<?php echo $szLayerTitle; ?>';
aszLayerAttributes[1] = '<?php echo $szLayerName; ?>';
aszLayerAttributes[2] = '<?php echo $szServerVersion; ?>';
aszLayerAttributes[3] = '<?php echo $szLayerConnectString; ?>';
aszLayerAttributes[4] = '<?php echo $szLayerAbstract; ?>';
aszLayerAttributes[5] = '<?php echo $szBBox; ?>';
aszLayerAttributes[6] = '<?php echo $szLayerStyles; ?>';
aszLayerAttributes[7] = '<?php echo $szLayerFormats; ?>';
aszLayerAttributes[8] = '<?php echo $szLayerSRSs; ?>';

parent.catalogSearchCallback("<?php echo $szURL; ?>", aszLayerAttributes);
</script>
