<?php
/**
 * @project     GeoDan
 * @revision    $Id: AddChart.php,v 1.1 2007/07/20 14:46:55 jlacroix Exp $
 * @purpose     This contains the supporting php code.
 * @author      Julien-Samuel Lacroix (jlacroix@mapgears.com)
 * @copyright
 * <b>Copyright (c) 2006, DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 **/

if(is_file('../../chameleon.php'))
    define('CHAMELEON_PATH', '../../');

if(!extension_loaded('gd'))
    dl('php_gd2.'.PHP_SHLIB_SUFFIX);


//set the language resource file
$szLanguageResource = str_replace("\\","/",dirname(__FILE__))."/ChartLayer";


// set the flag to setup the mapsession
if ( !defined("LOAD_MAPSESSION") )
    define("LOAD_MAPSESSION", 1);

// include the session handling file (currently only required for MLT)
include_once(CHAMELEON_PATH."widgets/session.inc.php");
include_once(CHAMELEON_PATH."widgets/CWC2ButtonCache.php");

// include the layer attribute handling functions
include( CHAMELEON_PATH."widgets/LayerAttributes.php" );

// include the query wrapper
include_once(CHAMELEON_PATH."common/wrapper/map_query.php");

// get the form vars
$_FORM = array_merge( $_GET, $_POST );

/* ============================================================================
 * Define the default properties for the "LIKE" operator
 * ========================================================================= */
if(isset($_FORM["wildcard"]))
    define( "LIKE_WILDCARD", urldecode( $_FORM["wildcard"] ) );
else
    define( "LIKE_WILDCARD", "" );
if(isset($_FORM["singlechar"]))
    define( "LIKE_SINGLECHAR", urldecode( $_FORM["singlechar"] ) );
else
    define( "LIKE_SINGLECHAR", "" );
if(isset($_FORM["escape"]))
    define( "LIKE_ESCAPECHAR", urldecode( $_FORM["escape"] ) );
else
    define( "LIKE_ESCAPECHAR", "" );

/* ============================================================================
 * Determine the layer specific info
 * ========================================================================= */
// init vars
$szGeometryAttribute = "";
$nCount = 0;
$nSelectedLayer = "";
$szSelectedLayerName = "";
$szSelectedLayerConnType = "";
$aszAttributes = array();
$szErrorNotice = "";
$szWFSConnection = "";
$nLayerCount = $oMapSession->oMap->numlayers;
$szWFSTypeName = '';
$szChartType = 'pie@Pie Chart|bar@Bar Chart';

/* ============================================================================
 * Get selected WFS layer
 * ========================================================================= */
// check if selected layer list has been passes through URL
$aszLayers = array();
if ( isset( $_FORM["selectedlayers"] ) &&
                              strlen( trim( $_FORM["selectedlayers"] ) ) > 0 )
{
    $szSelectedLayerName = $_FORM["selectedlayers"];
    // put layers into array
    $aszLayers = explode( ',', $_FORM["selectedlayers"] );
    $nTmpCount = count( $aszLayers );
    for( $i=0; $i<$nTmpCount; $i++ )
        $aszLayers[$i] = trim( $aszLayers[$i] );

}

// Maximum of number of shapes returned when querying for charts
$nMaxResult = 25;
if( isset( $_FORM["nMaxChart"] ) )
{
    $nMaxResult = $_FORM["nMaxChart"];
}

// check for layers from the url
if ( count( $aszLayers ) > 0 )
{
    //convert WMS_TITLE to WMS_NAME ... this should make sure WMS_NAME is
    //set first but I didn't have time to do that properly ... it is safe
    //when working with map files coming from Contexts but possibly not
    //when working with hand-crafted map files
    for( $i=0; $i<count($aszLayers); $i++ )
    {
        for ($j=0; $j<$nLayerCount; $j++)
        {
            $oLayer = $oMapSession->oMap->getLayer($j);
            if ($oLayer->connectiontype == MS_WMS)
            {
                if ($aszLayers[$i] == $oLayer->getMetadata( "WMS_TITLE" ))
                {
                    $aszLayers[$i] = $oLayer->getMetadata( "WMS_NAME" );
                }
            }
        }
    }
}
else
{
    // get list from metadata
    for ( $i=0; $i<$nLayerCount; $i++ )
    {
        // get layer
        $oLayer = $oMapSession->oMap->getLayer( $i );

        // check metadata
        if ( $oLayer->getmetadata("selected") == 1 )
        {
            // add to the list of layers
            array_push( $aszLayers, $oLayer->name );
        }
    }
}

// check for an empty first one
if ( $aszLayers[0] == '' )
    array_shift( $aszLayers );

// update the active layer count
$nCount = count( $aszLayers );

// only process the first WMS or WFS layer
for ( $i=0; $i<$nCount; $i++ )
{
    // get layer by name
    $oLayer = $oMapSession->oMap->getLayerbyName( $aszLayers[$i] );
    if ($oLayer == null)
    {
        //desperate attempt to find layer ...
        for ($j=0; $j<$oMapSession->oMap->numlayers; $j++)
        {
            $oLayer = $oMapSession->oMap->getLayer( $j );
            if ($oLayer->getMetaData( "WMS_NAME" ) == $aszLayers[$i] ||
                $oLayer->getMetaData( "WMS_TITLE" ) == $aszLayers[$i] )
            {
                break;
            }
        }
    }
    // only process WMS and WFS layers
    if ( $oLayer->connectiontype == MS_WFS ||
         $oLayer->connectiontype == MS_WMS )
    {
        // record layer index
        $nSelectedLayer = $oLayer->index;

        // store the layer name to use
        $szSelectedLayerName = $oLayer->name;

        // store the connection type
        $szSelectedLayerConnType = $oLayer->connectiontype;

        // process according to layer type
        switch( $oLayer->connectiontype )
        {
            case MS_WFS:
                // record the connection string
                $szWFSConnection = $oLayer->connection;
                $szWFSTypeName = $oLayer->getMetadata( "wfs_typename" );
                if( $szWFSTypeName == "" )
                    $szWFSTypeName = $oLayer->getMetadata( "ows_typename" );
                break;
            case MS_WMS:
                // get WFS the connection string
                $szSelectedLayerName = $oLayer->getMetadata( "WMS_NAME" );
                //echo $szSelectedLayerName."<BR>";
                $aszWFSInfo = getWFSConnection( $oLayer->connection,
                                                      $szSelectedLayerName );

                // function can return false instead of array!
                if ($aszWFSInfo != false)
                {
                  $szWFSConnection = $aszWFSInfo['wfs'];
                  //echo $szWFSConnection."<BR>";
                  // loop and build typename
                  foreach( $aszWFSInfo['typename'] as $szTypeName )
                  {
                    $szWFSTypeName .= $szTypeName.',';
                  }

                  // remove trailing ','
                  if ( substr( $szWFSTypeName, -1, 1 ) == ',' )
                  {
                    $szWFSTypeName = substr( $szWFSTypeName, 0, -1 );
                  }

                  // check for false (meaning no associated WFS)
                  if ( $szWFSConnection === false )
                  {
                      // give error
                      $szErrorNotice = $oMLT->get( 'ChartLayer', '30', 'An invalid WMS layer was '.
                          'selected.  A WMS layer must have a WFS associated with '.
                          'it in order to be filtered.' );

                      // reset
                      $szWFSConnection = '';
                      $nSelectedLayer = '';
                      $szSelectedLayerName = '';
                  }
                }
                else
                {
                  // give error
                  $szErrorNotice = $oMLT->get( 'ChartLayer', '30', 'An invalid WMS layer was '.
                      'selected.  A WMS layer must have a WFS associated with '.
                      'it in order to be filtered.' );


                  // reset
                  $szWFSConnection = '';
                  $nSelectedLayer = '';
                  $szSelectedLayerName = '';
                }
                break;
        }

        // save expressions if necessary
        if ( isset( $_FORM['txtSaveExpressions'] ) &&
                                        $_FORM['txtSaveExpressions'] == 1 )
        {
            // store these as current layer's metadata expression
            $oLayer = $oMapSession->oMap->getLayer( $nSelectedLayer );
            $oLayer->setMetadata( 'cham_x_build_expressions',
                                                  $_FORM['txtExpressions'] );
        }

        // get expressions from metadata
        $_FORM['txtExpressions'] =
                        $oLayer->getMetadata( 'cham_x_build_expressions' );

        // one layer has been processed so exit loop
        break;
    }

// for loop
}

/* ============================================================================
 * Process attribute info
 * ========================================================================= */
$szAttributeOptions = '';
if ( strlen( trim( $szWFSConnection ) ) > 0 )
{
    // check the the WFS online resource contains the necessary params
    //echo "fixing WFS url $szWFSConnection for layer $szSelectedLayerName<BR>";
    $szWFSConnection = fixWFSURL( $szWFSConnection, $szWFSTypeName );

    // get the attribute types
    $aszAttributes = getAttributeTypes( $szWFSConnection.
                            'request=describefeaturetype', $szSelectedLayerName );

    // build list of attrtibutes
    $szLayerType = '';
    foreach( $aszAttributes as $key=>$value )
    {
        // bartvde, set geometry attribute
        if (strpos($value, "gml:") !== false)
        {
            $szGeometryAttribute = $key;
        }
        // skip layer type
        if ( $key == 'LayerType' )
        {
            $szLayerType = $value;
            continue;
        }
        // do not add the geometry property to the list of attributes
        if ( (strpos(strtolower($value), 'geometrypropertytype') === false) &&
          (strpos(strtolower($value), 'point') === false) &&
          (strpos(strtolower($value), 'polygon') === false) &&
          (strpos(strtolower($value), 'line') === false) )
        {

          // assemble string
          $szTmpAttribute = $key." (".$value.")";

          // create new option list item
          $szAttributeOptions .= "<option value=\"".$key."\">".
              $szTmpAttribute."</option>\n";
        }
    }
}
else
{
    // get the attribute
    $oLayer = $oMapSession->oMap->getLayerByName($szSelectedLayerName);
    $oLayer->open();
    $aszItems = $oLayer->getItems();
    $oLayer->close();
    foreach( $aszItems as $key )
    {
        // create new option list item
        $szAttributeOptions .= "<option value=\"".$key."\">".
            $key." (string)</option>\n";
    }
}

// In some cases, a layer get other attributes from another source.
// Check in the session for the attributes for this layer
if(isset($_SESSION['CHART_WIDGET_JOIN']) && 
   isset($_SESSION['CHART_WIDGET_JOIN'][$szSelectedLayerName]) &&
   is_array($_SESSION['CHART_WIDGET_JOIN'][$szSelectedLayerName]))
{
    $aszAttributeList = array();
    foreach($_SESSION['CHART_WIDGET_JOIN'][$szSelectedLayerName] as $aszJoin)
    {
        switch($aszJoin['JOINTYPE'])
        {
          case 'PGSQL':
            $aszAttributes = getAttributesFromPGSQL($aszJoin);
            break;
        }

        if(in_array($aszJoin['JOINID'], $aszAttributes))
        {
            $aszAttributeList = array_merge($aszAttributes, $aszAttributeList);
        }
    }

    foreach($aszAttributeList as $key)
    {
        // create new option list item
        $szAttributeOptions .= "<option value=\"".$key."\">".
            $key."</option>\n";
    }
}

/* ============================================================================
 * Build style select
 * ========================================================================= */
    // get title
    $szTmpTitle = $oMLT->get( 'ChartLayer', '28', 'Select Chart Type');

    // loop and build list of drop down options
    $aszStyles = explode( '|', $szChartType);
    $nSLDCount = count( $aszStyles );
    $szStyleOptions = '';
    for ( $i=0; $i<$nSLDCount; $i++ )
    {
        // separate the name from the sld file
        // [0] = name
        // [1] = title
        $aszSplit = explode( '@', $aszStyles[$i] );
        $szStyleOptions .= '<option value="'.$aszSplit[0].'">'.$aszSplit[1].
            '</option>';

    // set
    $szStyleForm = <<<EOT
  <tr>
    <td colspan="2" class="layoutTable">
      <table class="titleArea" width="100%" border="0" cellpadding="4" cellspacing="0">
        <tr>
          <td><span class="title">{$szTmpTitle}</span></td>
        </tr>
      </table>
      <table class="contentArea" width="100%" border="0" cellpadding="4" cellspacing="0">
        <tr>
          <td><select name="selType" class="inputList">
                {$szStyleOptions}
              </select></td>
        </tr>
      </table>
    </td>
  </tr>
EOT;

/* ============================================================================
 * Build layer type HTML
 * ========================================================================= */
    if ( !isset( $szLayerType ) || strlen( $szLayerType ) <= 0 )
    {
        $szLayerTypeHTML = '<td valign="middle" rowspan="2"><p class="helpArea">'.
            $oMLT->get( 'ChartLayer', '33', 'Unable to determine layer data type.  Please specify the underlying data type for this layer.').
            '</p></td>'.
            '</tr>'.
            '<tr>'.
            '<td valign="top"><span class="label">'.
            $oMLT->get( 'ChartLayer', '31', 'Type').
            ': </span><select name="selLayerType" class="inputList">'.
            '<option value="MS_LAYER_POINT">Point</option>'.
            '<option value="MS_LAYER_LINE">Line</option>'.
            '<option value="MS_LAYER_POLYGON">Polygon</option></select></td>';
    }
    else
    {
        if ( !isset( $szLayerType ) ) $szLayerType = '';
        $szLayerTypeHTML = '<input type="hidden" name="selLayerType" value="'.
                                                                $szLayerType.'">';
    }
}

if(isset($_REQUEST['class1']) && $_REQUEST['class1'] != '')
{
    if(!addChartLayer())
    {
        // set error message
        $szErrorNotice = 'ERROR!!';
        return false;
    }

    // Save map state
    $_SESSION['gszCurrentState'] = $oMapSession->saveState();
    // and exit
    session_write_close();
    echo '<html><head><script language="javascript" type="text/javascript">window.opener.AddChartCB(2, window);window.close();</script></head></html>';

}


function addChartLayer()
{
    global $_FORM, $oMapSession, $szSelectedLayerName, $nMaxResult;

    // First, get all the values we need to build the chart layer
    $szLayerName = $szSelectedLayerName;
    $nChartTotal = -1;
    $aszClassType = array();
    $aszClassValue = array();
    $szType = '';

    if(isset($_FORM['total']) && $_FORM['total'] != '')
    {
        $nChartTotal = $_FORM['total'];
    }

    if(isset($_FORM['selType']) && $_FORM['selType'] != '')
    {
        $szType = $_FORM['selType'];
    }

    $i=1;
    while(isset($_FORM['class'.$i]) && $_FORM['class'.$i] != '')
    {
        switch($_FORM['class'.$i])
        {
          case 'classField':
            if(isset($_FORM['class'.$i.'Attribute']))
            {
                $aszClassType[] = 'field';
                $aszClassValue[] = $_FORM['class'.$i.'Attribute'];
            }
            break;
          case 'classStrict':
            if(isset($_FORM['class'.$i.'Strict']))
            {
                $aszClassType[] = 'strict';
                $aszClassValue[] = $_FORM['class'.$i.'Strict'];
            }
            break;
          case 'classEquat':
            if(isset($_FORM['class'.$i.'Equat']))
            {
                $aszClassType[] = 'equat';
                $aszClassValue[] = $_FORM['class'.$i.'Equat'];
            }
            break;
        }
        if(isset($_FORM['class'.$i.'ColorR']) && 
           isset($_FORM['class'.$i.'ColorG']) && 
           isset($_FORM['class'.$i.'ColorB']))
            $aszClassColor[] = array($_FORM['class'.$i.'ColorR'], 
                                     $_FORM['class'.$i.'ColorG'],
                                     $_FORM['class'.$i.'ColorB']);
        else if(isset($_FORM['class'.$i.'Color']))
        {
            $szHexRGB = $_FORM['class'.$i.'Color'];
            $aszClassColor[] = array(hexdec(substr($szHexRGB, 0, 2)),
                                     hexdec(substr($szHexRGB, 2, 2)),
                                     hexdec(substr($szHexRGB, 4, 2)));
        }
        else
            $aszClassColor[] = array(rand(0,255), rand(0,255), rand(0,255));
        $i++;
    }
    $nCountVal = count($aszClassValue);

    // Get the shapes in the map (with a maximum)
    $oMap = $oMapSession->oMap;

    // First query the layer to get the shapes in the current display
    $oSelectedLayer = $oMap->getLayerByName( $szSelectedLayerName );

    // Note that we may need to reproject the map extent to fit the layer proj
    $oRect = ms_newRectObj();
    $oRect->setExtent($oMap->extent->minx, $oMap->extent->miny, 
                      $oMap->extent->maxx, $oMap->extent->maxy);
    $szLayerProjection = $oSelectedLayer->getProjection();
    $szMapProjection = $oMap->getProjection();
    if($szLayerProjection && 
       $szLayerProjection != $szMapProjection)
    {
        $oMapProjObj = ms_newProjectionObj($szMapProjection);
        $oLayerProjObj = ms_newProjectionObj($szLayerProjection);

        $oRect->project($oMapProjObj, $oLayerProjObj);
    }

    // If the selected layer is a WMS layer, try to do a WFS with it
    $bLayerChanged = false;
    $aszSelectedLayer = array();
    if($oSelectedLayer->connectiontype == MS_WMS)
    {
        // Backup the values we change to reset the layer after the query.
        $bLayerChanged = true;
        $aszSelectedLayer['connection'] = $oSelectedLayer->connection;
        $aszSelectedLayer['connectiontype'] = $oSelectedLayer->connectiontype;
        $oSelectedLayer->set('connectiontype', MS_WFS); 
        $szWFSConnection = getWFSConnection($oSelectedLayer->connection, 
                                            $oSelectedLayer->name);
        if($oSelectedLayer->getMetadata('wfs_onlineresource'))
            $oSelectedLayer->set('connection', 
                           $oSelectedLayer->getMetadata('wfs_onlineresource'));
        else
            $oSelectedLayer->set('connection', $szWFSConnection['wfs']);
        if(!$oSelectedLayer->getMetadata('wfs_typename'))
            $oSelectedLayer->setMetadata('wfs_typename',
                                 $szWFSConnection['typename'][0]);
        if(!$oSelectedLayer->getMetadata('wfs_version'))
            $oSelectedLayer->setMetadata('wfs_version', '1.0.0');
    }

    // The layer must be queryable
    if(!$oSelectedLayer->template)
    {
        $bLayerChanged = true;
        $aszSelectedLayer['template'] = $oSelectedLayer->template;
        $oSelectedLayer->set('template', 'template.html');
    }


    // Note that the map extent can be in another projection we may need that 
    // later
    $oSelectedLayer->queryByRect( $oMap->extent );

    $oSelectedLayer->open();

    // Foreach shape returned, query the chart layer to extract the chartvalues
    $aoPoint = array();
    $aszChartFilenames = array();
    $nCount = 0;
    $nChartValuesTotal = 0;
    $aszColors = $aszClassColor;
    $aszChartLegendClass = array();
    $nNumResult = $oSelectedLayer->getNumResults();
    for($nRes=0; $nRes<$nNumResult; $nRes++)
    {
        if( $nCount > $nMaxResult )
            break;

        $oResult = $oSelectedLayer->getResult($nRes);
        $oShape = $oSelectedLayer->getShape($oResult->tileindex, 
                                            $oResult->shapeindex);
        $nCount++;
        $nChartValuesTotal = 0;
        $aszClassColor = $aszColors;
        // Build an array with all the chart values
        $aszChartValues = array();
        for($i=0; $i<$nCountVal; $i++)
        {
            switch($aszClassType[$i])
            {
              case 'field':
                $szField = $aszClassValue[$i];
                if(isset($oShape->values[$szField])) 
                    $aszChartValues[] = floatval($oShape->values[$szField]);
                else 
                if(($nJoinValue = getJoinFieldValue($szField,$oShape))!==false)
                    $aszChartValues[] = floatval($nJoinValue);
                $aszChartLegendClass[$i] = array($szField, $aszClassColor[$i]);
                break;
              case 'equat':
                $aszEquation = explode(' ', $aszClassValue[$i]);
                $aszEquatPart = array();
                // Validate the equation parts
                for($e=0; $e<count($aszEquation); $e++)
                {
                    if(isset($oShape->values[$aszEquation[$e]]))
                        $aszEquation[$e] = $oShape->values[$aszEquation[$e]];
                    else
                    if(($nJoinValue = getJoinFieldValue($szField,$oShape)) !==
                       false)
                        $aszEquation[$e] = floatval($nJoinValue);

                    // Characters allowed are numbers and +, /, *, -
                    if(preg_match('/^[\d\+\-\/\*]+$/', $aszEquation[$e]))
                        $aszEquatPart[] = $aszEquation[$e];
                }
                // Parse and compute it
                $nTotal = 0;
                while(count($aszEquatPart))
                {
                    $szOper = array_shift($aszEquatPart);
                    if(is_numeric($szOper))
                        $nTotal = $szOper;
                    switch($szOper)
                    {
                      case '+':
                        $nVal = floatval(array_shift($aszEquatPart));
                        $nTotal += $nVal;
                        break;
                      case '-':
                        $nVal = floatval(array_shift($aszEquatPart));
                        $nTotal -= $nVal;
                        break;
                      case '*':
                        $nVal = floatval(array_shift($aszEquatPart));
                        $nTotal *= $nVal;
                        break;
                      case '/':
                        $nVal = floatval(array_shift($aszEquatPart));
                        $nTotal /= $nVal;
                        break;
                    }
                }
                $aszChartValues[] = $nTotal;
                $aszChartLegendClass[$i] = array($aszClassValue[$i],
                                                 $aszClassColor[$i]);
                break;
              case 'strict':
                $aszChartValues[] = floatval($aszClassValue[$i]);
                $aszChartLegendClass[$i] = array(floatval($aszClassValue[$i]),
                                                 $aszClassColor[$i]);
                break;
            }
            $nChartValuesTotal += $aszChartValues[count($aszChartValues)-1];
        }

        // If we have a total, the last value should be "Other"
        if($nChartTotal)
        {
            if($nChartTotal > $nChartValuesTotal)
            {
                $aszChartValues[] = $nChartTotal - $nChartValuesTotal;
                $nChartValuesTotal = $nChartTotal;
                if(isset($_FORM['totalColorR']) && 
                   isset($_FORM['totalColorG']) && 
                   isset($_FORM['totalColorB']))
                    $aszClassColor[] = array($_FORM['totalColorR'], 
                                             $_FORM['totalColorG'],
                                             $_FORM['totalColorB']);
                else if(isset($_FORM['totalColor']))
                {
                    $szHexRGB = $_FORM['totalColor'];
                    $aszClassColor[] = array(hexdec(substr($szHexRGB, 0, 2)),
                                             hexdec(substr($szHexRGB, 2, 2)),
                                             hexdec(substr($szHexRGB, 4, 2)));
                }
                else
                    $aszClassColor[] = array(rand(0,255), rand(0,255), 
                                             rand(0,255));
                $aszChartLegendClass[$i] = array('Others',
                                                 $aszClassColor[count($aszClassColor)-1]);
            }
        }

        if($nChartValuesTotal == 0)
            $nChartValuesTotal = 1;

        // With the values here, we are supposed to be able to draw a chart 
        // symbol
        $szFilename = getSessionSavePath();
        $szFilename .= md5($nChartValuesTotal.rand().$szSelectedLayerName.
                      $oShape->classindex.$oShape->tileindex.$oShape->index);
        $szFilename .= '.png';

        // Draw the chart symbol
        if($szType == 'pie')
        {
            if(!drawPieChart($szFilename, $aszChartValues, $aszClassColor))
                continue;
        }
        else if($szType == 'bar')
        {
            if(!drawBarChart($szFilename, $aszChartValues, $aszClassColor))
                continue;
        }
        else
        {
            continue;
        }

        // Calculate the location of the symbol (considering the map edge)
        // The shape contains the extent, just use that.
        if($oShape->bounds->minx < $oRect->minx)
            $nMinX = $oRect->minx;
        else
            $nMinX = $oShape->bounds->minx;
        if($oShape->bounds->miny < $oRect->miny)
            $nMinY = $oRect->miny;
        else
            $nMinY = $oShape->bounds->miny;
        if($oShape->bounds->maxx > $oRect->maxx)
            $nMaxX = $oRect->maxx;
        else
            $nMaxX = $oShape->bounds->maxx;
        if($oShape->bounds->maxy > $oRect->maxy)
            $nMaxY = $oRect->maxy;
        else
            $nMaxY = $oShape->bounds->maxy;

        // Add the point on the map at that location
        // We create a shape in the session directory that will store the 
        // chart coordinates.
        $aoPoint[] = array(($nMinX+($nMaxX-$nMinX)/2), 
                           ($nMinY+($nMaxY-$nMinY)/2));

        // Save the filename to use in the chart layer
        $aszChartFilenames[] = $szFilename;

    }
    $oSelectedLayer->close();

    // Reset the layer to it's previous value
    if($bLayerChanged)
    {
        foreach($aszSelectedLayer as $szParameter => $szValue)
        {
            $oSelectedLayer->set($szParameter, $szValue);
        }
    }

    // Save the Chart shapefile in the session dir
    $oDH = dbase_create(getSessionSavePath().'addchart.dbf', 
                        array( array('chart', 'C', 250), 
                               array('id', 'N', 4, 0) ));
    $oShapefileObj = ms_newShapefileObj(getSessionSavePath().'addchart.shp',
                                        MS_SHP_POINT);
    for($i=0; $i<count($aoPoint); $i++)
    {
        $aPoint = $aoPoint[$i];
        $oPoint = ms_newPointObj();
        $oPoint->setXY($aPoint[0], $aPoint[1]);
        $oShapefileObj->addPoint($oPoint);
        dbase_add_record($oDH, array($aszChartFilenames[$i], $i));
    }
    $oShapefileObj->free();

    // Update the Chart layer to use that shapefile
    $oChartLayer = @$oMap->getLayerByName('__addChartLayer__');
    if(!$oChartLayer)
    {
        // Create the layer if it does not exist
        $oChartLayer = ms_newLayerObj($oMap);
        $oChartLayer->set('data', getSessionSavePath().'addchart.shp');
        $oChartLayer->set('type', MS_LAYER_POINT);
        $oChartLayer->set('name', '__addChartLayer__');
        $oChartLayer->set('classitem', 'id');
        $oChartLayer->set('status', MS_ON);
        $oChartLayer->setMetadata('wms_name','Chart - '.$oSelectedLayer->name);
        $oChartLayer->setMetadata('wms_title', 'Chart - '.$oSelectedLayer->name);
    }
    else
    {
        // if it exists, remove the existing classes
        for($i=0; $i<$oChartLayer->numclasses; $i++)
        {
            $oClass = $oChartLayer->getClass($i);
            $oClass->set('status', MS_DELETE);
        }
    }

    // Set the projection of the chart layer to be the same as the Selected
    // layer
    // This is needed because the Chart layer use the selected layer coords
    // to place the chart on the map.
    if($oSelectedLayer->getProjection())
        $oChartLayer->setProjection($oSelectedLayer->getProjection());

    // Add a class with an expression in that layer to display the chart
    for($i=0; $i<count($aoPoint); $i++)
    {
        $oClass = ms_newClassObj($oChartLayer);
        $oClass->setExpression($i);
        $oStyle = ms_newStyleObj($oClass);
        $oStyle->set('symbolname', $aszChartFilenames[$i]);
    }

    // Add a class with an invalid expression for the legend
    for($i=0; $i<count($aszChartLegendClass); $i++)
    {
        $oClass = ms_newClassObj($oChartLayer);
        $oClass->setExpression('__no_display__');
        $oClass->set('name', $aszChartLegendClass[$i][0]);
        $oStyle = ms_newStyleObj($oClass);
        $oStyle->set('symbolname', 'circle');
        $oStyle->set('size', 10);
        $oStyle->color->setRGB($aszChartLegendClass[$i][1][0],
                               $aszChartLegendClass[$i][1][1],
                               $aszChartLegendClass[$i][1][2]);
    }

    return true;
}

function drawPieChart($szFilename, $aszChartValues, $aszColors = array())
{
    if(count($aszChartValues) < 1 || 
       count($aszChartValues) != count($aszColors))
        return false;

    // GD related functions

    // Image creation
    $oImage = imageCreateTrueColor(33, 33);

    // WhiteBackground
    $oColor = imageColorAllocate($oImage, 255, 255, 255);
    imageColorTransparent($oImage, $oColor);
    imagefill($oImage, 0, 0, $oColor);

    $nStart = 0;
    $nChartValuesTotal = array_sum($aszChartValues);
    if($nChartValuesTotal == 0)
    {
        // For empty result, draw a blank chart
        $oBlack = imageColorAllocate($oImage, 0, 0, 0);
        imageArc($oImage, 16, 16, 30, 30, 0, 360, $oBlack);
        // Save the chart as a symbol in the session file
        imagePNG($oImage, $szFilename);
        return true;
    }
    for($i=0; $i<count($aszChartValues); $i++)
    {
        $aszChartValues[$i] *= 360.0/$nChartValuesTotal;

        // Allocate the color of this pie part
        $oColor = imageColorAllocate($oImage, $aszColors[$i][0],
                                     $aszColors[$i][1],
                                     $aszColors[$i][2]);

        // Draw the chart, piece by piece from the value
        //imageSetAntiAliased($oImage, $oColor);
        imageFilledArc($oImage, 16, 16, 30, 30, $nStart, 
                       ($nStart+$aszChartValues[$i]), $oColor, IMG_ARC_PIE);
        $nStart += $aszChartValues[$i];
    }

    // Save the chart as a symbol in the session file
    imagePNG($oImage, $szFilename);
//    header('Content-type: image/png');readfile($szFilename);exit;

    return true;
}

function drawBarChart($szFilename, $aszChartValues, $aszColors = array())
{
    if(count($aszChartValues) < 1 || 
       count($aszChartValues) != count($aszColors))
        return false;

    // Get the min and max values
    $nMinVal = 0;
    $nMaxVal = 0;
    foreach($aszChartValues as $szChartVal)
    {
        if($szChartVal > $nMaxVal)
            $nMaxVal = $szChartVal;
        if($szChartVal < $nMinVal)
            $nMinVal = $szChartVal;
    }
    if($nMinVal == $nMaxVal)
        $nMaxVal += 10;
    $nPixPerVal = floatval(27/($nMaxVal-$nMinVal));
    $nBarWidth = floatval(27/count($aszChartValues));
    
    // GD related functions

    // Image creation
    $oImage = imageCreateTrueColor(33, 33);

    // WhiteBackground
    $oColor = imageColorAllocate($oImage, 255, 255, 255);
    imageColorTransparent($oImage, $oColor);
    imagefill($oImage, 0, 0, $oColor);

    // Put the X and Y axis
    $oColor = imageColorAllocate($oImage, 0, 0, 0);
    imageFilledRectangle($oImage, 1,0,1,33,$oColor);
    imageFilledRectangle($oImage, 0,31,33,31,$oColor);

    $nStart = 3;
    for($i=0; $i<count($aszChartValues); $i++)
    {
        $nBarHeight = 0;

        // Allocate the color of this pie part
        $oColor = imageColorAllocate($oImage, $aszColors[$i][0],
                                     $aszColors[$i][1],
                                     $aszColors[$i][2]);

        // Draw the chart, piece by piece from the value
        //imageSetAntiAliased($oImage, $oColor);
        $nBarHeight = $aszChartValues[$i] * $nPixPerVal;
        imageFilledRectangle($oImage, $nStart,30 - $nBarHeight,$nStart+$nBarWidth-($nBarWidth/5),30,$oColor);
        $nStart += $nBarWidth;
    }

    // Save the chart as a symbol in the session file
    imagePNG($oImage, $szFilename);
    //header('Content-type: image/png');readfile($szFilename);exit;

    return true;
}


// The following 3 functions are used to link other data source to the chart 
// layer.

// This function read the field names in a PGSQL table
function getAttributesFromPGSQL($aszJoin)
{
    if(!extension_loaded('pgsql'))
        dl('pgsql.'.PHP_SHLIB_SUFFIX);

    $aszReturn = array();
    $szConnection = '';
    $szTable = '';

    if(isset($aszJoin['PGCONNECTION']) && $aszJoin['PGCONNECTION'] != '')
        $szConnection = $aszJoin['PGCONNECTION'];
    if(isset($aszJoin['PGTABLE']) && $aszJoin['PGTABLE'] != '')
        $szTable = preg_replace('/[^\w\d_\.]/', '',$aszJoin['PGTABLE']);

    if(!$szConnection || !$szTable)
        return $aszReturn;

    $oDB = pg_connect($szConnection);
    if(!$oDB)
        return $aszReturn;

    $oRes = pg_query($oDB, "SELECT column_name FROM information_schema.columns WHERE table_name = '$szTable'");

    if(!$oRes)
        return $aszReturn;

    $numResult = pg_num_rows($oRes);
    for($i=0; $i<$numResult; $i++)
    {
        $szName = pg_fetch_result($oRes, $i, 0);
        if($szName)
            $aszReturn[] = trim($szName);
    }

    return $aszReturn;
}

// This function read the field names in a PGSQL table
function getValueFromPGSQL($aszJoin, $szLayerId, $szField)
{
    if(!extension_loaded('pgsql'))
        dl('pgsql.'.PHP_SHLIB_SUFFIX);

    $aszReturn = false;
    $szConnection = '';
    $szTable = '';
    $szJoinId = '';

    // Get and sanitize the values
    if(isset($aszJoin['PGCONNECTION']) && $aszJoin['PGCONNECTION'] != '')
        $szConnection = $aszJoin['PGCONNECTION'];
    if(isset($aszJoin['PGTABLE']) && $aszJoin['PGTABLE'] != '')
        $szTable = preg_replace('/[^\w\d_\.]/', '',$aszJoin['PGTABLE']);
    $szField = preg_replace('/[^\w\d_\.]/', '',$szField);
    if(isset($aszJoin['JOINID']) && $aszJoin['JOINID'] != '')
        $szJoinId = preg_replace('/[^\w\d_\.]/', '',$aszJoin['JOINID']);

    if(!$szConnection || !$szTable || !$szField || !$szJoinId || !$szLayerId)
        return $aszReturn;

    $oDB = pg_connect($szConnection);
    if(!$oDB)
        return $aszReturn;

    $oRes = pg_query($oDB, "SELECT $szField FROM $szTable WHERE $szJoinId = '$szLayerId'");

    if(!$oRes)
        return $aszReturn;

    $numResult = pg_num_rows($oRes);
    if($numResult > 0)
    {
        $aszReturn = pg_fetch_result($oRes, 0);
    }
    else
        $aszReturn = 0;

    return $aszReturn;
}

// Get the value of a field from a JOIN datasource
function getJoinFieldValue( $szField, $oShape )
{
    if(!extension_loaded('pgsql'))
        dl('pgsql.'.PHP_SHLIB_SUFFIX);

    global $szSelectedLayerName;

    if(isset($_SESSION['CHART_WIDGET_JOIN']) && 
       isset($_SESSION['CHART_WIDGET_JOIN'][$szSelectedLayerName]) &&
       is_array($_SESSION['CHART_WIDGET_JOIN'][$szSelectedLayerName]))
    {
        $aszJoinList = $_SESSION['CHART_WIDGET_JOIN'][$szSelectedLayerName];
        $aszAttributeList = array();
        foreach($aszJoinList as $aszJoin)
        {
            $szLayerId = '';
            if(isset($aszJoin['LAYERID']) && 
               isset($oShape->values[$aszJoin['LAYERID']]))
                $szLayerId = $oShape->values[$aszJoin['LAYERID']];
            switch($aszJoin['JOINTYPE'])
            {
              case 'PGSQL':
                $aszAttributes = getAttributesFromPGSQL($aszJoin);
                if(in_array($szField, $aszAttributes))
                {
                    $nValue = getValueFromPGSQL($aszJoin,$szLayerId, $szField);
                    if($nValue !== false)
                        return $nValue;
                }
                break;
            }
        }
    }

    return false;
}


?>
