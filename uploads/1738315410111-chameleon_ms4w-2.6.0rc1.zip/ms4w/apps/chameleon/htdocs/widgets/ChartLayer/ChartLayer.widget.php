<?php
/**
 * ChartLayer Widget Class
 *
 * @project     Chameleon
 * @revision    $Id: ChartLayer.widget.php,v 1.1 2007/07/20 14:46:55 jlacroix Exp $
 * @purpose     Add a Chart Layer on the map
 * @author      Julien-Samuel Lacroix (jlacroix@mapgears.com)
 * @copyright
 * <b>Copyright (c) 2006, Mapgears Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */


include_once(CHAMELEON_PATH."/widgets/Widget.php");
include_once(CHAMELEON_PATH."/widgets/Button.php");
include_once(CHAMELEON_PATH."/widgets/Popup.php");

/**
 * ROIPGDigitize
 */
class ChartLayer extends CWCWidget
{
    var $moLabel;
    var $moButton;
    var $moPopup;

    /**
     * ChartLayer
     *
     * Constctor method for the ChartLayer
     */
    function ChartLayer()
    {
        parent::CWCWidget();

        $this->moLabel = new CWCLabel( $this );

        $this->moButton = new CWCButton( $this );

        $this->moPopup = new CWCPopup( $this );

        // set the description for this widget
        $this->szWidgetDescription = <<<EOT
The widget displays the Chrating popup that allows the user
to add a chart layer 
EOT;
        $this->mnMaturityLevel = MATURITY_BETA;

    }

    function InitDefaults()
    {
        parent::InitDefaults();
        //this widget should never belong to a toolset
        $this->maParams["TOOLSET"] = "";
        $this->moButton->InitDefaults();
        $this->moButton->SetOnClick('AddChart');

        // Enable the loading of other row for each layers
        if(isset($this->maszContents['JOIN']) && 
           is_array($this->maszContents['JOIN']))
        {
            $_SESSION['CHART_WIDGET_JOIN'] = array();
            foreach($this->maszContents['JOIN'] as $aszJoin)
            {
                if(isset($aszJoin['LAYER']) && $aszJoin['LAYER'] != '' &&
                   isset($aszJoin['LAYERID']) && $aszJoin['LAYERID'] != '' &&
                   isset($aszJoin['JOINTYPE']) && $aszJoin['JOINTYPE']!='' &&
                   isset($aszJoin['JOINID']) && $aszJoin['JOINID'] != '')
                {
                    if($aszJoin['JOINTYPE'] == 'PGSQL')
                    {
                        $_SESSION['CHART_WIDGET_JOIN'][$aszJoin['LAYER']][] =
                            $aszJoin;
                    }
                }
            }
        }
    }


    function GetJavascriptInitFunctions()
    {
        return $this->moButton->GetJavascriptInitFunctions();
    }

    /**
     * GetJavascriptFunctions
     *
     * Return the Javacriptfunctions needed by the widget.
     *
     * @return Javacriptfunctions needed by the widget.
     */
    function GetJavascriptFunctions()
    {
        if (isset($this->maSharedResourceWidgets["CWCJSAPI"]))
          $bCWCJSAPI = 1;
        else
          $bCWCJSAPI = 0;

        $aReturn = $this->moButton->GetJavascriptFunctions();//array();
        $szButtonJS = $this->moPopup->DrawPublish();

        $szSID = SID;
        
        //Launch AddChart
        $szJsFunctionName = "AddChart";
        $szFunction = <<<EOT
function {$szJsFunctionName}()
{
     if ({$this->mszHTMLForm}.SELECTED_LAYERS == null ||
         {$this->mszHTMLForm}.SELECTED_LAYERS.value == null ||
         {$this->mszHTMLForm}.SELECTED_LAYERS.value == "" )
     {
         alert( "no layer selected!" );
         return;
     }
    
     var szLayer = "&selectedlayers=" + {$this->mszHTMLForm}.SELECTED_LAYERS.value;
     var szURL = "{$_SESSION['gszCoreWebPath']}widgets/ChartLayer/AddChart.phtml?{$szSID}";
     szURL = szURL + szLayer;
//     alert( szURL );
     wh = window.open(szURL, 'AddChart', 'scrollbars=yes,resizable=yes,location=no,width=720,height=640');
     wh.focus();
}

EOT;
        $aReturn[$szJsFunctionName] = $szFunction;

        //AddChart callback
        $szJsFunctionName = "AddChartCB";
        $szFunction = <<<EOT
function {$szJsFunctionName}( actionId, wh )
{
    {$this->mszHTMLForm}.NAV_CMD.value = '';
    if ( actionId == 0) //Clicked OK
    {
      wh.close();
    }
    else
    if ( actionId == 1) // cancel
    {
      if (!wh.closed)
          wh.close();
    }
    else if (actionId == 2) //apply
    {
        if ({$bCWCJSAPI})
        {
            goCWCJSAPI.TriggerEvent(MAP_NEW_LAYER_ADDED);
            //Need to add the chart layer to JSAPI map in order to control
            //its status in the legend for instance.
            goCWCJSAPI.oMap.AddLayer("__addChartLayer__");
            goCWCJSAPI.oMap.GetLayerByName("__addChartLayer__").SetStatus("ON");
        }
        else
        {
            {$this->mszHTMLForm}.submit();
        }
    }
    return;
}
EOT;
        $aReturn[$szJsFunctionName] = $szFunction;

        return $aReturn;
    }

    function GetJavascriptVariables()
    {
        return $this->moButton->GetJavascriptVariables();
    }

    function GetJavascriptOnLoadFunctions()
    {
        return $this->moButton->GetJavascriptOnLoadFunctions();
    }

    function GetJavascriptIncludeFunctions()
    {
        return $this->moButton->GetJavascriptIncludeFunctions();
    }

    /**
     * GetHTMLHiddenVariables
     *
     * return the NAV_CMD varaiable.
     */
    function GetHTMLHiddenVariables()
    {
        $aReturn = $this->moButton->GetHTMLHiddenVariables();
        return $aReturn;
    }

    /**
     * ParseURL
     *
     * Look for the COMPASS_POINT command and if found, recenter
     * the image in the appropriate direction.
     * according to the other NAV paramaters.
     */
    function  ParseURL()
    {
        
        // return success
        return true;
    }


    /**
     * DrawPublish
     *
     * Return the HTML code using the name in the map file and the
     * parameters of the CWC tag.
     */
    function DrawPublish()
    {
        if (!$this->mbVisible)
            return "<!-- AddChart widget hidden -->";

        $szResult = $this->moButton->DrawPublish();

        return $szResult;
    }
}
?>
