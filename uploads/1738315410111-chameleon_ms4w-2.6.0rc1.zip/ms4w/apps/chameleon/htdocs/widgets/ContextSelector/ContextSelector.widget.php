<?php
/**
 * ContextSelector Class
 *
 * @project     Chameleon
 * @revision    $Id: ContextSelector.widget.php,v 1.14 2006/03/21 19:47:26 bartvde Exp $
 * @purpose     Allow the user to select a context from a pre-defined list
 * @author      DM Solutions Group (pspencer@dmsolutions.ca)
 * @copyright
 * <b>Copyright (c) 2002, DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */


include_once(dirname(__FILE__)."/../Widget.php");
include_once(dirname(__FILE__)."/../Button.php");
include_once(dirname(__FILE__)."/../Popup.php");

/**
 * ContextSelector is an embedded widget that allows the user to change the current
 * context to one from a pre-defined list.
 */
class ContextSelector extends CWCWidget
{
    var $mszClass = "";
    var $mszStyle = "";
    var $mbAllowResize = true;
    var $moLabel;

    /**
     * constructor
     */
    function ContextSelector()
    {
        $this->mnPriority = PRIORITY_HIGH;

        // invoke constructor of parent
        parent::CWCWidget();

        $this->moLabel = new CWCLabel( $this );

        // set the description for this widget
        $this->szWidgetDescription = <<<EOT
The ContextSelector widget allows the user to select from a pre-defined list of contexts.
EOT;

        $this->maAttributes["WIDGETCLASS"] = new StringAttribute( "WIDGETCLASS", false );
        $this->maAttributes["WIDGETSTYLE"] = new StringAttribute( "WIDGETSTYLE", false );
        $this->maAttributes['ALLOWRESIZE'] = new BooleanAttribute('ALLOWRESIZE', false);
        $this->mnMaturityLevel = MATURITY_BETA;

    }

    function InitDefaults()
    {
        parent::InitDefaults();
        $this->moLabel->InitDefaults();

        if (!isset($_SESSION['CONTEXTSELECTOR_OPTIONS']))
        {
            $_SESSION['CONTEXTSELECTOR_OPTIONS'] = array();
            if (isset($this->maszContents["OPTION"]))
            {
                foreach($this->maszContents["OPTION"] as $aSelection)
                {
                    $aOption = array();
                    if (isset($aSelection["LABEL"]))
                    {
                        array_push($aOption, $aSelection['LABEL']);
                        array_push($aOption, isset( $aSelection['VALUE'] ) ? $aSelection['VALUE'] : "" );
                    }
                    else if (isset($aSelection['VALUE']))
                    {
                        array_push($aOption, $aSelection['VALUE']);
                        array_push($aOption, $aSelection['VALUE']);

                    }
                    if (isset($aSelection["SELECTED"]))
                    {
                        array_push( $aOption, strcasecmp($aSelection["SELECTED"], "true") == 0 ? true : false );
                    }
                    array_push( $_SESSION['CONTEXTSELECTOR_OPTIONS'], $aOption );
                }
            }
            if (isset( $this->maszContents["CONTEXT"] ))
            {
                foreach( $this->maszContents["CONTEXT"] as $aSelection )
                {
                    if (isset($aSelection["NAME"]) && isset($aSelection["URL"]))
                    {
                        $aOption = array( $aSelection["NAME"], $aSelection["URL"], false );
                        array_push( $_SESSION['CONTEXTSELECTOR_OPTIONS'], $aOption );

                    }
                    else
                    {
                        $_SESSION['gErrorManager']->setError(ERR_WARNING,
                          $this->moMLT->get( $this->mszWidgetName, '0', 'ERROR: Invalid CONTEXT tag definition in ContextSelector Tag' ));
                    }
                }
            }
        }
        if (isset( $this->maParams['ALLOWRESIZE']))
            $this->mbAllowResize = strcasecmp($this->maParams['ALLOWRESIZE'], 'true') == 0 ? true : false;
    }

    /**
     * inspect URL parameters for map size changes
     */
    function ParseURL()
    {
        $oApp =& GetChameleonApplication();
        if ($this->isVarSet( "CONTEXTSELECTOR_LOADCONTEXT" ))
        {
            $szContext = $this->getVar( "CONTEXTSELECTOR_LOADCONTEXT" );
            if (strlen($szContext) > 0)
                $oApp->loadContext( $szContext, $this->mbAllowResize );
        }
        return true;
    }

    /**
     * GetHTMLHiddenVariables
     *
     * return the map size  variables.
     */
    function GetHTMLHiddenVariables()
    {
        $szVariable = "CONTEXTSELECTOR_LOADCONTEXT";
        $szValue = "<INPUT TYPE=HIDDEN NAME=$szVariable VALUE=\"\">\n";
        $aReturn[$szVariable] = $szValue;

        return $aReturn;
    }


    /**
     * GetJavascriptFunctions
     *
     * Build and return the array of functions needed in the
     * widget.
     */
    function GetJavascriptFunctions()
    {
        $aReturn = array();

        $szJsFunctionName = "applyContextSelection";
        $szFunction = <<<EOT
/**
 * {$szJsFunctionName}
 * load the selected context.
 */
function {$szJsFunctionName}(szContext)
{

    if (szContext == "")
        return;

    {$this->mszHTMLForm}.CONTEXTSELECTOR_LOADCONTEXT.value=szContext;
    if ({$this->mszHTMLForm}.CONTEXTSELECTOR_ALL_LAYERS != null)
        {$this->mszHTMLForm}.CONTEXTSELECTOR_ALL_LAYERS.value = "";
    if ({$this->mszHTMLForm}.LEGENDTEMPLATE_LAYERS != null)
        {$this->mszHTMLForm}.LEGENDTEMPLATE_LAYERS.value = "";

    {$this->mszHTMLForm}.submit();
     return;
}
EOT;
        $aReturn[$szJsFunctionName] = $szFunction;

        return $aReturn;
    }

    /**
     * Draw the widget
     */
    function DrawPublish()
    {
        if (!$this->mbVisible)
            return "<!-- ContextSelector widget hidden -->";

        $szResult = "<SELECT NAME=\"CONTEXTSELECTOR_LIST\" onchange=\"applyContextSelection(this.options[this.selectedIndex].value)\"\n";
        $szClass = "";
        if ( strlen($this->mszClass) > 0 )
        {
            $szClass = " CLASS=\"$this->mszClass\"";
        }

        $szStyle = "";
        if ( strlen($this->mszStyle) > 0 )
        {
            $szStyle = " STYLE=\"$this->mszStyle\"";
        }


        $szResult .= $szClass.$szStyle.">";

        if (isset( $_SESSION['CONTEXTSELECTOR_OPTIONS'] ))
        {
            foreach( $_SESSION['CONTEXTSELECTOR_OPTIONS']  as $aOption )
            {
                $szResult .= "<OPTION VALUE=\"".$aOption[1]."\"";
                if ($aOption[2])
                    $szResult .= " SELECTED";
                $szResult .= ">".$aOption[0]."</OPTION>";
            }
        }
        $szResult .= "</SELECT>\n";
        return $this->moLabel->DrawPublish( $szResult );
    }
}
?>
