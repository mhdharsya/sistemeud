<?php
/**
 * CodePostalLocalisation Widget class
 *
 * @project     CWC2
 * @revision    $Id:
 * @purpose     CodePostalLocalisation Popup Widget class
 * @author      DM Solutions Group (sfournier@dmsolutions.ca)
 * @copyright
 * <b>Copyright (c) 2002, DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
include_once(CHAMELEON_PATH."/widgets/Widget.php");
include_once(CHAMELEON_PATH."/widgets/Button.php");
include_once(CHAMELEON_PATH."/widgets/SQLQuery/SQLQuery.widget.php");
include_once( COMMON."wrapper/map_navigator.php" );

/**
 * a simple widget to link to another page
 */
class CodePostalLocalisation extends SQLQuery
{
    var $moButton;
    var $maszProjections = array();
    var $maszScales = array();
    var $mbSubmit = false;
    var $mbHiddenVar = false;
    var $mszCodePostal = '';
    var $mszScale = '';
    var $mszProj = 'epsg:32188';
    var $maszErrors = array();

    /**
     * construct a new link widget
     */
    function CodePostalLocalisation( &$oParent = false )
    {
        // invoke constructor of parent
        if(!$oParent)
        {
            $this->mszUserName = "dummy";
            $this->mszPassword = "dummy";
            $this->mszDatabase = "dummy";
            $this->mszServer   = "dummy";
        }
        $this->mszSQLQuery = "dummy";
        parent::SQLQuery();

        // set the description for this widget
        $this->szWidgetDescription = <<<EOT
The CodePostalLocalisation widget allows the template to display a button that will open an
arbitrary URL such as a help page for an application.
EOT;

        $this->moButton = new CWCButton($this);
        $this->maAttributes["INCLUDESUBMIT"] = new BooleanAttribute("INCLUDESUBMIT", false );
        $this->maAttributes["INCLUDEHIDDEN"] = new BooleanAttribute("INCLUDEHIDDEN", false );
        $this->maAttributes["CODEPOSTALPROJECTION"] = new BooleanAttribute("INCLUDEHIDDEN", false );

        if($oParent)
        {
            foreach($this->maAttributes as $szAttribute => $oType)
            {
                if(!isset($oParent->maAttributes[$szAttribute]))
                    $oParent->maAttributes[$szAttribute] = $oType;
            }
        }

        $this->mnMaturityLevel = MATURITY_BETA;
    }

    /**
     * initialize default values
     */
    function InitDefaults()
    {
        parent::InitDefaults();
        $this->moButton->InitDefaults();
        $this->moButton->SetOnClick( 'CodePostalLocalisation' );

        if (isset($this->maParams['INCLUDESUBMIT']))
        {
            $this->mbSubmit = strcasecmp($this->maParams['INCLUDESUBMIT'], 'true') == 0 ? true : false;
        }
        if (isset($this->maParams['INCLUDEHIDDEN']))
        {
            $this->mbHiddenVar = strcasecmp($this->maParams['INCLUDEHIDDEN'], 'true') == 0 ? true : false;
        }

        if (isset($this->maParams['CODEPOSTALPROJECTION']))
        {
            $this->mszProj = $this->maParams['CODEPOSTALPROJECTION'];
        }
        // List of scales by default + scales specified in template
        $this->maszScales[] = array('50000', '1:50000');
        $this->maszScales[] = array('25000', '1:25000');
        $this->maszScales[] = array('12500', '1:12500');
        $this->maszScales[] = array('5000', '1:5000');
        $this->maszScales[] = array('1000', '1:1000');

        // Add user specific projection
        if(isset($this->maszContents['SCALE']) && 
           is_array($this->maszContents['SCALE']))
        {
            foreach($this->maszContents['SCALE'] as $aszScale)
            {
                if(isset($aszScale['NAME']) && $aszScale['NAME'] != '' && 
                   isset($aszScale['CODE']) && $aszScale['CODE'] != '')
                {
                    $this->maszScales[] = array($aszScale['CODE'], 
                                                      $aszScale['NAME']);
                }
            }
        }
    }
    
    function ParseURL()
    {
        if ($this->mbSubmit && $this->mbVisible)
            $this->moButton->ParseURL();

        $this->mszCodePostal = $this->getVar('CODEPOSTALLOCALISATION_CODEPOSTAL');
        $this->mszScale = $this->getVar('CODEPOSTALLOCALISATION_SCALE');

        $this->mszCodePostal = preg_replace("/[^\w\d]/", "", 
                                            strtoupper($this->mszCodePostal));
        $this->mszScale = preg_replace("/[^\d]/", "", $this->mszScale);

        if($this->getVar('CODEPOSTALLOCALISATION') != 1)
        {
            return true;
        }

        // Extract the Postal Code from a DB. Connection info should have
        // been pass through the widget.
        $this->mszSQLQuery = 'SELECT astext(the_geom) as xy FROM codepostal where '.
            'codepostal = \''.$this->mszCodePostal.'\'';

        parent::ParseURL();
        if(!isset($this->maSharedResourceWidgets[$this->mszSharedResourceName]) || 
           !isset($this->maSharedResourceWidgets[$this->mszSharedResourceName][0]) || 
           !isset($this->maSharedResourceWidgets[$this->mszSharedResourceName][0]['xy']))
        {
            $this->maszErrors[] = 'Aucun code postal correspondant: '.
                $this->mszCodePostal;
            return true;
        }

        // Extract the X/Y center of the postal code
        $szGeomAsText = $this->maSharedResourceWidgets[$this->mszSharedResourceName][0]['xy'];
        if(!preg_match('/POINT\(([\d\.]+)\s([\d\.]+)\)/', $szGeomAsText, $aszMatches))
        {
            $this->maszErrors[] = 'Coordonnees invalide pour ce code postal: '.
                $this->mszCodePostal;
            return true;
        }
        $nLongitude = $aszMatches[1];
        $nLatitude = $aszMatches[2];

        // calculate the center pixel co-ordinates of the map if necessary
        $nX = $this->moMapObject->oMap->width / 2;
        $nY = $this->moMapObject->oMap->height / 2;
        
        $oPixelPos = ms_newpointobj();
        
        //set the click position
        $oPixelPos->setxy($nX,$nY);

        // create new rectangle object
        $oRect = ms_newrectobj();
        
        // get current map extents
        $dMapMinX = $nLongitude-1;
        $dMapMinY = $nLatitude-1;
        $dMapMaxX = $nLongitude+1;
        $dMapMaxY = $nLatitude+1;
        // set the extents of the rectangle
        $oRect->setextent($dMapMinX, $dMapMinY, $dMapMaxX, $dMapMaxY);

        // set projection if needed
        $oIn = ms_newProjectionObj("init=".strtolower($this->mszProj));
        $oOut = ms_newProjectionObj($this->moMapObject->oMap->getProjection());
        $oRect->project($oIn, $oOut);
        
        // call the zoomscale function
        $this->moMapObject->oMap->zoomscale($this->mszScale, $oPixelPos, 
                                             $this->moMapObject->oMap->width, 
                                             $this->moMapObject->oMap->height,
                                             $oRect);

        return true;
    }
    
    /**
     * return javascript functions
     */
    function GetJavascriptFunctions()
    {
        $aReturn = array();
        if ($this->mbVisible)
            $aReturn = $this->moButton->GetJavascriptFunctions();

        $szJsFunctionName = "CodePostalLocalisation";
        $szFunction = <<<EOT
function $szJsFunctionName()
{
    {$this->mszHTMLForm}.CODEPOSTALLOCALISATION = 1;
    {$this->mszHTMLForm}.submit();
}
EOT;
        $aReturn[$szJsFunctionName] = $szFunction;

        $szJsFunctionName = "CodePostalLocalisationGetArguments";
        $szFunction = <<<EOT
function $szJsFunctionName()
{
    var aszArgs = Array();
    aszArgs[0] = Array('CODEPOSTALLOCALISATION', 1);
    aszArgs[1] = Array('CODEPOSTALLOCALISATION_CODEPOSTAL', 
                       {$this->mszHTMLForm}.CODEPOSTALLOCALISATION_CODEPOSTAL.value);
    aszArgs[2] = Array('CODEPOSTALLOCALISATION_SCALE', 
                       {$this->mszHTMLForm}.CODEPOSTALLOCALISATION_SCALE.value);

    return aszArgs;
}
EOT;
        $aReturn[$szJsFunctionName] = $szFunction;

        $szJsFunctionName = "CodePostalLocalisationValid";
        $szFunction = <<<EOT
function $szJsFunctionName()
{
    var szCodePostal = {$this->mszHTMLForm}.CODEPOSTALLOCALISATION_CODEPOSTAL.value;
    if(!szCodePostal)
    {
        alert('Veuillez entrer un code postal valide');
        return false;
    }

    var postalPattern =/^[a-zA-Z][0-9][a-zA-Z](|-|\s)[0-9][a-zA-Z][0-9]$/;
    var postalRegExp = new RegExp(postalPattern);
    if (postalRegExp.test(szCodePostal) == false )
    {
        alert('Veuillez entrer un code postal valide');
        return false;
    }

    return true;
}
EOT;
        $aReturn[$szJsFunctionName] = $szFunction;

        return $aReturn;
    }

    /**
     * return javascript functions
     */
    function GetJavascriptIncludeFunctions()
    {
        $aResult = array();
        if ($this->mbVisible)
            $aResult = $this->moButton->GetJavascriptIncludeFunctions();
        return $aResult;
    }

    /**
     * return javascript variables
     */
    function GetJavascriptVariables()
    {
        $aResult = array();
        if ($this->mbVisible)
            $aResult =  $this->moButton->GetJavascriptVariables();
        return $aResult;
    }

    /**
     * return javascript onload functions
     */
    function GetJavascriptOnLoadFunctions()
    {
        $aResult = array();
        if ($this->mbVisible)
            $aResult = $this->moButton->GetJavascriptOnLoadFunctions();
        return $aResult;
    }
    
    /**
     * return javascript initialization funcitons
     */
    function GetJavascriptInitFunctions()
    {
        $aResult = array();
        if ($this->mbVisible)
            $aResult =  $this->moButton->GetJavascriptInitFunctions();

        $szJSErrors = '';
        foreach($this->maszErrors as $szError)
        {
            $szJSErrors .= 'alert("'.$szError.'");';
        }
        if($szJSErrors)
            $aResult['CodePostalErrors'] = $szJSErrors;

        return $aResult;
    }

    function GetHTMLHiddenVariables()
    {
        $aReturn = array();
        if ($this->mbVisible)
            $aReturn = $this->moButton->GetHTMLHiddenVariables();

        $szVariable = "CODEPOSTALLOCALISATION";
        $szValue = "<INPUT TYPE=HIDDEN NAME=$szVariable VALUE=\"\">";
        $aReturn[$szVariable] = $szValue;

        if($this->mbHiddenVar)
        {
            $szVariable = "CODEPOSTALLOCALISATION_CODEPOSTAL";
            $szValue = "<INPUT TYPE=HIDDEN NAME=$szVariable VALUE=\"\">";
            $aReturn[$szVariable] = $szValue;
            $szVariable = "CODEPOSTALLOCALISATION_SCALE";
            $szValue = "<INPUT TYPE=HIDDEN NAME=$szVariable VALUE=\"\">";
            $aReturn[$szVariable] = $szValue;
        }

        return $aReturn;
    }

    /**
     * draw the link widget
     */
    function DrawPublish()
    {
        if (!$this->mbVisible)
            return "<!-- CodePostalLocalisationWidget is hidden -->";

        $szReturn = '';
        if($this->mbSubmit)
            $szReturn = $this->moButton->DrawPublish();

        $szCodePostal = $this->mszCodePostal;

        $szScale = '<select name="CODEPOSTALLOCALISATION_SCALE">';
        foreach($this->maszScales as $aszScale)
        {
            $szSelect = '';
            if($aszScale[0] == $this->mszScale)
                $szSelect = 'SELECTED';
            $szScale .= "<option value='".$aszScale[0]."'>".
                $aszScale[1]."</option>\n";
        }

        $szReturn = <<<EOT
        <table><tr>
          <td><img src="icon_find_ca_place.gif" width="22" height="22"> </td>
          <td><span class="label"> Code postal </span></td></tr>
          <tr><td colspan="2"><input class="inputBox" type="text" name ="CODEPOSTALLOCALISATION_CODEPOSTAL" value="$szCodePostal" size="10"></td>
          </tr>
          </table>
          <table><tr><td><span class="label">&Eacute;chelle:</span><br>
          $szScale
          </td></tr></table>
EOT;

        return $szReturn;
    }
}
?>
