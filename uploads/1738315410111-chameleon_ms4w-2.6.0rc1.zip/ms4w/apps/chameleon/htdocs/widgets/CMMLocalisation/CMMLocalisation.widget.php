<?php
/**
* CMMLocalisation Widget class
*
* @project     CWC2
* @revision    $Id: CMMLocalisation.widget.php,v 1.15 2006/12/13 20:05:50 nsavard Exp $
* @purpose     CMMLocalisation Popup Widget class
* @author      DM Solutions Group (sfournier@dmsolutions.ca)
* @copyright
* <b>Copyright (c) 2002, DM Solutions Group Inc.</b>
* Permission is hereby granted, free of charge, to any person obtaining a
* copy of this software and associated documentation files (the "Software"),
* to deal in the Software without restriction, including without limitation
* the rights to use, copy, modify, merge, publish, distribute, sublicense,
* and/or sell copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
* THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
* DEALINGS IN THE SOFTWARE.
*/
include_once(CHAMELEON_PATH."/widgets/Widget.php");
include_once(CHAMELEON_PATH."/widgets/Button.php");
include_once(CHAMELEON_PATH."/widgets/Popup.php");
include_once(dirname(__FILE__)."/../XYLocalisation/XYLocalisation.widget.php");
include_once(dirname(__FILE__)."/../CodePostalLocalisation/CodePostalLocalisation.widget.php");
include_once(dirname(__FILE__)."/../SQRCLocalisation/SQRCLocalisation.widget.php");

/**
* a simple widget to link to another page
*/
class CMMLocalisation extends CWCWidget
{
    var $moButton;
    var $moPopup;
    var $moXYLocalisation;
    var $moCodePostalLocalisation;
    var $moSQRCLocalisation;
    
    /**
    * construct a new CMMLocalisation widget
    */
    function CMMLocalisation()
    {
        // invoke constructor of parent
        parent::CWCWidget();
        
        $this->moButton = new CWCButton( $this );
        $this->moPopup = new CWCPopup( $this );
        $this->moXYLocalisation = new XYLocalisation( $this );
        $this->moCodePostalLocalisation = new CodePostalLocalisation( $this );
        $this->moSQRCLocalisation = new SQRCLocalisation( $this );

        // set the description for this widget
        $this->szWidgetDescription = <<<EOT
The CMMLocalisation widget allows .....
EOT;
        $this->mnMaturityLevel = MATURITY_BETA;
    }
    
    function InitDefaults()
    {
        $oApp = GetChameleonApplication();
        
        parent::InitDefaults();

        $this->moButton->InitDefaults();
        $this->moXYLocalisation->maParams =& $this->maParams;
        $this->moXYLocalisation->InitDefaults();
        $this->moCodePostalLocalisation->maParams =& $this->maParams;
        $this->moCodePostalLocalisation->InitDefaults();
        $this->moSQRCLocalisation->maParams =& $this->maParams;
        $this->moSQRCLocalisation->InitDefaults();
        $this->moXYLocalisation->mbHiddenVar = true;
        $this->moCodePostalLocalisation->mbHiddenVar = true;
        $this->moSQRCLocalisation->mbHiddenVar = true;

        // this widget should never belong to a toolset
        $this->maParams["TOOLSET"] = "";
        $this->moButton->SetOnClick( 'clickCMMLocalisation' );
        $this->moPopup->mszLink = $_SESSION['gszCoreWebPath']."/widgets/CMMLocalisation/CMMLocalisation.php?";

    }
    
    function GetJavascriptFunctions()
    {
        $aReturn = array_merge($this->moButton->GetJavascriptFunctions(), 
                $this->moXYLocalisation->GetJavascriptFunctions(),
                $this->moCodePostalLocalisation->GetJavascriptFunctions(),
                $this->moSQRCLocalisation->GetJavascriptFunctions());
        
        $szJsFunctionName = "CMMLocalisationCB";
        $szFunction = <<<EOT
function {$szJsFunctionName}( actionId, wh )
{
    if ( actionId == 0) //Clicked Apply
    {
        if(arguments.length > 2)
        {
            var aszArgs = arguments[2];

            for(var j=0;j<{$this->mszHTMLForm}.elements.length; j++)
            {
                for(var i=0; i<aszArgs.length; i++)
                {
                    if({$this->mszHTMLForm}.elements[j].name == aszArgs[i][0])
                    {
                        {$this->mszHTMLForm}.elements[j].value=aszArgs[i][1];
                    }
                }
            }
        }
        {$this->mszHTMLForm}.NAV_CMD.value = "";
        {$this->mszHTMLForm}.submit();
    }
    else if ( actionId == 1) // cancel
    {
        if (!wh.closed)
            wh.close();
    }
    else if ( actionId == 2) // submit only
    {
        {$this->mszHTMLForm}.NAV_CMD.value = "";
        {$this->mszHTMLForm}.submit();
    }
    return;
}
EOT;
         
        $aReturn[$szJsFunctionName] = $szFunction;
        
        $szPopup = $this->moPopup->DrawPublish();
        $szJsFunctionName = "clickCMMLocalisation";
        $szFunction = <<<EOT
function {$szJsFunctionName}()
{
    {$szPopup}
}
EOT;
       $aReturn[$szJsFunctionName] = $szFunction;

       return $aReturn;
    }

    /**
    * return hidden variables
    */
    function GetHTMLHiddenVariables()
    {
        $aReturn =  array_merge($this->moButton->GetHTMLHiddenVariables(), 
                $this->moXYLocalisation->GetHTMLHiddenVariables(),
                $this->moCodePostalLocalisation->GetHTMLHiddenVariables(),
                $this->moSQRCLocalisation->GetHTMLHiddenVariables());
        
        return $aReturn;
    }
    
    function GetJavascriptInitFunctions()
    {
        return array_merge($this->moButton->GetJavascriptInitFunctions(), 
                $this->moXYLocalisation->GetJavascriptInitFunctions(),
                $this->moCodePostalLocalisation->GetJavascriptInitFunctions(),
                $this->moSQRCLocalisation->GetJavascriptInitFunctions());
    }

    function GetJavascriptVariables()
    {
        return array_merge($this->moButton->GetJavascriptVariables(), 
                $this->moXYLocalisation->GetJavascriptVariables(),
                $this->moCodePostalLocalisation->GetJavascriptVariables(),
                $this->moSQRCLocalisation->GetJavascriptVariables());
    }

    function GetJavascriptOnLoadFunctions()
    {
        return array_merge($this->moButton->GetJavascriptOnLoadFunctions(), 
                $this->moXYLocalisation->GetJavascriptOnLoadFunctions(),
                $this->moCodePostalLocalisation->GetJavascriptOnLoadFunctions(),
                $this->moSQRCLocalisation->GetJavascriptOnLoadFunctions());
    }

    function GetJavascriptIncludeFunctions()
    {
        return array_merge($this->moButton->GetJavascriptIncludeFunctions(), 
                $this->moXYLocalisation->GetJavascriptIncludeFunctions(),
                $this->moCodePostalLocalisation->GetJavascriptIncludeFunctions(),
                $this->moSQRCLocalisation->GetJavascriptIncludeFunctions());
    }

    function ParseURL()
    {
        $this->moXYLocalisation->SetMap($this->moMapObject);
        $this->moXYLocalisation->SetURL($this->moFormVars, $this->moURLArray);
        $this->moCodePostalLocalisation->SetMap($this->moMapObject);
        $this->moCodePostalLocalisation->SetURL($this->moFormVars, 
                                                $this->moURLArray);
        $this->moSQRCLocalisation->SetMap($this->moMapObject);
        $this->moSQRCLocalisation->SetURL($this->moFormVars, 
                                          $this->moURLArray);

        return true;
    }

    /**
     * DrawPublish
     *
     * Return the HTML code using the name in the map file and the
     * parameters of the CWC tag.
     */
    function DrawPublish()
    {
        if (!$this->mbVisible)
            return "<!-- CMMLocalisation popup widget hidden -->";
        
        $szResult = $this->moButton->DrawPublish();

        return $szResult;
    }
}
?>
