<?php
/**
 * this function tests a file name and downloads it as a local file in the
 * session if it is a remote file, then returns the local filename.  If the
 * file is already local, then it will simply return the same name.
 * @param szFilename string the filename to get
 * @param szExtension string an optional extension to place on the local file if the
 * file is downloaded.  If the file is not downloaded, the filename is not
 * changed.
 * @return string a local filename or FALSE if fetching the remote file failed.
 */
function getRemoteFile( $szFilename, $szExtension = "" )
{
    if (strlen($szFilename) < 7)
    {
        $szLocalFile = $szFilename;
    }
    else if (strcasecmp( "http://", substr($szFilename, 0, 7 )) != 0)
    {
        $szLocalFile = $szFilename;
    }
    else
    {
        //at this point we need to fetch the file
        $aszFile = @file( $szFilename );
        if ($aszFile === false)
        {
            $_SESSION["gErrorManager"]->seError(ERR_ERROR, "Error retrieving remote file ($szFilename), please ensure the URL is correct" );
            $szLocalFile = false;
        }
        else
        {
            $szLocalFile = tempnam($_SESSION['gszTmpPath'], "remote").".".$szExtension;
            $fh = @fopen($szLocalFile, "w");
            if ($fh === false)
            {
                $szLocalFile = false;
                $_SESSION["gErrorManager"]->setError(ERR_ERROR, "Error creating local copy ($szLocalFile) of remote file ($szFilename), please ensure permissions are correctly set." );
            }
            else
            {
                $nbLine = count($aszFile);

                for($i=0; $i<$nbLine; $i++)
                {
                    fwrite($fh, $aszFile[$i]);
                }
                fclose($fh);
            }
        }
    }
    return $szLocalFile;
}

/**
 * this function loads a context. The name passed to this function
 * can be either a filename on the local filesystem OR a URL to a remote
 * context.  If it is a remote context, it will be downloaded first and then
 * loaded.
 *
 * If the file is a context collection, then each context in the
 * collection will be loaded in order.
 *
 * @param szContextName string the name (file or URL) of the context or
 * collection to load.
 */
function loadContext( $szContextName, $bAllowResize = true )
{
    //echo "loading context $szContextName<BR>";
    $szLocalContext = $this->getRemoteFile( $szContextName, ".cml" );

    $oMap = ms_newMapObj( "" );
    $bResult = $oMap->loadMapContext( $szLocalContext );
    if ($oMap->numlayers == 0)
    {
        $szText = $oMLT->get( "4", "ERROR: Invalid Context file" );
        $this->moErrorManager->setError(ERR_WARNING, $szText);

    }
    else
    {
        //remove existing layers
        for ($i = 0; $i < $this->moMapSession->oMap->numlayers; $i++)
        {
            $oLayer = $this->moMapSession->oMap->getLayer( $i );
            $oLayer->set( "status", MS_DELETE );
        }

        //import the newly defined layers
        $nLayers = $oMap->numlayers;
        //echo "adding ".$nLayers." layers<BR>";
        for ($i=0; $i<$nLayers; $i++)
        {
            ms_newLayerObj($this->moMapSession->oMap, $oMap->getlayer($i));
            $oLayer = $this->moMapSession->oMap->getLayer( $i );
        }

        $this->moMapSession->oMap->set( "name", $oMap->name );
        $this->moMapSession->oMap->setmetadata( "wms_title", $oMap->getmetadata( "wms_title" ) );
        if ($bAllowResize)
        {
            $this->moMapSession->oMap->set( "width", $oMap->width );
            $this->moMapSession->oMap->set( "height", $oMap->height );
        }
        $this->moMapSession->oMap->setProjection( $oMap->getprojection(), MS_TRUE );
        $this->moMapSession->oMap->extent->setExtent( $oMap->extent->minx, $oMap->extent->miny, $oMap->extent->maxx, $oMap->extent->maxy );
        $this->moMapSession->oMap->setMetadata( "original_extents", "");
        $this->moMapSession->oMap->setMetadata( "original_projection", "" );
        $this->moMapSession->oMap->web->set( "minscale", $oMap->web->minscale );
        $this->moMapSession->oMap->web->set( "maxscale", $oMap->web->maxscale );

        // Get mapserver error stack and display them as HTML comments.
        $oError = ms_GetErrorObj();
        while($oError && $oError->code > 0)
        {
            if (isset($this->moErrorManager))
            {
                $szMsg = getMapServerErrorMessage( $oError );
                $this->moErrorManager->setError(ERR_WARNING, $szMsg);
            }
            echo "<!-- ".$szMsg." -->";

            $oError = $oError->next();
        }
        $this->mszCurrentState = $this->moMapSession->saveState();
        $_SESSION["gszCurrentState"] = $this->mszCurrentState;
        $this->moMapSession->restoreState($this->mszCurrentState,
        $this->mszMapFile,
        dirname($this->mszMapFile));

    }
}
?>