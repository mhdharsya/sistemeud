<?php
header( "Location: cwc2.php?TEMPLATE=demo.html&CONTEXT=gmap_context.xml" );
?>

