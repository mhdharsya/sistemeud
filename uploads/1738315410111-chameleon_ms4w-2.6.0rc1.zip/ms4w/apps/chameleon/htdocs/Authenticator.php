<?php
/**
 *
 * @project     Chameleon
 * @revision    $Id: Authenticator.php,v 1.3 2005/05/27 15:02:47 jlacroix Exp $ 
 * @purpose     Chameleon user authentication and profile support
 * @author      DM Solutions Group (pspencer@dmsolutions.ca)
 * @copyright
 * <b>Copyright (c) 2002, DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
 
/* 
 * User authentication services for Chameleon
 */

class Authenticator
{
    var $moDB = null;
    var $mszUserTable = '';
    var $mszUserIDField = '';
    var $mszUsernameField = '';
    var $mszPasswordField = '';
    var $mszLoginTemplate = '';
    
    function Authenticator( $oDB, $szLoginTemplate, $szUserTable='users', $szUserIDField='userid', $szUsernameField='username', $szPasswordField='password' )
    {
        $this->moDB = $oDB;
        $this->moDB->initialize();
        $this->mszLoginTemplate = $szLoginTemplate;
        $this->mszUserTable = $szUserTable;
        $this->mszUserIDField = $szUserIDField;
        $this->mszUsernameField = $szUsernameField;
        $this->mszPasswordField = $szPasswordField;
    }
    
    function authenticate( $user, $password )
    {
        $_SESSION['CWCAuthentication'] = false;
        
        $szSQL = "SELECT * FROM ".$this->mszUserTable." WHERE ".$this->mszUsernameField."='".$user."' AND ".$this->mszPasswordField."='".md5($password)."';";
        $oRS = $this->moDB->execute( $szSQL );
        if (is_object($oRS) && $oRS->numRows() == 1)
        {
            $result = $oRS->getNext();
            $_SESSION['CWCAuthentication'] = $result;
        }
        return $_SESSION['CWCAuthentication'];
    }
    
    function isAuthenticated()
    {
        if (isset($_SESSION['CWCAuthentication']) && $_SESSION['CWCAuthentication'] !== false)
            return true;
        else
            return false;
    }
    
    function dethenticate()
    {
        unset($_SESSION['CWCAuthentication']);
        return true;
    }
    
}
?>
