<?php
/**
  _____________________________________________________________________________
 | 
 | Help Viewer
 |
 | @project     Chameleon
 | @revision    $Id: globprefs.inc.php,v 1.1 2005/01/11 17:03:32 wbronsema Exp $
 | @purpose     XML help viewer
 | @author      DM Solutions Group (wbronsema@dmsolutions.ca)
 | @copyright
 | <b>Copyright (c) 2004 DM Solutions Group Inc.</b>
 | Permission is hereby granted, free of charge, to any person obtaining a
 | copy of this software and associated documentation files (the "Software"),
 | to deal in the Software without restriction, including without limitation
 | the rights to use, copy, modify, merge, publish, distribute, sublicense,
 | and/or sell copies of the Software, and to permit persons to whom the
 | Software is furnished to do so, subject to the following conditions:
 |
 | The above copyright notice and this permission notice shall be included
 | in all copies or substantial portions of the Software.
 |
 | THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 | IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 | FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 | THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 | LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 | FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 | DEALINGS IN THE SOFTWARE.
 |_____________________________________________________________________________

 **/
 
/* ============================================================================
 * Configure as necessary
 * ========================================================================= */
// set the config file name
$szConfigFileName = 'help.xml';
 
// only process the xml file if found
if ( file_exists( $szConfigFileName ) )
{ 
    // define the file name for the configuration files
    define( 'CONFIG_FILE', $szConfigFileName );
      
    // define the file system path to the common directory (MUST have trailing "/")
    define( 'COMMON', '../common/' );;
    
    // include the appcontext code from the common directory
    include( COMMON.'appcontext/appcontext.php');
    
    // create new context object
    $oAppContext = new AppContext( CONFIG_FILE );
    
    // define the values 
    define( 'HTML_URL', $oAppContext->getContextValue( 'html_docs_url' ).'widgets/' );
    define( 'HTML_PATH', $oAppContext->getContextValue( 'html_docs_path' ).'widgets/' );
    define( 'TOC_FILE', $oAppContext->getContextValue( 'toc_url' ) );
 
}
else 
{
    // set defaults
    define( 'HTML_URL', './html/widgets/' );
    define( 'HTML_PATH', './html/widgets/' );
    define( 'TOC_FILE', './toc_html.html' );    
}
 
 ?>