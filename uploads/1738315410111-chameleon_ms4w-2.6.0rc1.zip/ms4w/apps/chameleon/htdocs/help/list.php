<?php
/**
  _____________________________________________________________________________
 | 
 | Help Viewer
 |
 | @project     Chameleon
 | @revision    $Id: list.php,v 1.8 2005/01/11 17:03:32 wbronsema Exp $
 | @purpose     XML help viewer
 | @author      DM Solutions Group (wbronsema@dmsolutions.ca)
 | @copyright
 | <b>Copyright (c) 2004 DM Solutions Group Inc.</b>
 | Permission is hereby granted, free of charge, to any person obtaining a
 | copy of this software and associated documentation files (the "Software"),
 | to deal in the Software without restriction, including without limitation
 | the rights to use, copy, modify, merge, publish, distribute, sublicense,
 | and/or sell copies of the Software, and to permit persons to whom the
 | Software is furnished to do so, subject to the following conditions:
 |
 | The above copyright notice and this permission notice shall be included
 | in all copies or substantial portions of the Software.
 |
 | THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 | IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 | FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 | THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 | LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 | FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 | DEALINGS IN THE SOFTWARE.
 |_____________________________________________________________________________

 **/
 
// include global configuration
include ( 'globprefs.inc.php' );
  
/* ============================================================================
 * Get FORM vars
 * ========================================================================= */
$_FORM = array_merge( $_POST, $_GET );

/* ============================================================================
 * Check for values passed on the URL
 * ========================================================================= */
// check for language extension
$szLanguageExtension = ( isset( $_FORM['language_ext'] ) ) ? 
                                      $_FORM['language_ext'] : 'en-ca.doc.xml';

// check for the comma delimited list of widgets/attribute groups.
$aszDocList = ( isset( $_FORM['doc_list'] ) ) ? 
                                 explode( ',',$_FORM['doc_list'] ) : array();
                                      
// determine search path based on extension
if ( strtolower( substr( $szLanguageExtension, -4 ) ) == 'html' )
{
    $szSearchPath = HTML_PATH;
}
else 
{
    $szSearchPath = '../';
}

// set the search url
$szSearchURL = HTML_URL;

// check if extended search is requested then 
if (  isset( $_FORM['extended_searchpath'] ) )
{
    $szSearchPath .=  rawurldecode( $_FORM['extended_searchpath'] );
    $szSearchURL .= rawurldecode( $_FORM['extended_searchpath'] );
}
                                    
/* ============================================================================
 * Build list of docs
 * ========================================================================= */
$aszFinalDocList = collectDocs( $szSearchPath, $szLanguageExtension, 
                                                                $aszDocList );
/* ============================================================================
 * Format list of docs
 * ========================================================================= */
$szBody = '';
$nCount = 1;
$szDefaultXml = '';
$szDefaultName = '';
foreach ( $aszFinalDocList as $key=>$value )
{
    // fix URL to HTML docs
    if ( strtolower( substr( $value, -4 ) ) == 'html' )
    {
        $value = $szSearchURL.basename( $value );
    }
    
    // default the first xml doc
    if ( strlen( $szDefaultXml ) <= 0 )
    {
        $szDefaultXml = $value;
        $szDefaultName = $key;
    }
    
    $szBody .= '<tr>'."\n".
               '<td><div name="list_'.$nCount.'" id="list_'.$nCount.
               '" class="tableCell"'.
               ' onmouseover="javascript:hoverEffect(this)" onmouseup="'.
               'javascript:loadHelp(this,\''.$key.'\',\''.$value.
               '\')">'.
               $key.'</div></td>'."\n".
               '</tr>'."\n";
               
    $nCount++;
}



/**
  _____________________________________________________________________________
 |
 | collectDocs()
 |
 | Postcondition:  This function sweeps the given directory and looks for all
 |                 files with the given extension.
 |
 | @param $szDir string - Directory to search.
 | @param $szExt string - extension of files to return.
 | @param $aszInclude array - optional list of docs to return.
 | @return Array - Associative array of docs.
 | @desc Returns list of docs matching the given criteria.
 |_____________________________________________________________________________
 
 **/
function collectDocs( $szDir, $szExt, $aszInclude = array() )
{
    // init vars
    $aszReturn = array();
    
    // make sure the list of includes are lowercase
    $nCount = count( $aszInclude );
    for( $i=0; $i<$nCount; $i++ )
    {
        $aszInclude[$i] = strtolower( $aszInclude[$i] );
    }
    
    // loop recursively through directory
    if( is_dir( $szDir ) )
    {
        // fix the path if necessary
        $szDirectory = str_replace( "\\", '/', realpath( $szDir ) ).'/';
        
        // open directory and build array of file/dirs
        if ( $handle = opendir( $szDirectory ) ) 
        { 
            while ( false !== ( $file = readdir( $handle ) ) ) 
            { 
                // check if directory
                if ( $file != '.' && $file != '..' && is_dir( $szDirectory.$file ) )
                {
                    // call function recursively
                    $aszTmpReturn = collectDocs( $szDirectory.$file, $szExt, 
                                                                $aszInclude );
                    // merge the result
                    $aszReturn = array_merge( $aszReturn, $aszTmpReturn );
                }
                else 
                {
                    // get file info
                    $nExtLen = strlen( $szExt );
                    $szRealFileName = substr( $file, 0, 0-$nExtLen-1 );
                    $szFileName = strtolower( $szRealFileName );
                    $szFileExt = strtolower( substr( $file, 0-$nExtLen ) );
                    
                    // only add files with the matching extension
                    if ( $szFileExt == strtolower( $szExt ) )
                    { 
                        // only add if in list of includes or all files are allowed
                        if ( in_array( $szFileName, $aszInclude ) || 
                                                        count( $aszInclude ) == 0 )
                        {                        
                            // add to array
                            $aszReturn[$szRealFileName] = $szDirectory.$file;
                        }   
                    } 
                }
            }
            closedir( $handle ); 
        }
    }

    // return array
    ksort( $aszReturn );
    return $aszReturn;
    
// end collectDoc() function
}

?>