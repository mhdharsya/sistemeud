// define globals
var oSelected;
var oHoverSelected;

function getLayer(name)
{
    if (document.getElementById)
    {
  	    return document.getElementById(name);
    }
    else if (document.all)
    {
	    return document.all[name];
    }
    else if (document.layers)
    {
   	    return document.layers[name];
    }
}

function selectItem( oItem )
{
    // deselect previous
    oSelected.className = 'tableCell';

    // select the item
    oItem.className = 'tableCellSelected';

    // remember selected
    oSelected = oItem;
}

function hoverEffect( oItem )
{   
    // deselect previous
    if ( oHoverSelected != oSelected )
    {
        oHoverSelected.className = 'tableCell';
    }
    
    // select the item if not selected
    if ( oItem != oSelected )
    {
        oItem.className = 'tableCellHover';
    }
    
    // remember selected
    oHoverSelected = oItem;
    
}

