
  CHAMELEON LIBRARY
  =================

The chameleon/ext/ directory is the home of a PHP extension for 
Chameleon. This extension allows to include some Chameleon 
functionalities directly in the PHP programming language for 
the purpose of speed and security.

Note that for now, the chameleon PHP module contains only 
optional functions. This is why there's not much documentation 
on it right now.

 COMPILATION ON LINUX
 --------------------

Assumptions :
  * general knowledge on building on a Linux machine.
  * general knowledge on Makefile.

To compile the Chameleon extension, go in the ext/ directory 
(Here!). From there simply do:

$ cd port/ ; make ; cd ../
$ cd src/ ; make ; cd ../
$ cd wmsparse/ ; make ; cd ../
$ cd php/ ; ./configure ; make ; cd ../

Note that you need php, libxml2 

If any error happens, you may have to change the xml2-config 
path in the src/ directory Makefile.

The configure options available in the php/ directory are:
--with-chameleon: Change the path to your Chameleon installation. 
Default is ../../
--with-chameleon-libxml: Change the path to xml2-config. Default 
is /usr/local/bin/ or /usr/bin/

Other path may need to be changed. To do so, you may have to edit 
the Makefiles in the src/, port/ or the wmsparse/ directories.


 COMPILATION ON WINDOWS
 ----------------------

Assumptions : 
  * general knowledge on building using MSVC++.
  * general knwoledge on how to use a php extension.

There are four directories in this project (port, src, wmsparse, php), 
containing each a MS VC++ windows makefile (makefile.vc). 

Here are the steps to build on Windows :

  - Download and install the following modules from 
    http://xmlsoft.org/sources/win32/. These are prebuilt binaries and 
    all you need to do is unzip the windows zip files.
     * limxml2 (eg : libxml2-2.6.13.win32.zip)
     * iconv (eg : iconv-1.9.1.win32.zip)
     * zlib (eg : zlib-1.2.1.win32.zip)

  - copy the dlls contained in the zip files to the Windows directory
    (or any directory that is defined in the PATH). The dlls to be
    copied are libxml2.dll, iconv.dll zlib1.dll.

  - edit all the makefiles in the 3 directories to reflect your 
    installtion of limxml2 and iconv (eg look for LIB_XML2_DIR and
    change the path to reflect your installtion)

  - edit the makefile.vc in the php diretcory to refect your php
    installation.

  - type nmake -f makefile.vc in the main directory (...chameleon/ext)

  If you want to build the directorries individually :

  - cd tp port directory and type nmake -f makefile.vc. This
    should create a cpl.lib

  - cd to the src directory and type nmake -f makefile.vc. This
    should create a libchameleon.lib

  - cd to the wmsparse directory and type nmake -f makefile.vc. This
    should create a wmsparse.exe.

  - cd to the php directory and type nmake -f makefile.vc. This should
    create the php extension  php_chameleon.dll.

  

 Using it!
 ---------

Available functions:

wmsparse functionalities
------------------------

wmsparse_add_server( string pszXMLDoc, string pszServerDB, string pszLayerDB, 
                     string pszBBoxDB, string pszStyleDB, 
                     string pszSRSFileName, string pszAbstractFileName, 
                     [int nServerID] )

Function to load WMS Server info in various DBF. pszXMLDoc is 
the XML file of the WMS capabilities. All other parameters 
are path to the dbf files containing the WMS informations.


wmsparse_add_server_dir( string pszXMLDoc, string pszDirectory, int nServerID )

Function to load WMS Server info in various DBF. DBF Are located 
in pszDirectory. The names are: server.dbf, layer.dbf, bbox.dbf 
and style.dbf. pszXMLDoc is the XML file of the WMS capabilities. 
