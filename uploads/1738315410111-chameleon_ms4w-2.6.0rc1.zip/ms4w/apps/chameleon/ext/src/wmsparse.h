/**********************************************************************
 * $Id: wmsparse.h,v 1.2 2005/04/12 15:13:47 jlacroix Exp $
 *
 * Name:     wmsparse.c
 * Project:  MapLab/MapBrowser
 * Purpose:  Parse a OGC WMS capabilities file into a set of dbase files
 * Author:   Paul Spencer, spencer@dmsolutions.ca
 *
 **********************************************************************
 * Copyright (c) 2001,2002, DM Solutions Group Inc
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 **********************************************************************
 * $Log: wmsparse.h,v $
 * Revision 1.2  2005/04/12 15:13:47  jlacroix
 * Include CPL for error handling
 *
 * Revision 1.1  2004/12/21 13:32:18  jlacroix
 * Initial Revision
 *
 *
 */


//standard headers
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//libxml headers
#include <libxml/parser.h>
#include <libxml/xpath.h>

//dbase support taken from shapelib
#include "shapefil.h"

//CPL (Common Portable Library) headers
#include "cpl_port.h"
#include "cpl_error.h"

#define INCHES_PER_METER 39.3701

#ifndef M_SQRT2
# define M_SQRT2	1.41421356237309504880	/* sqrt(2) */
#endif

int getMaxID( DBFHandle hDB, char * szField );

xmlChar * getXPathNodePath( xmlNodePtr pNode );

xmlChar * getXPathNodeAttribute( xmlXPathContextPtr pContext,
                                 xmlChar * pszPath, xmlChar * pszAttribute );

xmlChar * getXPathNodeContent( xmlXPathContextPtr pContext, xmlChar * pszPath);

xmlChar * xmlConcat( xmlChar * first , xmlChar * second );

xmlChar * wmsTrim( xmlChar *pszString );

xmlChar * wmsEncode( xmlChar * pszStrContent);

void addCapability( DBFHandle hCapabDB, int nLayerID, int nServerID, 
                    xmlChar* pszName, xmlChar* pszTitle, xmlChar *pszSRS,
                    xmlChar* pszMetaDataURLType,
                    xmlChar* pszMetaDataURLFormat,
                    xmlChar* pszMetaDataURLOnlineResource,
                    float ll_minx,
                    float ll_miny, float ll_maxx, float ll_maxy,
                    double dMinScale, double dMaxScale, int bbox_id,
                    int style_id, char* pszDepth, int nQueryable,
                    int nAbstractID, int nExtractID, int anEnableModule[4] );

int addBBox( DBFHandle hBBoxDB, xmlChar * pszSRS, float nMinX, float nMinY, 
             float nMaxX, float nMaxY, int bNextID );

int addStyle(DBFHandle hStyleDB, xmlChar* pszName, xmlChar* pszTitle, 
             xmlChar* pszLegendURL, int nLegendHeight, int nLegendWidth, 
             xmlChar* pszLegendFormat, xmlChar* pszStyleSheetURL, 
             xmlChar* pszStyleURL, int bNextID );

void processExtractLayer( xmlXPathContextPtr pContext, int anEnableModule[4] );

int getExtractLayerID( xmlChar * pszName );

int processLayerStyle( DBFHandle hStyleDB, xmlXPathContextPtr pContext, 
                       xmlChar * pszPath , xmlChar * pszVersion);

int processLayerBBox( DBFHandle hBBoxDB, xmlXPathContextPtr pContext, 
                      xmlChar * pszPath );

double scaleHintToScaleDenominator( double dScaleHint, double dResolution);

int add_layer(DBFHandle hCapabDB, DBFHandle hBBoxDB, DBFHandle hStyleDB, 
              FILE *hSRSfile, FILE *hAbstractFile, 
              int nLayerID, int nServerID, xmlXPathContextPtr pContext,
              xmlChar * pszVersion, xmlChar* pszPath,
              xmlChar* pszSRS, float ll_minx, float ll_miny, float ll_maxx,
              float ll_maxy, int bb_id, char * pszDepth, 
              int anEnableModule[4]);

int add_server( const xmlChar *pszXMLDoc, const xmlChar *pszServerDB, 
                const xmlChar *pszLayerDB, const xmlChar *pszBBoxDB, 
                const xmlChar *pszStyleDB, const xmlChar *pszSRSFileName, 
                const xmlChar *pszAbstractFileName, int nServerID);
