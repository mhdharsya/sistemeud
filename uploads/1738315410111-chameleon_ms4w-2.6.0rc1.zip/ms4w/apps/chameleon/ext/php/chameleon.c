/*
  +----------------------------------------------------------------------+
  | PHP Version 4                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2003 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 2.02 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available at through the world-wide-web at                           |
  | http://www.php.net/license/2_02.txt.                                 |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author:                                                              |
  +----------------------------------------------------------------------+

  $Id: chameleon.c,v 1.3 2005/04/12 15:14:36 jlacroix Exp $ 
*/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"
#include "php_chameleon.h"


#ifdef PHP4
#define ZEND_DEBUG 0
#endif

/* True global resources - no need for thread safety here */
static int le_chameleon;

/* {{{ chameleon_functions[]
 *
 * Every user visible function must have an entry in chameleon_functions[].
 */
function_entry chameleon_functions[] = {
	PHP_FE(wmsparse_add_server,	NULL)
	PHP_FE(wmsparse_add_server_dir,	NULL)
	{NULL, NULL, NULL}	/* Must be the last line in chameleon_functions[] */
};
/* }}} */

/* {{{ chameleon_module_entry
 */
zend_module_entry chameleon_module_entry = {
#if ZEND_MODULE_API_NO >= 20010901
	STANDARD_MODULE_HEADER,
#endif
	"chameleon",
	chameleon_functions,
	PHP_MINIT(chameleon),
	PHP_MSHUTDOWN(chameleon),
	PHP_RINIT(chameleon),		/* Replace with NULL if there's nothing to do at request start */
	PHP_RSHUTDOWN(chameleon),	/* Replace with NULL if there's nothing to do at request end */
	PHP_MINFO(chameleon),
#if ZEND_MODULE_API_NO >= 20010901
	"0.1", /* Replace with version number for your extension */
#endif
	STANDARD_MODULE_PROPERTIES
};
/* }}} */

#ifdef COMPILE_DL_CHAMELEON
ZEND_GET_MODULE(chameleon)
#endif

/* {{{ PHP_MINIT_FUNCTION
 */
PHP_MINIT_FUNCTION(chameleon)
{
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MSHUTDOWN_FUNCTION
 */
PHP_MSHUTDOWN_FUNCTION(chameleon)
{
	return SUCCESS;
}
/* }}} */

/* Remove if there's nothing to do at request start */
/* {{{ PHP_RINIT_FUNCTION
 */
PHP_RINIT_FUNCTION(chameleon)
{
	return SUCCESS;
}
/* }}} */

/* Remove if there's nothing to do at request end */
/* {{{ PHP_RSHUTDOWN_FUNCTION
 */
PHP_RSHUTDOWN_FUNCTION(chameleon)
{
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MINFO_FUNCTION
 */
PHP_MINFO_FUNCTION(chameleon)
{
	php_info_print_table_start();
	php_info_print_table_header(2, "chameleon support", "enabled");
	php_info_print_table_end();
}
/* }}} */

/***********************************************************************
 *            Utils functions
 **********************************************************************/

/*************************
 *  Error report function
 *************************/
static void *PHPErrorHandler( CPLErr eErrClass, int nError,
                             const char * pszErrorMsg )
{
    php_error(E_WARNING, pszErrorMsg);
}


/***********************************************************************
 *            PHP functions
 **********************************************************************/


/* {{{ proto  wmsparse_add_server(string pszXMLDoc, string pszServerDB, 
   string pszLayerDB, string pszBBoxDB, 
   string pszStyleDB, string pszSRSFileName, 
   string pszAbstractFileName [, int nServerID])
   Function to load WMS Server info in various DBF. */
PHP_FUNCTION(wmsparse_add_server)
{
	char *pszXMLDoc = NULL;
	char *pszServerDB = NULL;
	char *pszLayerDB = NULL;
	char *pszBBoxDB = NULL;
	char *pszStyleDB = NULL;
	char *pszSRSFileName = NULL;
	char *pszAbstractFileName = NULL;
	int argc = ZEND_NUM_ARGS();
	int pszXMLDoc_len;
	int pszServerDB_len;
	int pszLayerDB_len;
	int pszBBoxDB_len;
	int pszStyleDB_len;
	int pszSRSFileName_len;
	int pszAbstractFileName_len;
	long nServerID = -1;
    int nStatus;

    CPLSetErrorHandler(PHPErrorHandler);

	if (zend_parse_parameters(argc TSRMLS_CC, "sssssss|l", &pszXMLDoc, &pszXMLDoc_len, &pszServerDB, &pszServerDB_len, &pszLayerDB, &pszLayerDB_len, &pszBBoxDB, &pszBBoxDB_len, &pszStyleDB, &pszStyleDB_len, &pszSRSFileName, &pszSRSFileName_len, &pszAbstractFileName, &pszAbstractFileName_len, &nServerID) == FAILURE) 
		WRONG_PARAM_COUNT;

    nStatus = add_server(pszXMLDoc, pszServerDB, pszLayerDB, pszBBoxDB, 
                         pszStyleDB, pszSRSFileName, pszAbstractFileName, 
                         nServerID);

    RETURN_LONG( nStatus );
}
/* }}} */

/* {{{ proto  wmsparse_add_server_dir(string pszXMLDoc, string pszDirectory 
                                      [, int nServerID])
   Function to load WMS Server info in various DBF. DBF Are located in 
   pszDirectory. The names are: server.dbf, layer.dbf, bbox.dbf and style.dbf. 
*/
PHP_FUNCTION(wmsparse_add_server_dir)
{
	char *pszXMLDoc = NULL;
	char *pszDirectory = NULL;
	char *pszDirWithSlash = NULL;
	char *pszServerDB = NULL;
	char *pszLayerDB = NULL;
	char *pszBBoxDB = NULL;
	char *pszStyleDB = NULL;
	char *pszSRSFileName = NULL;
	char *pszAbstractFileName = NULL;
	int argc = ZEND_NUM_ARGS();
	int pszXMLDoc_len;
	int pszDirectory_len;
	long nServerID;
    int nStatus;

    CPLSetErrorHandler(PHPErrorHandler);

	if (zend_parse_parameters(argc TSRMLS_CC, "ss|l", &pszXMLDoc, &pszXMLDoc_len, &pszDirectory, &pszDirectory_len, &nServerID) == FAILURE) 
		return;

    if(pszDirectory[pszDirectory_len - 1] != '/' && 
       pszDirectory[pszDirectory_len - 1] != '\\')
        pszDirWithSlash = xmlConcat( pszDirectory, "/" );
    else
        pszDirWithSlash = strdup(pszDirectory);

    pszServerDB = xmlConcat( pszDirWithSlash, "server.dbf" );
    pszLayerDB = xmlConcat( pszDirWithSlash, "layer.dbf" );
    pszBBoxDB = xmlConcat( pszDirWithSlash, "bbox.dbf" );
    pszStyleDB = xmlConcat( pszDirWithSlash, "style.dbf" );
    free(pszDirWithSlash);

    nStatus = add_server(pszXMLDoc, pszServerDB, pszLayerDB, pszBBoxDB, 
                         pszStyleDB, pszSRSFileName, pszAbstractFileName, 
                         nServerID);

    RETURN_LONG( nStatus );

}
/* }}} */


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
