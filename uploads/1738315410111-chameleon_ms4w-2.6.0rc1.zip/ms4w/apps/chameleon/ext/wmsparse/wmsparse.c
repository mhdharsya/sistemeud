/**********************************************************************
 * $Id: wmsparse.c,v 1.2 2005/04/12 15:14:17 jlacroix Exp $
 *
 * Name:     wmsparse.c
 * Project:  MapLab/MapBrowser
 * Purpose:  Parse a OGC WMS capabilities file into a set of dbase files
 * Author:   Paul Spencer, spencer@dmsolutions.ca
 *
 **********************************************************************
 * Copyright (c) 2001,2002, DM Solutions Group Inc
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 **********************************************************************
 * $Log: wmsparse.c,v $
 * Revision 1.2  2005/04/12 15:14:17  jlacroix
 * Include CPL for error handling
 *
 * Revision 1.1  2004/12/21 13:32:18  jlacroix
 * Initial Revision
 *
 * Revision 1.38  2004/11/11 21:03:29  pspencer
 * bug DM 3325: added metadataurl support
 *
 * Revision 1.37  2004/11/10 16:43:18  pspencer
 * bug DM 3325: added Daniel's implementation of scaleHintToScaleDenominator
 *
 * Revision 1.36  2004/11/10 15:59:54  pspencer
 * bug DM 3325: added scale hint capacity (pending Daniel's implementation of scaleHintToScale)
 *
 * Revision 1.35  2003/05/12 15:04:24  sacha
 * remove the space added beetwee formats
 *
 * Revision 1.34  2002/11/26 14:01:53  julien
 * Valid the 3 optional legendURL field
 *
 * Revision 1.33  2002/11/21 22:47:53  daniel
 * OOpps... fixed a typo in usage output (WMSPARSE instead of WSMPARSE)
 *
 * Revision 1.32  2002/11/21 22:06:24  daniel
 * Contert strings from UTF-8 (libxml2 default) to ISO-8859-1 (our default)
 *
 * Revision 1.31  2002/11/20 04:46:24  daniel
 * Added wmsTrim() to trim spaces in layer titles from some servers
 *
 * Revision 1.30  2002/11/19 22:35:23  julien
 * change the stylesheeturl field in style.dbf to stylesheet.
 *
 * Revision 1.29  2002/11/19 22:31:31  daniel
 * Fixed more memory leaks
 *
 * Revision 1.28  2002/11/19 21:25:40  daniel
 * Added -v (version) command-line switch and added version/date info to
 * usage message.
 *
 * Revision 1.27  2002/11/19 21:09:50  julien
 * Add legendurl height, width and format for the mapcontext in the style.dbf
 *
 * Revision 1.26  2002/11/19 21:04:05  daniel
 * Added copyright header.
 * Run into Purify and fixed some memory issues.
 *
 */

#include "wmsparse.h"

/**
 * application mainline
 *
 * expects several arguments - xml file name, server db name, capabilities
 * db name, bbox db name, style db name, srs text file name, and server id
 *
 * xml file name - the path and name of an WMS Capabilities XML file
 *
 * server db name - the path and name of a dbase file for server info
 *
 * capabilities db name - the path and name of a dbase for for layer info
 *
 * bbox db name - the path and name of a dbase file for bounding box info
 *
 * srs file name - the path and name of a text file for srs info
 *
 * abstract file name - the path and name of a text file for abstract info
 *
 * server id - the id of the server we are parsing for (in the server db)
 */
int main( int argc, char * argv[] )
{
  int nServerID, nDirLen, nReturnValue;
  xmlChar *pszDirectory, *pszFile;
  xmlChar *pszSRSFileName, *pszAbstractFileName;
  xmlChar *pszServerDB, *pszLayerDB, *pszStyleDB, *pszBBoxDB, *pszXMLDoc;

  // Return version information with '-v' command-line switch
  if ( argc == 2 && strcasecmp(argv[1], "-v") == 0 )
  {
      printf( "WMSPARSE - ($Revision: 1.2 $, $Date: 2005/04/12 15:14:17 $)\n");
      return 1;
  }
  if ( argc < 8 && argc != 3 && argc != 4 )
  {
      printf( "WMSPARSE - ($Revision: 1.2 $, $Date: 2005/04/12 15:14:17 $)\n\n");
      printf( "ERROR: invalid number of arguments!\n\n" );
      printf( "Usage: \n");
      printf( " %s -v\n", argv[0] );
      printf( "or\n" );
      printf( " %s xmlfile directory [serverid]\n", argv[0] );
      printf( "or\n" );
      printf( " %s xmlfile serverdb layerdb ", argv[0] );
      printf( "bboxdb styledb\n\tsrsfile abstractfile [serverid]\n\n" );
      return -1;
  }

  pszXMLDoc = xmlStrdup( argv[1] );

  if(argc == 3 || argc == 4)
  {
      pszFile = xmlStrdup(argv[2]);
      nDirLen = strlen(pszFile);
      if(pszFile[nDirLen - 1] != '/' && pszFile[nDirLen - 1] != '\\')
          pszDirectory = xmlConcat( pszFile, "/" );
      else
          pszDirectory = xmlStrdup(argv[2]);
      xmlFree(pszFile);

      pszServerDB = xmlConcat( pszDirectory, "server.dbf" );
      pszLayerDB = xmlConcat( pszDirectory, "layer.dbf" );
      pszBBoxDB = xmlConcat( pszDirectory, "bbox.dbf" );
      pszStyleDB = xmlConcat( pszDirectory, "style.dbf" );

      //get server ID
      if ( argc == 4 )
          nServerID = atoi(argv[3]);
      else
          nServerID = -1;

      //open the srs txt file;
      pszFile = (xmlChar*)xmlMalloc(  sizeof(xmlChar) * 15 );
      sprintf(pszFile, "s%dsrs.txt", nServerID );
      pszSRSFileName = xmlConcat( pszDirectory, pszFile );
      xmlFree( pszFile );

      //open the abstract txt file
      pszFile = (xmlChar*)xmlMalloc(  sizeof(xmlChar) * 20 );
      sprintf(pszFile, "a%dabstract.txt", nServerID );
      pszAbstractFileName = xmlConcat( pszDirectory, pszFile );
      xmlFree( pszFile );

      xmlFree(pszDirectory);
  }
  else
  {
      pszServerDB = xmlStrdup( argv[2] );
      pszLayerDB = xmlStrdup( argv[3] );
      pszBBoxDB = xmlStrdup( argv[4] );
      pszStyleDB = xmlStrdup( argv[5] );

      //open the SRS txt file
      pszSRSFileName = xmlStrdup( argv[6] );

      //open the abstract txt file
      pszAbstractFileName = xmlStrdup( argv[7] );

      if ( argc == 9 )
          nServerID = atoi(argv[8]);
      else
          nServerID = -1;
  }

  // load the server.
  nReturnValue = add_server( pszXMLDoc, pszServerDB, pszLayerDB, pszBBoxDB, 
                             pszStyleDB, pszSRSFileName, pszAbstractFileName, 
                             nServerID);

  // Free variables
  xmlFree(pszXMLDoc);
  xmlFree(pszServerDB);
  xmlFree(pszLayerDB);
  xmlFree(pszBBoxDB);
  xmlFree(pszStyleDB);
  xmlFree(pszSRSFileName);
  xmlFree(pszAbstractFileName);

  return nReturnValue;
}

