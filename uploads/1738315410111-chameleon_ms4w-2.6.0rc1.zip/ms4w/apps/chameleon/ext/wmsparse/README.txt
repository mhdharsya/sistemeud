WMSPARSE
++++++++

About WMSPARSE
--------------

this is a utility used to parse a WMT Capabilities file (version 1.0.0 or 
1.0.1) into several DBF files that are then used by PHP applications to
provide access to the layers provided by the WMS server.

The utility will only work with version 1.0.0 or 1.0.1 files, so when
requesting the capabilities file, make sure to specify:

http://url/to/wms/server?request=capabilities&wmtver=1.0.1

Building WMSPARSE
-----------------

On Linux/Unix
+++++++++++++

you will need libxml2-2.4.13 or later installed.  See http://xmlsoft.org for
the latest version.  After it is compiled and installed, type:

  $ libxml2-config --version
  
at a command prompt and make sure it returns the right version number.
Now you can simply type make.

On Windows
++++++++++

Please see the READEME.txt (COMPILATION ON WINDOWS) in the main ext directory.

Testing
-------

once built, copy all .dbf files to .bak.  There should be server.dbf,
layer.dbf and bbox.dbf.  There can be a style.dbf too, but this file is 
optional.  The wmsparse will try to detect and use it only if the 'style_id' 
field exist in layer.dbf.  You can test wmsparse by typing the following 
command:

wmsparse[.exe] test2.xml path_to_config_file.xml path_to_dbf_dir/

you shouldn't see any errors and you should be able to view the entries
in the server.dbf, layer.dbf and bbox.dbf files.  A text file should have 
been created then, s1srs.txt.

Three other options can be used.  If layer.dbf contains a field called 
'abstractid', a file called a1abstract.txt will be created.  The extractable 
option is activated with the 'extractabl' field in layer.dbf and the 
capabability URL is activated with the 'capab_url' in server.dbf.
