<?
// Packages
define("EXTRACTABLE_LAYER", true);
define("LAYER_ABSTRACT", true);
define("LAYER_STYLE", true);

// Extra fields
$gaExtraFields = array(DB_SERVER => array(), 
                       DB_STYLE => array(), 
                       DB_THEME => array(), 
                       DB_ALIAS => array(), 
                       DB_LAYER => array(), 
                       DB_FIELD => array(), 
                       DB_CAPABILITIES => array(), 
                       DB_BBOX => array());
?>