<?php
/**
  _____________________________________________________________________________
 | 
 | Config GUI
 |
 | @project     Chameleon
 | @revision    $Id: main.php,v 1.6 2004/12/06 15:58:42 wbronsema Exp $
 | @purpose     Configuration Tool for Chameleon
 | @author      DM Solutions Group (wbronsema@dmsolutions.ca)
 | @copyright
 | <b>Copyright (c) 2004 DM Solutions Group Inc.</b>
 | Permission is hereby granted, free of charge, to any person obtaining a
 | copy of this software and associated documentation files (the "Software"),
 | to deal in the Software without restriction, including without limitation
 | the rights to use, copy, modify, merge, publish, distribute, sublicense,
 | and/or sell copies of the Software, and to permit persons to whom the
 | Software is furnished to do so, subject to the following conditions:
 |
 | The above copyright notice and this permission notice shall be included
 | in all copies or substantial portions of the Software.
 |
 | THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 | IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 | FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 | THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 | LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 | FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 | DEALINGS IN THE SOFTWARE.
 |_____________________________________________________________________________

 **/
 
/* ============================================================================
 * Configure
 * ========================================================================= */
// define the file system path to the configuration directory (MUST have trailing "/")
define('CONFIG_DIR', '../../config/');

// define the filesystem path to the chameleon data directory
define('DATA_DIR', '../../data/');

// define the file system path and file name for the configuration files
define( 'CONFIG_FILE', CONFIG_DIR.'chameleon.xml' );
define( 'CWC2_CONFIG_FILE', CONFIG_DIR.'cwc2.xml' );
  
// define the file system path to the common directory (MUST have trailing "/")
define( 'COMMON', '../../htdocs/common/' );;

// include the appcontext code from the common directory
include( COMMON.'appcontext/appcontext.php');

/* ============================================================================
 * Check if the chameleon & cwc2 config files exist
 * ========================================================================= */
$szChameleonConfig = checkConfig( CONFIG_FILE, CONFIG_DIR.'chameleon.xml-dist' );
$szCWC2Config = checkConfig( CWC2_CONFIG_FILE, CONFIG_DIR.'cwc2.xml-dist' );

/* ============================================================================
 * Create hyperlinks to the config files
 * ========================================================================= */
// create javascript links
$szChameleonConfig = strlen( $szChameleonConfig ) > 0 ? 
    'alert(\''.$szChameleonConfig.'\')' :'selectPage(\'configure\')';
$szCWC2Config = strlen( $szCWC2Config ) > 0 ? 
    'alert(\''.$szCWC2Config.'\')' :'selectPage(\'configureCWC2\')';    

/* ============================================================================
 * Load necessary modules
 * ========================================================================= */
if ( !extension_loaded( 'gd' ) ) 
{ 
   dl('php_gd2.' . PHP_SHLIB_SUFFIX ); 
}
if ( !extension_loaded( 'dbase' ) ) 
{ 
   dl('php_dbase.' . PHP_SHLIB_SUFFIX ); 
}


/* ============================================================================
* Check if apache
* ========================================================================= */
// check if $_SERVER["DOCUMENT_ROOT"] is set to determine an APACHE configuration
$bApache = isset( $_SERVER["DOCUMENT_ROOT"] );

/* ============================================================================
 * Set error reporting levels
 * ========================================================================= */
error_reporting( E_ALL );

/* ============================================================================
 * Build an array with the HTTP GET or POST parameters.
 * ========================================================================= */
$_FORM =  array_merge( $_POST, $_GET );


/**
  _____________________________________________________________________________
 | 
 |  checkConfig()
 |
 |  Postcondition:  This function creates a new config file from the given 
 |                  template if necessary.
 |  
 |  @param $szFile string - File to check and create as necessary.
 |  @param $szTemplate string - File to copy.
 |  @return String - Empty string if successful or errors messages on failure.
 |  @desc Checks and creates as necessary given config file.
 |__________________________________________________________________________
    
 **/
function checkConfig( $szFile, $szTemplate )
{
    // check if the file exists
    if ( file_exists( $szFile ) )
    {
        return '';
    }
    
    // file does not exist, check template
    if ( !file_exists( $szTemplate ) )
    {
        return 'The configuration file('.$szFile.
            ') does not exist nor does the template file('.$szTemplate.
            ').\n\nUnable to create new config file from template.';
    }
    
    // copy the template
    if ( !@copy( $szTemplate, $szFile ) )
    {
        return 'Unable to create new config file('.$szFile.
            ') from template file('.$szTemplate.
            ').\n\nPlease check directory permissions.';
    }
    
    // success
    return '';
}
  
?>