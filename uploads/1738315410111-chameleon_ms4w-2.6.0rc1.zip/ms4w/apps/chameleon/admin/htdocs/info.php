<?php
/**
  _____________________________________________________________________________
 | 
 | Info functions
 |
 | @project     Chameleon
 | @revision    $Id: info.php,v 1.2 2004/10/22 17:16:51 wbronsema Exp $
 | @purpose     Configuration Tool for Chameleon
 | @author      DM Solutions Group (wbronsema@dmsolutions.ca)
 | @copyright
 | <b>Copyright (c) 2004 DM Solutions Group Inc.</b>
 | Permission is hereby granted, free of charge, to any person obtaining a
 | copy of this software and associated documentation files (the "Software"),
 | to deal in the Software without restriction, including without limitation
 | the rights to use, copy, modify, merge, publish, distribute, sublicense,
 | and/or sell copies of the Software, and to permit persons to whom the
 | Software is furnished to do so, subject to the following conditions:
 |
 | The above copyright notice and this permission notice shall be included
 | in all copies or substantial portions of the Software.
 |
 | THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 | IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 | FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 | THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 | LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 | FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 | DEALINGS IN THE SOFTWARE.
 |_____________________________________________________________________________

 **/

/* ============================================================================
 * Open XML
 * ========================================================================= */
// get info from xml
//$oAppContext = new AppContext( CONFIG_FILE );

/* ============================================================================
 * Mapscript Info
 * ========================================================================= */
// ensure mapscript module is loaded
if (!extension_loaded("MapScript"))
    $bMapscriptValid = @dl($oAppContext->getContextValue("mapscript_module"));
else
    $bMapscriptValid = true;

// initialize array
$gaMSImageTypes = array();

if ( $bMapscriptValid )
{
    // check each
    if (strpos( ms_GetVersion(), "OUTPUT=GIF") > 0 )
        array_push( $gaMSImageTypes, "MS_GIF" );
    if (strpos( ms_GetVersion(), "OUTPUT=PNG") > 0 )
        array_push( $gaMSImageTypes, "MS_PNG" );
    if (strpos( ms_GetVersion(), "OUTPUT=JPEG") > 0 )
        array_push( $gaMSImageTypes, "MS_JPEG" );
    if (strpos( ms_GetVersion(), "OUTPUT=WBMP") > 0 )
        array_push( $gaMSImageTypes, "MS_WBMP" );
    if (strpos( ms_GetVersion(), "OUTPUT=PDF") > 0 )
        array_push( $gaMSImageTypes, "MS_PDF" );
    if (strpos( ms_GetVersion(), "OUTPUT=SWF") > 0 )
        array_push( $gaMSImageTypes, "MS_SWF" );
}

/* ============================================================================
 * Php Image Types
 * ========================================================================= */
// initialize array
$gaPhpImageTypes = array();

// check each
if ( ImageTypes() & IMG_GIF )
   array_push( $gaPhpImageTypes, "GIF" );
if ( ImageTypes() & IMG_PNG )
   array_push( $gaPhpImageTypes, "PNG" );
if ( ImageTypes() & IMG_JPG )
   array_push( $gaPhpImageTypes, "JPEG" );
if ( ImageTypes() & IMG_WBMP )
   array_push( $gaPhpImageTypes, "WBMP" );

/* ============================================================================
 * Php Configuration File Settings
 *
 * the array has the configuration value as the key and the value is an array
 * of three elements.  The first is the required value.  The second is
 * read from PHP using ini_get.  The third is the message to display about the
 * setting.  The same structure is used for both Mandatory and Recommended
 * settings.
 * ========================================================================= */
$gaszMandatorySettings = array(
    "enable_dl" => array( "1", "1", "this value must be set to on or 1 in php.ini" ),
    "file_uploads" => array( "1", "1", "this value must be set to on or 1 in php.ini" ),
    "allow_url_fopen" => array( "1", "1", "this value must be set to on or 1 in php.ini" )
                              );

foreach( array_keys($gaszMandatorySettings) as $szIniKey)
{
    $gaszMandatorySettings[$szIniKey][1] = ini_get( $szIniKey );
}

$gaszRecommendedSettings = array(
    "register_globals" => array( "0", "0", "this value should be set to off or 0 in php.ini" ),
    "display_errors" => array( "0", "0", "this value should be set to off or 0 in php.ini" ),
    "log_errors" => array( "1", "1", "this value should be set to on or 1 in php.ini" ),
    "error_reporting" => array( "0", "0", "this value should be E_ALL in php.ini" )
                                );

foreach( array_keys($gaszRecommendedSettings) as $szIniKey )
{
    if ($szIniKey == "error_reporting")
    {
        $anErrorLevels = array( "E_ERROR" => 1,
                                "E_WARNING" => 2,
                                "E_PARSE" => 4,
                                "E_NOTICE" => 8,
                                "E_CORE_ERROR" => 16,
                                "E_CORE_WARNING" => 32,
                                "E_COMPILE_ERROR" => 64,
                                "E_COMPILE_WARNING" => 128,
                                "E_USER_ERROR" => 256,
                                "E_USER_WARNING" => 512,
                                "E_USER_NOTICE" => 1024
                              );
        //calculate the output string for the current value
        //and set it in index 1
        $nErrorLevel = error_reporting();
        $szValue = "<font size=1>";
        $szSep = "";
        foreach( $anErrorLevels as $szLevel => $nLevel )
        {
            if ($nErrorLevel & $nLevel)
            {
                $szValue .= $szSep.$szLevel;
                $szSep = "<BR>";
            }
        }
        $szValue .= "</font>";
        $gaszRecommendedSettings[$szIniKey][1] = $szValue;

        //calculate the output string if E_NOTICE is not included
        //and set it as the required value (index 0)
        $nErrorLevel = E_ALL;
        $szValue = "<font size=1>";
        $szSep = "";
        foreach( $anErrorLevels as $szLevel => $nLevel )
        {
            if ($nErrorLevel & $nLevel)
            {
                $szValue .= $szSep.$szLevel;
                $szSep = "<BR>";
            }
        }
        $szValue .= "</font>";
        $gaszRecommendedSettings[$szIniKey][0] = $szValue;
    }
    elseif ( $szIniKey == "register_globals" )
    {
        // NOTE: there seems to be a bug in PHP that returns "" when false
        $szTmpString = ini_get( "register_globals" );
        if ( $szTmpString == "" )
            $gaszRecommendedSettings[$szIniKey][1] = 0;
        else
            $gaszRecommendedSettings[$szIniKey][1] = 1;

    }
    elseif ( $szIniKey == "display_errors" )
    {
        // NOTE: there seems to be a bug in PHP that returns "" when false
        $szTmpString = ini_get( "display_errors" );
        if ( $szTmpString == "" )
            $gaszRecommendedSettings[$szIniKey][1] = 0;
        else
            $gaszRecommendedSettings[$szIniKey][1] = 1;

    }
    else
    {
        $gaszRecommendedSettings[$szIniKey][1] = ini_get( $szIniKey );
    }
}



/* ============================================================================
 * Php Required Modules (in enable_dl is off)
 * ========================================================================= */
$gaszModuleNames = array( "MapScript" => "",
                          "dbase" => "",
                          "gd" => "" );
foreach( array_keys($gaszModuleNames) as $szModuleName )
{
    $gaszModuleNames[$szModuleName] = extension_loaded( $szModuleName );
}

/* ============================================================================
 * Determine Mapscript image values
 * ========================================================================= */
$szMSGIFStatusImage = in_array( "MS_GIF", $gaMSImageTypes ) ? 
                            './images/icon_on.gif' : './images/icon_off.gif';
$szMSPNGStatusImage = in_array( "MS_PNG", $gaMSImageTypes ) ? 
                            './images/icon_on.gif' : './images/icon_off.gif';
$szMSJPEGStatusImage = in_array( "MS_JPEG", $gaMSImageTypes ) ? 
                            './images/icon_on.gif' : './images/icon_off.gif';
$szMSWBMPStatusImage = in_array( "MS_WBMP", $gaMSImageTypes ) ? 
                            './images/icon_on.gif' : './images/icon_off.gif';
$szMSPDFStatusImage = in_array( "MS_PDF", $gaMSImageTypes ) ? 
                            './images/icon_on.gif' : './images/icon_off.gif';
$szMSSWFStatusImage = in_array( "MS_SWF", $gaMSImageTypes ) ? 
                            './images/icon_on.gif' : './images/icon_off.gif';
                            
/* ============================================================================
 * Determine GD image values
 * ========================================================================= */
$szGDGIFStatusImage = in_array( "GIF", $gaPhpImageTypes ) ? 
                            './images/icon_on.gif' : './images/icon_off.gif';
$szGDPNGStatusImage = in_array( "PNG", $gaPhpImageTypes ) ? 
                            './images/icon_on.gif' : './images/icon_off.gif';
$szGDJPEGStatusImage = in_array( "JPEG", $gaPhpImageTypes ) ? 
                            './images/icon_on.gif' : './images/icon_off.gif';
$szGDWBMPStatusImage = in_array( "WBMP", $gaPhpImageTypes ) ? 
                            './images/icon_on.gif' : './images/icon_off.gif';
                            

/**
 * Postcondition:   This function takes the given string and adds "<br>" tags at
 *                  the requested character interval.
 * @param $szString string - The string to break.
 * @param $nInterval integer - The character interval.
 * @return string - The string with <br> tags.
 **/
function breakString( $szString, $nInterval )
{
    // init vars
    $szNewString = "";
    $nCount = 0;

    // loop through and break at every "$nInterval" chars
    for ( $i = 0; $i < strlen( $szString ); $i++ )
    {
        // increment counter
        $nCount++;

        // add next character
        $szNewString .= substr( $szString, $i, 1 );

        // if the count is "$nInterval" then add break
        if ( $nCount == $nInterval )
        {
            $szNewString .= "<br>";
            $nCount = 0;
        }
    }

    // return the new string
    return $szNewString;
}
?>
