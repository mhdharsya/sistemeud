<?php
/**
  _____________________________________________________________________________
 | 
 | Config GUI
 |
 | @project     Chameleon
 | @revision    $Id: edit_xml.php,v 1.4 2004/10/25 20:35:25 wbronsema Exp $
 | @purpose     Configuration Tool for Chameleon
 | @author      DM Solutions Group (wbronsema@dmsolutions.ca)
 | @copyright
 | <b>Copyright (c) 2004 DM Solutions Group Inc.</b>
 | Permission is hereby granted, free of charge, to any person obtaining a
 | copy of this software and associated documentation files (the "Software"),
 | to deal in the Software without restriction, including without limitation
 | the rights to use, copy, modify, merge, publish, distribute, sublicense,
 | and/or sell copies of the Software, and to permit persons to whom the
 | Software is furnished to do so, subject to the following conditions:
 |
 | The above copyright notice and this permission notice shall be included
 | in all copies or substantial portions of the Software.
 |
 | THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 | IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 | FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 | THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 | LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 | FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 | DEALINGS IN THE SOFTWARE.
 |_____________________________________________________________________________

 **/

if (!isset($_FORM["bSave"]))
{
    $_FORM["bSave"] = false;
}

/* ============================================================================
 * Check for valid config file
 * ========================================================================= */
// initialize vars
$gszStatus = '';
$gbErrors = false;
 

//TODO: add regex expression to make sure that this value is a valid file
//name, ends with XML and doesn't have any extra path information than it
//should.  Should probably limit it to one of four file names also.
// check if the file is read-only
$gbWritable = is_writable( CONFIG_FILE ) && is_writable( CWC2_CONFIG_FILE );

// create the new appcontext objects
$oAppContext = new AppContext( CONFIG_FILE );
$oCWC2AppContext = new AppContext( CWC2_CONFIG_FILE );

/* ============================================================================
* Process save command
* ========================================================================= */    
if ( $_FORM['bSave'] == 1 && $gbWritable )
{
    // set flag
    $bChanged = false;
    
    //array of changed keys
    $aszChangedKeys = array();
    
    // loop through each query variable and set
    foreach ($_FORM as $szKey => $szValue)
    {
        // init var
        $bRet = false;
        
        // clean any path issues
        $szValue = str_replace( '\\\\', '/', $szValue );
        $szValue = str_replace( '\\', '/', $szValue );
     
        // process chameleon & CWC2 separately
        $szXMLKey = substr( $szKey, 0, -5 );
        $szXMLSuffix = substr( $szKey, -5 );
        
        // get temp app object                                   
        if ( $szXMLSuffix == '_cham' )
        {
            // set value if changed
            $szCurrentValue = $oAppContext->getContextValue( $szXMLKey );
            if (trim($szCurrentValue) != trim($szValue))
            {
                $bRet = $oAppContext->setContextValue($szXMLKey, $szValue);
            }  
            
            // always update the description with htmlentities
            $oAppContext->setContextDescription( $szXMLKey, 
               htmlentities( $oAppContext->getContextDescription( $szXMLKey ) ) );
        }
        else
        {
            // set value if changed
            $szCurrentValue = $oCWC2AppContext->getContextValue( $szXMLKey );
            if (trim($szCurrentValue) != trim($szValue))
            {
                $bRet = $oCWC2AppContext->setContextValue($szXMLKey, $szValue);
            }  
            
            // always update the description with htmlentities
            $oCWC2AppContext->setContextDescription( $szXMLKey, 
               htmlentities( $oCWC2AppContext->getContextDescription( $szXMLKey ) ) );            
            
        }
        
        // check for failure
        if ($bRet !== false)
        {
           $bChanged = true;
           array_push($aszChangedKeys, $szKey);
        }
        
    }
    
    // check for any changes
    if ($bChanged)
    {
        // save the files
        $bRes = $oAppContext->saveAppContext( CONFIG_FILE );
        $bRes = $oCWC2AppContext->saveAppContext( CWC2_CONFIG_FILE );
    }
}
?>


