<?php
session_start();
require_once 'config/database.php';

// Redirect ke dashboard jika sudah ada session
if (isset($_SESSION['user_id'])) {
    header('Location: pages/dashboard.php');
    exit;
}

// Proses login
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Validasi sederhana
    if ($username === 'admin' && $password === 'admin123') {
        $_SESSION['user_id'] = 1;
        $_SESSION['username'] = 'admin';
        header('Location: pages/dashboard.php');
        exit;
    } else {
        $error = 'Username atau password salah!';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Pembayaran Kos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

        * {
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(-45deg, #7367F0, #8E44AD, #4158d0, #764ba2);
            background-size: 400% 400%;
            animation: gradient 15s ease infinite;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            padding: 20px;
        }

        @keyframes gradient {
            0% {
                background-position: 0% 50%;
            }
            50% {
                background-position: 100% 50%;
            }
            100% {
                background-position: 0% 50%;
            }
        }

        .login-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 420px;
            transform-style: preserve-3d;
            perspective: 1000px;
            animation: fadeInUp 1s ease;
        }

        .logo {
            text-align: center;
            margin-bottom: 35px;
            transform: translateZ(30px);
            transition: transform 0.3s ease;
        }

        .logo:hover {
            transform: translateZ(50px) scale(1.05);
        }

        .logo-icon {
            font-size: 48px;
            margin-bottom: 15px;
            display: inline-block;
            animation: bounce 2s infinite;
        }

        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% {
                transform: translateY(0);
            }
            40% {
                transform: translateY(-20px);
            }
            60% {
                transform: translateY(-10px);
            }
        }

        .logo-text {
            color: #333;
            font-size: 26px;
            font-weight: 600;
            margin: 0;
            background: linear-gradient(45deg, #7367F0, #8E44AD);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .form-group {
            margin-bottom: 25px;
            position: relative;
        }

        .form-control {
            border-radius: 12px;
            padding: 15px 20px;
            border: 2px solid #eee;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.9);
            font-size: 15px;
        }

        .form-control:focus {
            border-color: #7367F0;
            box-shadow: 0 0 0 0.2rem rgba(115, 103, 240, 0.25);
            transform: translateY(-2px);
        }

        .form-label {
            position: absolute;
            top: -10px;
            left: 15px;
            background: white;
            padding: 0 5px;
            color: #666;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .form-control:focus + .form-label {
            color: #7367F0;
            transform: translateY(-2px);
        }

        .btn-login {
            background: linear-gradient(45deg, #7367F0, #8E44AD);
            border: none;
            border-radius: 12px;
            padding: 15px;
            font-weight: 600;
            color: white;
            width: 100%;
            margin-top: 20px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .btn-login:before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: all 0.5s ease;
        }

        .btn-login:hover:before {
            left: 100%;
        }

        .btn-login:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(115, 103, 240, 0.3);
        }

        .error-message {
            background: rgba(255, 68, 68, 0.1);
            color: #FF4444;
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 25px;
            font-size: 14px;
            display: flex;
            align-items: center;
            animation: shake 0.5s ease;
            border-left: 4px solid #FF4444;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-10px); }
            75% { transform: translateX(10px); }
        }

        .error-message i {
            margin-right: 10px;
            font-size: 18px;
        }

        .input-group {
            position: relative;
        }

        .input-icon {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #7367F0;
            cursor: pointer;
            transition: all 0.3s ease;
            opacity: 0.7;
        }

        .input-icon:hover {
            opacity: 1;
            transform: translateY(-50%) scale(1.1);
        }

        @media (max-width: 480px) {
            .login-container {
                padding: 30px 20px;
            }

            .logo-text {
                font-size: 22px;
            }

            .form-control {
                padding: 12px 15px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container animate__animated animate__fadeInUp">
        <div class="logo">
            <div class="logo-icon">🏠</div>
            <h1 class="logo-text">Sistem Pembayaran Kos Padang</h1>
        </div>

        <?php if (isset($error) && $error !== ''): ?>
            <div class="error-message">
                <i>⚠️</i> <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="" class="animate__animated animate__fadeIn animate__delay-1s">
            <div class="form-group">
                <div class="input-group">
                    <input type="text" class="form-control" id="username" name="username" required>
                    <span class="input-icon">👤</span>
                </div>
                <label for="username" class="form-label">Username</label>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <input type="password" class="form-control" id="password" name="password" required>
                    <span class="input-icon toggle-password">👁️</span>
                </div>
                <label for="password" class="form-label">Password</label>
            </div>
            <button type="submit" class="btn-login">
                Login
            </button>
        </form>
    </div>

    <script>
        // Toggle password visibility
        document.querySelector('.toggle-password').addEventListener('click', function() {
            const passwordInput = document.querySelector('#password');
            const icon = this;
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.textContent = '👁️‍🗨️';
            } else {
                passwordInput.type = 'password';
                icon.textContent = '👁️';
            }
        });

        // Add floating effect on mouse move
        document.addEventListener('mousemove', function(e) {
            const container = document.querySelector('.login-container');
            const xAxis = (window.innerWidth / 2 - e.pageX) / 25;
            const yAxis = (window.innerHeight / 2 - e.pageY) / 25;
            container.style.transform = `rotateY(${xAxis}deg) rotateX(${yAxis}deg)`;
        });

        // Reset transform on mouse leave
        document.querySelector('.login-container').addEventListener('mouseleave', function() {
            this.style.transform = 'rotateY(0) rotateX(0)';
        });

        // Smooth transition on form elements focus
        const formControls = document.querySelectorAll('.form-control');
        formControls.forEach(control => {
            control.addEventListener('focus', function() {
                this.parentElement.classList.add('focused');
            });
            control.addEventListener('blur', function() {
                if (!this.value) {
                    this.parentElement.classList.remove('focused');
                }
            });
        });
    </script>
</body>
</html>