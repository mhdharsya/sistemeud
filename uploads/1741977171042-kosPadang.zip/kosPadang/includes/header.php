<?php
session_start();

// Function untuk mendapatkan base URL
function getBaseUrl() {
    $projectFolder = '/kosPadang'; 
    return $projectFolder;
}

// Function untuk membuat URL lengkap
function url($path) {
    return getBaseUrl() . $path;
}

// Redirect ke login jika belum login
if (!isset($_SESSION['user_id']) && basename($_SERVER['PHP_SELF']) !== 'index.php') {
    header("Location: " . url('/index.php'));
    exit;
}

// Get current page for active menu
$current_page = basename($_SERVER['PHP_SELF']);
$current_dir = basename(dirname($_SERVER['PHP_SELF']));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kos Padang</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?= url('/assets/css/style.css') ?>" rel="stylesheet">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="<?= url('/pages/dashboard.php') ?>">
                <i class="bi bi-house-door"></i> Sistem Pembayaran Kos Padang
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav" style="margin-left: 6%;">
                <?php if (isset($_SESSION['user_id'])): ?>
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link <?= $current_page === 'dashboard.php' ? 'active' : '' ?>" 
                        href="<?= url('/pages/dashboard.php') ?>">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle <?= $current_dir === 'penghuni' ? 'active' : '' ?>" 
                        href="#" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-people"></i> Penghuni
                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a class="dropdown-item" href="<?= url('/pages/penghuni/list.php') ?>">
                                    <i class="bi bi-list"></i> Data Penghuni
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="<?= url('/pages/penghuni/tambah.php') ?>">
                                    <i class="bi bi-plus-circle"></i> Tambah Penghuni
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle <?= $current_dir === 'operasional' ? 'active' : '' ?>" 
                        href="#" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-gear"></i> Operasional
                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a class="dropdown-item" href="<?= url('/pages/operasional/list.php') ?>">
                                    <i class="bi bi-list"></i> Data Pembayaran
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="<?= url('/pages/operasional/tambah.php') ?>">
                                    <i class="bi bi-plus-circle"></i> Tambah Pembayaran
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle <?= $current_dir === 'pembayaran' ? 'active' : '' ?>" 
                        href="#" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-cash-stack"></i> Pembayaran
                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a class="dropdown-item" href="<?= url('/pages/pembayaran/list.php') ?>">
                                    <i class="bi bi-list"></i> Data Pembayaran
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="<?= url('/pages/pembayaran/tambah.php') ?>">
                                    <i class="bi bi-plus-circle"></i> Tambah Pembayaran
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle <?= $current_dir === 'laporan' ? 'active' : '' ?>" 
                        href="#" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-file-earmark-text"></i> Laporan
                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a class="dropdown-item" href="<?= url('/pages/laporan/bulanan.php') ?>">
                                    <i class="bi bi-calendar-month"></i> Laporan Bulanan
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="<?= url('/pages/laporan/tahunan.php') ?>">
                                    <i class="bi bi-calendar-year"></i> Laporan Tahunan
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="<?= url('/pages/laporan/keuangan.php') ?>">
                                    <i class="bi bi-calendar-year"></i> Laporan Keuangan
                                </a>
                            </li>
                        </ul>
                    </li>
                    <!-- Tambahkan Dropdown Baru untuk Bagi Hasil -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle <?= $current_dir === 'bagi_hasil' ? 'active' : '' ?>" 
                        href="#" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-bar-chart"></i> Bagi Hasil
                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a class="dropdown-item" href="<?= url('/pages/bagi_hasil/list.php') ?>">
                                    <i class="bi bi-list"></i> Data Bagi Hasil
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="<?= url('/pages/bagi_hasil/tambah.php') ?>">
                                    <i class="bi bi-plus-circle"></i> Tambah Data
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle"></i> <?= htmlspecialchars($_SESSION['username']) ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <a class="dropdown-item" href="../logout.php" data-bs-toggle="modal" data-bs-target="#logoutModal">
                                    <i class="bi bi-box-arrow-right"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <?php endif; ?>
            </div>
        </div>
    </nav>


    <!-- Logout Modal -->
    <div class="modal fade" id="logoutModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Konfirmasi Logout</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Apakah Anda yakin ingin keluar dari sistem?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <a href="<?= url('/logout.php') ?>" class="btn btn-primary">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content Container -->
    <div class="container my-4">