<?php
// Konfigurasi database
$host = 'localhost';     // Hostname database
$dbname = 'kos_payment_system';   // Nama database
$username = 'root';      // Username database
$password = '';          // Password database (kosong untuk default XAMPP)

try {
    // Membuat koneksi PDO
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    
    // Set error mode ke exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Set default fetch mode ke associative array
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // Set emulate prepares ke false untuk keamanan yang lebih baik
    $conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

} catch(PDOException $e) {
    // Tampilkan pesan error jika koneksi gagal
    die("Koneksi database gagal: " . $e->getMessage());
}

// Function untuk sanitasi input
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Function untuk format tanggal ke format Indonesia
function format_tanggal_indo($tanggal) {
    $bulan = array (
        1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    );
    
    $pecahkan = explode('-', $tanggal);
    return $pecahkan[2] . ' ' . $bulan[(int)$pecahkan[1]] . ' ' . $pecahkan[0];
}

// Function untuk format angka ke format rupiah
function format_rupiah($angka) {
    return "Rp " . number_format($angka, 0, ',', '.');
}

// Function untuk cek status pembayaran bulan ini
function cek_status_pembayaran($conn, $id_penghuni, $bulan, $tahun) {
    $sql = "SELECT status_pembayaran FROM pembayaran 
            WHERE id_penghuni = ? AND bulan = ? AND tahun = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$id_penghuni, $bulan, $tahun]);
    $result = $stmt->fetch();
    
    return $result ? $result['status_pembayaran'] : 'Belum Bayar';
}

// Function untuk mendapatkan total pembayaran per bulan
function get_total_pembayaran_bulan($conn, $bulan, $tahun) {
    $sql = "SELECT SUM(jumlah_pembayaran) as total FROM pembayaran 
            WHERE bulan = ? AND tahun = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$bulan, $tahun]);
    $result = $stmt->fetch();
    
    return $result['total'] ?? 0;
}

// Function untuk mendapatkan total pembayaran per tahun
function get_total_pembayaran_tahun($conn, $tahun) {
    $sql = "SELECT SUM(jumlah_pembayaran) as total FROM pembayaran 
            WHERE tahun = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$tahun]);
    $result = $stmt->fetch();
    
    return $result['total'] ?? 0;
}

// Function untuk generate nomor kwitansi
function generate_nomor_kwitansi($conn) {
    $tahun = date('Y');
    $bulan = date('m');
    
    $sql = "SELECT COUNT(*) as total FROM pembayaran 
            WHERE YEAR(created_at) = ? AND MONTH(created_at) = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$tahun, $bulan]);
    $result = $stmt->fetch();
    
    $nomor = str_pad($result['total'] + 1, 4, '0', STR_PAD_LEFT);
    return "KWT-" . $tahun . $bulan . $nomor;
}

// Function untuk cek file adalah gambar yang valid
function is_valid_image($file) {
    $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];
    $max_size = 5 * 1024 * 1024; // 5MB
    
    if (!in_array($file['type'], $allowed_types)) {
        return false;
    }
    
    if ($file['size'] > $max_size) {
        return false;
    }
    
    return true;
}

// Function untuk upload file
function upload_file($file, $target_dir) {
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $file_name = uniqid() . '.' . $file_extension;
    $target_path = $target_dir . $file_name;
    
    if (move_uploaded_file($file['tmp_name'], $target_path)) {
        return $file_name;
    }
    
    return false;
}