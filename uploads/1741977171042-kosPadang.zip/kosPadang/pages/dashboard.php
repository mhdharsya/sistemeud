<?php
require_once '../config/database.php';
include '../includes/header.php';

/**
 * 1. Total Penghuni (hanya yang aktif)
 */
$sql_total_penghuni = "SELECT COUNT(*) AS total_penghuni 
                       FROM penghuni
                       WHERE status = 1";  // Hanya hitung yang aktif
$total_penghuni = $conn->query($sql_total_penghuni)->fetch()['total_penghuni'];

/**
 * 2. Total Kamar (hanya yang aktif, opsional)
 *    Jika ingin menghitung semua kamar termasuk yang sudah nonaktif, 
 *    hapus "WHERE status=1".
 */
$sql_total_kamar = "SELECT COUNT(DISTINCT nomor_kamar) AS total_kamar 
                    FROM penghuni
                    WHERE status = 1"; // Hanya kamar yang sedang ditempati penghuni aktif
$total_kamar = $conn->query($sql_total_kamar)->fetch()['total_kamar'];

/**
 * 3. Total pemasukan (SEMUA pembayaran).
 *    Tetap men-sum semua data di `pembayaran` (tak terikat status penghuni).
 *    Namun jika Anda mau hanya menghitung pembayaran milik penghuni aktif,
 *    bisa JOIN ke tabel penghuni dengan `ph.status=1`.
 */
$sql_total_masuk = "SELECT SUM(p.jumlah_pembayaran) AS total_masuk
                    FROM pembayaran p";
$result_masuk = $conn->query($sql_total_masuk)->fetch(PDO::FETCH_ASSOC);
$total_masuk = $result_masuk['total_masuk'] ?? 0;

/**
 * 4. Total pengeluaran (operasional).
 */
$sql_total_keluar = "SELECT SUM(po.nominal) AS total_keluar
                     FROM pembayaran_operasional po";
$result_keluar = $conn->query($sql_total_keluar)->fetch(PDO::FETCH_ASSOC);
$total_keluar = $result_keluar['total_keluar'] ?? 0;

/**
 * 5. Saldo (pendapatan bersih) = total masuk - total keluar.
 */
$saldo = $total_masuk - $total_keluar;

/**
 * 6. Daftar penghuni aktif (status=1).
 */
$sql_penghuni_aktif = "
    SELECT nomor_kamar, nama_penghuni, tanggal_masuk, biaya_bulanan
    FROM penghuni
    WHERE status = 1  -- hanya tampilkan yang aktif
    ORDER BY nomor_kamar
";
$penghuni_aktif = $conn->query($sql_penghuni_aktif)->fetchAll(PDO::FETCH_ASSOC);

/**
 * 7. Pembayaran terakhir (5 transaksi terbaru).
 *    Secara default, menampilkan semua pembayaran (termasuk dari penghuni nonaktif).
 *    Jika Anda ingin hanya dari penghuni aktif, 
 *    tambahkan "AND ph.status=1" di bagian JOIN.
 */
$sql_recent_payments = "
    SELECT 
        p.tanggal_pembayaran, 
        p.jumlah_pembayaran, 
        ph.nomor_kamar, 
        ph.nama_penghuni
    FROM pembayaran p
    JOIN penghuni ph ON p.id_penghuni = ph.id_penghuni
    ORDER BY p.tanggal_pembayaran DESC
    LIMIT 5
";
$recent_payments = $conn->query($sql_recent_payments)->fetchAll(PDO::FETCH_ASSOC);

/**
 * 8. Data untuk Grafik Pendapatan per Bulan (tahun berjalan).
 */
$current_year = date('Y');
$sql_pendapatan_per_bulan = "
    SELECT 
        MONTH(tanggal_pembayaran) AS bulan,
        SUM(jumlah_pembayaran) AS total_pendapatan
    FROM pembayaran
    WHERE YEAR(tanggal_pembayaran) = ?
    GROUP BY MONTH(tanggal_pembayaran)
    ORDER BY MONTH(tanggal_pembayaran)
";
$stmt_pendapatan = $conn->prepare($sql_pendapatan_per_bulan);
$stmt_pendapatan->execute([$current_year]);
$pendapatan_per_bulan = $stmt_pendapatan->fetchAll(PDO::FETCH_ASSOC);

$bulan_labels = [
    'Januari','Februari','Maret','April','Mei','Juni',
    'Juli','Agustus','September','Oktober','November','Desember'
];
$pendapatan_data = array_fill(0, 12, 0);

foreach ($pendapatan_per_bulan as $data) {
    $index_bulan = $data['bulan'] - 1;
    $pendapatan_data[$index_bulan] = $data['total_pendapatan'];
}
?>

<div class="container mt-4">
    <!-- Statistik Umum -->
    <div class="row mb-3">
        <!-- Kartu: Total Penghuni Aktif -->
        <div class="col-md-4">
            <div class="card shadow-sm border-0 bg-primary text-white">
                <a href="../pages/penghuni/list.php" style="text-decoration: none; color: white;">
                    <div class="card-body text-center py-3">
                        <i class="bi bi-people-fill fs-3"></i>
                        <h6 class="card-title mt-2">Total Penghuni Aktif</h6>
                        <h4 class="fw-bold mb-0"><?= $total_penghuni ?></h4>
                    </div>
                </a>
            </div>
        </div>
        
        <!-- Kartu: Total Kamar (ditempati oleh penghuni aktif) -->
        <div class="col-md-4">
            <div class="card shadow-sm border-0 bg-success text-white">
                <div class="card-body text-center py-3">
                    <i class="bi bi-door-closed-fill fs-3"></i>
                    <h6 class="card-title mt-2">Total Kamar (Aktif)</h6>
                    <h4 class="fw-bold mb-0"><?= $total_kamar ?></h4>
                </div>
            </div>
        </div>
        
        <!-- Kartu: Saldo (Pendapatan Bersih) -->
        <div class="col-md-4">
            <div class="card shadow-sm border-0 bg-info text-white">
                <div class="card-body text-center py-3">
                    <i class="bi bi-cash-stack fs-3"></i>
                    <h6 class="card-title mt-2">Total Pendapatan (Bersih)</h6>
                    <h4 class="fw-bold mb-0">
                        Rp <?= number_format($saldo, 0, ',', '.') ?>
                    </h4>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabel Pembayaran Terakhir -->
    <div class="card shadow-sm mb-3">
        <div class="card-header bg-dark text-white py-2">
            <a href="../pages/pembayaran/list.php" style="text-decoration: none; color: white;">
                <h6 class="card-title mb-0">Pembayaran Terakhir</h6>
            </a>
        </div>
        <div class="card-body p-3">
            <?php if (empty($recent_payments)): ?>
                <p class="text-center text-muted">Tidak ada pembayaran terakhir.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover table-sm align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th style="color: black;">Tanggal Pembayaran</th>
                                <th style="color: black;">Nomor Kamar</th>
                                <th style="color: black;">Nama Penghuni</th>
                                <th style="color: black;">Jumlah Pembayaran</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_payments as $payment): ?>
                                <tr>
                                    <td><?= date('d/m/Y', strtotime($payment['tanggal_pembayaran'])) ?></td>
                                    <td><?= htmlspecialchars($payment['nomor_kamar']) ?></td>
                                    <td><?= htmlspecialchars($payment['nama_penghuni']) ?></td>
                                    <td>Rp <?= number_format($payment['jumlah_pembayaran'], 0, ',', '.') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Tabel Daftar Penghuni Aktif -->
    <div class="card shadow-sm mb-3">
        <div class="card-header bg-secondary text-white py-2">
            <h6 class="card-title mb-0">Daftar Penghuni Aktif</h6>
        </div>
        <div class="card-body p-3">
            <?php if (empty($penghuni_aktif)): ?>
                <p class="text-center text-muted">Tidak ada penghuni aktif.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped table-sm align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th style="color: black;">Nomor Kamar</th>
                                <th style="color: black;">Nama Penghuni</th>
                                <th style="color: black;">Tanggal Masuk</th>
                                <th style="color: black;">Biaya Bulanan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($penghuni_aktif as $penghuni): ?>
                                <tr>
                                    <td><?= htmlspecialchars($penghuni['nomor_kamar']) ?></td>
                                    <td><?= htmlspecialchars($penghuni['nama_penghuni']) ?></td>
                                    <td><?= date('d/m/Y', strtotime($penghuni['tanggal_masuk'])) ?></td>
                                    <td>Rp <?= number_format($penghuni['biaya_bulanan'], 0, ',', '.') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Grafik Pendapatan Per Bulan -->
    <div class="card shadow-sm mb-3">
        <div class="card-header bg-primary text-white py-2">
            <h6 class="card-title mb-0">Grafik Pendapatan Per Bulan (<?= $current_year ?>)</h6>
        </div>
        <div class="card-body p-3">
            <canvas id="chartPendapatan" style="height: 250px;"></canvas>
        </div>
    </div>
</div>

<!-- Script untuk Chart.js dan ikon Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('chartPendapatan').getContext('2d');
    const chartPendapatan = new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?= json_encode($bulan_labels) ?>,
            datasets: [{
                label: 'Pendapatan (Rp)',
                data: <?= json_encode($pendapatan_data) ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1.5,
                tension: 0.4,
                pointBackgroundColor: 'rgba(54, 162, 235, 1)'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
</script>

<?php include '../includes/footer.php'; ?>
