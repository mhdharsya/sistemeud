<?php
require_once '../../config/database.php';
ob_start(); // Memulai output buffering untuk menghindari output sebelum header
include '../../includes/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $id_penghuni = $_POST['id_penghuni'];
        $bulan = $_POST['bulan'];
        $tahun = $_POST['tahun'];
        $tanggal_pembayaran = $_POST['tanggal_pembayaran'];
        $jumlah_pembayaran = $_POST['jumlah_pembayaran'];
        $status_pembayaran = $_POST['status_pembayaran'];
        $keterangan = $_POST['keterangan'];

        // Handle file upload
        $bukti_pembayaran = '';
        if (isset($_FILES['bukti_pembayaran']) && $_FILES['bukti_pembayaran']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../../assets/uploads/bukti_pembayaran/';
            $file_extension = pathinfo($_FILES['bukti_pembayaran']['name'], PATHINFO_EXTENSION);
            $file_name = uniqid() . '.' . $file_extension;
            $upload_path = $upload_dir . $file_name;

            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            if (move_uploaded_file($_FILES['bukti_pembayaran']['tmp_name'], $upload_path)) {
                $bukti_pembayaran = $file_name;
            }
        }

        // Check if payment for this month and year already exists
        $check_sql = "SELECT COUNT(*) FROM pembayaran 
                     WHERE id_penghuni = ? AND bulan = ? AND tahun = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->execute([$id_penghuni, $bulan, $tahun]);
        $payment_exists = $check_stmt->fetchColumn() > 0;

        if ($payment_exists) {
            throw new Exception("Pembayaran untuk bulan $bulan tahun $tahun sudah ada!");
        }

        $sql = "INSERT INTO pembayaran (id_penghuni, bulan, tahun, tanggal_pembayaran, 
                jumlah_pembayaran, bukti_pembayaran, status_pembayaran, keterangan) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            $id_penghuni,
            $bulan,
            $tahun,
            $tanggal_pembayaran,
            $jumlah_pembayaran,
            $bukti_pembayaran,
            $status_pembayaran,
            $keterangan
        ]);

        // Redirect ke halaman pembayaran/list.php dengan pesan sukses
        header('Location: list.php?status=success&message=Pembayaran berhasil ditambahkan');
        exit();
    } catch(Exception $e) {
        $error_message = $e->getMessage();
    }
}

// Get list of penghuni for dropdown
$stmt = $conn->query("SELECT id_penghuni, nomor_kamar, nama_penghuni, biaya_bulanan 
                      FROM penghuni 
                      WHERE status = 1 
                      ORDER BY nomor_kamar");
$penghuni_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<div class="card">
    <div class="card-header">
        <h5 class="card-title">Tambah Pembayaran Baru</h5>
    </div>
    <div class="card-body">
        <?php if (isset($error_message)): ?>
            <script>
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal!',
                    text: '<?= htmlspecialchars($error_message) ?>',
                    confirmButtonText: 'OK'
                });
            </script>
        <?php endif; ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="id_penghuni" class="form-label">Penghuni</label>
                <select class="form-select" name="id_penghuni" id="id_penghuni" required>
                    <option value="">Pilih Penghuni</option>
                    <?php foreach ($penghuni_list as $penghuni): ?>
                        <option value="<?= $penghuni['id_penghuni'] ?>" 
                                data-biaya="<?= $penghuni['biaya_bulanan'] ?>">
                            Kamar <?= htmlspecialchars($penghuni['nomor_kamar']) ?> - 
                            <?= htmlspecialchars($penghuni['nama_penghuni']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="bulan" class="form-label">Bulan</label>
                        <select class="form-select" name="bulan" required>
                            <?php
                            $bulan = [
                                'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
                                'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
                            ];
                            foreach ($bulan as $b): ?>
                                <option value="<?= $b ?>" <?= date('F') === $b ? 'selected' : '' ?> >
                                    <?= $b ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="tahun" class="form-label">Tahun</label>
                        <select class="form-select" name="tahun" required>
                            <?php
                            $tahun_sekarang = date('Y');
                            for ($tahun = $tahun_sekarang - 1; $tahun <= $tahun_sekarang + 2; $tahun++): ?>
                                <option value="<?= $tahun ?>" <?= $tahun_sekarang === $tahun ? 'selected' : '' ?>>
                                    <?= $tahun ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="mb-3">
                <label for="tanggal_pembayaran" class="form-label">Tanggal Pembayaran</label>
                <input type="date" class="form-control" name="tanggal_pembayaran" 
                       value="<?= date('Y-m-d') ?>" required>
            </div>

            <div class="mb-3">
                <label for="jumlah_pembayaran" class="form-label">Jumlah Pembayaran</label>
                <input type="number" class="form-control" name="jumlah_pembayaran" 
                       id="jumlah_pembayaran" required>
            </div>

            <div class="mb-3">
                <label for="status_pembayaran" class="form-label">Status Pembayaran</label>
                <select class="form-select" name="status_pembayaran" required>
                    <option value="Lunas">Lunas</option>
                    <option value="Belum Lunas">Belum Lunas</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="bukti_pembayaran" class="form-label">Bukti Pembayaran</label>
                <input type="file" class="form-control" name="bukti_pembayaran" 
                       accept="image/*">
                <small class="text-muted">Upload gambar bukti pembayaran (JPG, PNG)</small>
            </div>

            <div class="mb-3">
                <label for="keterangan" class="form-label">Keterangan (opsional)</label>
                <textarea class="form-control" name="keterangan" rows="3"></textarea>
            </div>

            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-primary">Simpan Pembayaran</button>
                <a href="list.php" class="btn btn-secondary">Kembali</a>
            </div>
        </form>
    </div>
</div>

<script>
document.getElementById('id_penghuni').addEventListener('change', function() {
    const selectedOption = this.options[this.selectedIndex];
    const biaya = selectedOption.getAttribute('data-biaya');
    document.getElementById('jumlah_pembayaran').value = biaya || '';
});
</script>

<?php include '../../includes/footer.php'; ?>
