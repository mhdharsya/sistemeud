<?php
require_once '../../config/database.php';
include '../../includes/header.php';

// Ambil ID Pembayaran
$id_pembayaran = isset($_GET['id']) ? $_GET['id'] : null;

if (!$id_pembayaran) {
    echo "ID tidak ditemukan.";
    exit;
}

// Ambil data pembayaran
$sql = "SELECT * FROM pembayaran WHERE id_pembayaran = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$id_pembayaran]);
$pembayaran = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$pembayaran) {
    echo "Data pembayaran tidak ditemukan.";
    exit;
}

// Update data pembayaran
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bulan = $_POST['bulan'];
    $tahun = $_POST['tahun'];
    $tanggal_bayar = $_POST['tanggal_bayar'];
    $jumlah_pembayaran = $_POST['jumlah_pembayaran'];
    $status_pembayaran = $_POST['status_pembayaran'];

    $sql_update = "UPDATE pembayaran 
                   SET bulan = ?, tahun = ?, tanggal_pembayaran = ?, jumlah_pembayaran = ?, status_pembayaran = ? 
                   WHERE id_pembayaran = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->execute([$bulan, $tahun, $tanggal_bayar, $jumlah_pembayaran, $status_pembayaran, $id_pembayaran]);

    echo "<script>alert('Data berhasil diperbarui!'); window.location='list.php';</script>";
    exit;
}
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title">Edit Pembayaran</h5>
    </div>
    <div class="card-body">
        <form action="" method="POST">
            <!-- Bulan -->
            <div class="mb-3">
                <label for="bulan" class="form-label">Bulan</label>
                <select name="bulan" id="bulan" class="form-select" required>
                    <?php
                    $bulan_list = [
                        'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
                        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
                    ];
                    foreach ($bulan_list as $b): ?>
                        <option value="<?= $b ?>" <?= $pembayaran['bulan'] === $b ? 'selected' : '' ?>>
                            <?= $b ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Tahun -->
            <div class="mb-3">
                <label for="tahun" class="form-label">Tahun</label>
                <input type="number" name="tahun" id="tahun" 
                       class="form-control" 
                       value="<?= htmlspecialchars($pembayaran['tahun']) ?>" required>
            </div>

            <!-- Tanggal Bayar -->
            <div class="mb-3">
                <label for="tanggal_bayar" class="form-label">Tanggal Bayar</label>
                <input type="date" name="tanggal_bayar" id="tanggal_bayar" 
                       class="form-control" 
                       value="<?= htmlspecialchars($pembayaran['tanggal_pembayaran']) ?>" required>
            </div>

            <!-- Jumlah Pembayaran -->
            <div class="mb-3">
                <label for="jumlah_pembayaran" class="form-label">Jumlah Pembayaran</label>
                <input type="number" name="jumlah_pembayaran" id="jumlah_pembayaran" 
                       class="form-control" 
                       value="<?= htmlspecialchars($pembayaran['jumlah_pembayaran']) ?>" required>
            </div>

            <!-- Status Pembayaran -->
            <div class="mb-3">
                <label for="status_pembayaran" class="form-label">Status Pembayaran</label>
                <select name="status_pembayaran" id="status_pembayaran" class="form-select" required>
                    <option value="Lunas" <?= $pembayaran['status_pembayaran'] === 'Lunas' ? 'selected' : '' ?>>Lunas</option>
                    <option value="Belum Lunas" <?= $pembayaran['status_pembayaran'] === 'Belum Lunas' ? 'selected' : '' ?>>Belum Lunas</option>
                </select>
            </div>

            <!-- Tombol -->
            <button type="submit" class="btn btn-success">Simpan Perubahan</button>
            <a href="list.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
