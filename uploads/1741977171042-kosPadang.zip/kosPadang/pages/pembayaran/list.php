<?php
require_once '../../config/database.php';
include '../../includes/header.php';

// Filter parameters
$bulan = isset($_GET['bulan']) ? $_GET['bulan'] : date('F');
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');
$status = isset($_GET['status']) ? $_GET['status'] : '';
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Build query
$sql = "SELECT p.*, ph.nomor_kamar, ph.nama_penghuni 
        FROM pembayaran p
        JOIN penghuni ph ON p.id_penghuni = ph.id_penghuni
        WHERE 1=1";

$params = [];

if ($bulan) {
    $sql .= " AND p.bulan = ?";
    $params[] = $bulan;
}

if ($tahun) {
    $sql .= " AND p.tahun = ?";
    $params[] = $tahun;
}

if ($status) {
    $sql .= " AND p.status_pembayaran = ?";
    $params[] = $status;
}

if ($search) {
    $sql .= " AND (ph.nomor_kamar LIKE ? OR ph.nama_penghuni LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$sql .= " ORDER BY p.tanggal_pembayaran DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$pembayaran_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="card">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Daftar Pembayaran</h5>
            <a href="tambah.php" class="btn btn-primary">Tambah Pembayaran</a>
        </div>
    </div>
    <div class="card-body">
        <!-- Filter Form -->
        <form action="" method="GET" class="mb-4">
            <div class="row g-3">
                <div class="col-md-2">
                    <select name="bulan" class="form-select">
                        <option value="">Semua Bulan</option>
                        <?php
                        $bulan_list = [
                            'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
                            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
                        ];
                        foreach ($bulan_list as $b): ?>
                            <option value="<?= $b ?>" <?= $bulan === $b ? 'selected' : '' ?>>
                                <?= $b ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="tahun" class="form-select">
                        <option value="">Semua Tahun</option>
                        <?php
                        $tahun_sekarang = date('Y');
                        for ($t = $tahun_sekarang - 1; $t <= $tahun_sekarang + 1; $t++): ?>
                            <option value="<?= $t ?>" <?= $tahun == $t ? 'selected' : '' ?>>
                                <?= $t ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="status" class="form-select">
                        <option value="">Semua Status</option>
                        <option value="Lunas" <?= $status === 'Lunas' ? 'selected' : '' ?>>Lunas</option>
                        <option value="Belum Lunas" <?= $status === 'Belum Lunas' ? 'selected' : '' ?>>Belum Lunas</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <input type="text" name="search" class="form-control" 
                           placeholder="Cari nomor kamar atau nama penghuni..." 
                           value="<?= htmlspecialchars($search) ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">Filter</button>
                </div>
            </div>
        </form>

        <!-- Payment List Table -->
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>No. Kamar</th>
                        <th>Nama Penghuni</th>
                        <th>Bulan/Tahun</th>
                        <th>Tanggal Bayar</th>
                        <th>Jumlah</th>
                        <th>Status</th>
                        <th>Bukti</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($pembayaran_list)): ?>
                        <tr>
                            <td colspan="8" class="text-center">Tidak ada data pembayaran</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($pembayaran_list as $pembayaran): ?>
                            <tr>
                                <td><?= htmlspecialchars($pembayaran['nomor_kamar']) ?></td>
                                <td><?= htmlspecialchars($pembayaran['nama_penghuni']) ?></td>
                                <td><?= $pembayaran['bulan'] ?> <?= $pembayaran['tahun'] ?></td>
                                <td><?= date('d/m/Y', strtotime($pembayaran['tanggal_pembayaran'])) ?></td>
                                <td>Rp <?= number_format($pembayaran['jumlah_pembayaran'], 0, ',', '.') ?></td>
                                <td>
                                    <span class="badge bg-<?= $pembayaran['status_pembayaran'] === 'Lunas' ? 'success' : 'warning' ?>">
                                        <?= $pembayaran['status_pembayaran'] ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="#" class="btn btn-sm btn-info" data-bs-toggle="modal" 
                                       data-bs-target="#buktiModal<?= $pembayaran['id_pembayaran'] ?>">
                                        Lihat Bukti
                                    </a>
                                </td>
                                <td>
                                    <a href="detail.php?id=<?= $pembayaran['id_pembayaran'] ?>" 
                                       class="btn btn-sm btn-primary">
                                        Detail
                                    </a>
                                    <a href="edit.php?id=<?= $pembayaran['id_pembayaran'] ?>" 
                                    class="btn btn-sm btn-warning">
                                        Edit
                                    </a>
                                </td>
                            </tr>

                            <!-- Modal Bukti Pembayaran -->
                            <div class="modal fade" id="buktiModal<?= $pembayaran['id_pembayaran'] ?>" tabindex="-1">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Bukti Pembayaran</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <img src="../../assets/uploads/bukti_pembayaran/<?= $pembayaran['bukti_pembayaran'] ?>" 
                                                 class="img-fluid" alt="Bukti Pembayaran">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>