<?php
require_once '../../config/database.php';
include '../../includes/header.php';

$id_pembayaran = isset($_GET['id']) ? $_GET['id'] : 0;

// Get payment detail
$sql = "SELECT p.*, ph.nomor_kamar, ph.nama_penghuni, ph.biaya_bulanan
        FROM pembayaran p
        JOIN penghuni ph ON p.id_penghuni = ph.id_penghuni
        WHERE p.id_pembayaran = ?";

$stmt = $conn->prepare($sql);
$stmt->execute([$id_pembayaran]);
$pembayaran = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$pembayaran) {
    echo "<div class='alert alert-danger'>Data pembayaran tidak ditemukan</div>";
    exit;
}

// Proses update status pembayaran
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $new_status = $_POST['status_pembayaran'];
    $sql_update = "UPDATE pembayaran SET status_pembayaran = ? WHERE id_pembayaran = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->execute([$new_status, $id_pembayaran]);

    // Refresh data
    $stmt->execute([$id_pembayaran]);
    $pembayaran = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<div class="card">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Detail Pembayaran</h5>
            <div>
                <button onclick="window.print()" class="btn btn-secondary me-2">
                    <i class="bi bi-printer"></i> Print
                </button>
                <a href="list.php" class="btn btn-primary">
                    <i class="bi bi-arrow-left"></i> Kembali
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <div class="card mb-3">
                    <div class="card-body">
                        <h6 class="card-subtitle mb-3 text-muted">Informasi Penghuni</h6>
                        <table class="table table-borderless">
                            <tr>
                                <td width="40%">No. Kamar</td>
                                <td>: <?= htmlspecialchars($pembayaran['nomor_kamar']) ?></td>
                            </tr>
                            <tr>
                                <td>Nama Penghuni</td>
                                <td>: <?= htmlspecialchars($pembayaran['nama_penghuni']) ?></td>
                            </tr>
                            <tr>
                                <td>Periode</td>
                                <td>: <?= $pembayaran['bulan'] ?> <?= $pembayaran['tahun'] ?></td>
                            </tr>
                            <tr>
                                <td>Biaya Bulanan</td>
                                <td>: Rp <?= number_format($pembayaran['biaya_bulanan'], 0, ',', '.') ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card mb-3">
                    <div class="card-body">
                        <h6 class="card-subtitle mb-3 text-muted">Detail Pembayaran</h6>
                        <table class="table table-borderless">
                            <tr>
                                <td width="40%">Tanggal Bayar</td>
                                <td>: <?= date('d/m/Y', strtotime($pembayaran['tanggal_pembayaran'])) ?></td>
                            </tr>
                            <tr>
                                <td>Jumlah Bayar</td>
                                <td>: Rp <?= number_format($pembayaran['jumlah_pembayaran'], 0, ',', '.') ?></td>
                            </tr>
                            <tr>
                                <td>Status</td>
                                <td>
                                    <form method="POST" class="d-inline" id="updateStatusForm">
                                        <select name="status_pembayaran" class="form-select form-select-sm d-inline-block w-auto" 
                                                onchange="document.getElementById('updateStatusForm').submit();">
                                            <option value="Lunas" <?= $pembayaran['status_pembayaran'] === 'Lunas' ? 'selected' : '' ?>>
                                                Lunas
                                            </option>
                                            <option value="Belum Lunas" <?= $pembayaran['status_pembayaran'] === 'Belum Lunas' ? 'selected' : '' ?>>
                                                Belum Lunas
                                            </option>
                                        </select>
                                        <input type="hidden" name="update_status" value="1">
                                    </form>
                                </td>
                            </tr>
                            <?php if ($pembayaran['status_pembayaran'] === 'Belum Lunas'): ?>
                            <tr>
                                <td>Kekurangan</td>
                                <td>: Rp <?= number_format($pembayaran['biaya_bulanan'] - $pembayaran['jumlah_pembayaran'], 0, ',', '.') ?></td>
                            </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Keterangan -->
        <?php if ($pembayaran['keterangan']): ?>
        <div class="card mb-3">
            <div class="card-body">
                <h6 class="card-subtitle mb-3 text-muted">Keterangan</h6>
                <p class="mb-0"><?= nl2br(htmlspecialchars($pembayaran['keterangan'])) ?></p>
            </div>
        </div>
        <?php endif; ?>

        <!-- Bukti Pembayaran -->
        <div class="card">
            <div class="card-body">
                <h6 class="card-subtitle mb-3 text-muted">Bukti Pembayaran</h6>
                <div class="text-center">
                    <img src="../../assets/uploads/bukti_pembayaran/<?= $pembayaran['bukti_pembayaran'] ?>" 
                         class="img-fluid" style="max-height: 500px;" alt="Tidak ada bukti pembayaran">
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Print Styles -->
<style media="print">
    .no-print {
        display: none !important;
    }
    
    .card {
        border: none !important;
        box-shadow: none !important;
    }
    
    .card-body {
        padding: 0 !important;
    }
    
    select.form-select {
        border: none;
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        padding: 0;
        background: none;
    }
    
    img {
        max-width: 100% !important;
        height: auto !important;
    }
</style>

<?php include '../../includes/footer.php'; ?>