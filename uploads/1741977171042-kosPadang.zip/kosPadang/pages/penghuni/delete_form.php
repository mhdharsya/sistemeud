<?php
// delete_form.php
require_once '../../config/database.php';
include '../../includes/header.php';

// Pastikan parameter ?id_penghuni=... ada
if (!isset($_GET['id_penghuni'])) {
    echo "<p>ID Penghuni tidak ditemukan.</p>";
    exit;
}

$id_penghuni = $_GET['id_penghuni'];

// Ambil data penghuni by id
$sql = "SELECT * FROM penghuni WHERE id_penghuni = :id LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id_penghuni]);
$penghuni = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$penghuni) {
    echo "<p>Data penghuni tidak valid atau tidak ditemukan.</p>";
    exit;
}

// Jika statusnya sudah 0, berarti sudah nonaktif
if ($penghuni['status'] == 0) {
    echo "<p>Penghuni ini sudah nonaktif.</p>";
    exit;
}
?>

<div class="container mt-5">
    <h2>Form Soft Delete (Set Tanggal Keluar)</h2>
    <div class="mt-4">
        <p><strong>No. Kamar:</strong> <?= htmlspecialchars($penghuni['nomor_kamar']) ?></p>
        <p><strong>Nama Penghuni:</strong> <?= htmlspecialchars($penghuni['nama_penghuni']) ?></p>
        <p><strong>Tanggal Masuk:</strong> <?= htmlspecialchars($penghuni['tanggal_masuk']) ?></p>
        <p><strong>Biaya Bulanan:</strong> 
            Rp <?= number_format($penghuni['biaya_bulanan'], 0, ',', '.') ?>
        </p>
    </div>

    <form action="delete.php" method="POST" class="mt-4">
        <div class="mb-3">
            <label for="tanggal_keluar" class="form-label">Tanggal Keluar</label>
            <input type="date" name="tanggal_keluar" id="tanggal_keluar" 
                   class="form-control" required>
        </div>
        
        <!-- Hidden: ID Penghuni -->
        <input type="hidden" name="id_penghuni" value="<?= $penghuni['id_penghuni'] ?>">

        <button type="submit" class="btn btn-danger">
            Nonaktifkan Penghuni
        </button>
        <a href="list.php" class="btn btn-secondary">
            Batal
        </a>
    </form>
</div>

<?php include '../../includes/footer.php'; ?>
