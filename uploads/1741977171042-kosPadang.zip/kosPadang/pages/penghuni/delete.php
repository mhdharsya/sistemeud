<?php
// delete.php
require_once '../../config/database.php';
include '../../includes/header.php';

if (isset($_POST['id_penghuni']) && isset($_POST['tanggal_keluar'])) {
    $id = $_POST['id_penghuni'];
    $tgl_keluar = $_POST['tanggal_keluar']; // format YYYY-mm-dd

    try {
        $conn->beginTransaction();
        
        $sql = "
            UPDATE penghuni
            SET status = 0,
                tanggal_keluar = :tgl_keluar
            WHERE id_penghuni = :id
        ";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':tgl_keluar', $tgl_keluar);
        $stmt->bindParam(':id', $id);

        if ($stmt->execute()) {
            $conn->commit();
            $status = 'success';
            $message = 'Penghuni berhasil di-nonaktifkan (soft delete) dengan tanggal keluar.';
        } else {
            throw new Exception("Gagal mengupdate data.");
        }

    } catch (Exception $e) {
        $conn->rollBack();
        $status = 'error';
        $message = $e->getMessage();
    }
} else {
    $status = 'error';
    $message = 'ID Penghuni atau Tanggal Keluar tidak valid.';
}
?>

<!-- SweetAlert (opsional) -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    <?php if (isset($status) && $status === 'success'): ?>
        Swal.fire({
            icon: 'success',
            title: 'Berhasil!',
            text: '<?= $message ?>',
            confirmButtonText: 'OK',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'list.php'; 
            }
        });
    <?php elseif (isset($status) && $status === 'error'): ?>
        Swal.fire({
            icon: 'error',
            title: 'Gagal!',
            text: '<?= $message ?>',
            confirmButtonText: 'OK',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'list.php'; 
            }
        });
    <?php else: ?>
        window.location.href = 'list.php';
    <?php endif; ?>
});
</script>
