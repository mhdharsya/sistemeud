<?php
// list.php
require_once '../../config/database.php';
include '../../includes/header.php';

// Query: menampilkan semua penghuni berstatus aktif (status=1) 
// (Silakan sesuaikan jika Anda ingin menampilkan semua)
$sql = "SELECT * FROM penghuni WHERE status = 1 ORDER BY id_penghuni ASC";
$stmt = $conn->prepare($sql);
$stmt->execute();
$penghuni_aktif = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Tangani notifikasi jika ada, misal: ?status=success&message=...
$status = isset($_GET['status']) ? $_GET['status'] : null;
$message = isset($_GET['message']) ? $_GET['message'] : null;
?>

<div class="container mt-5">
<div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="mb-0">Daftar Penghuni Aktif</h2>
        <a href="tambah.php" class="btn btn-primary">
            <i class="bi bi-plus"></i> Tambah Penghuni
        </a>
    </div>

    <!-- Notifikasi dari query string, jika ada -->
    <?php if ($status && $message): ?>
        <div class="alert alert-<?= $status === 'success' ? 'success' : 'danger' ?>" role="alert">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <!-- Tabel -->
    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>No. Kamar</th>
                    <th>Nama Penghuni</th>
                    <th>Tanggal Masuk</th>
                    <th>Biaya Bulanan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php if (count($penghuni_aktif) > 0): ?>
                <?php foreach ($penghuni_aktif as $penghuni): ?>
                <tr>
                    <td><?= htmlspecialchars($penghuni['nomor_kamar']) ?></td>
                    <td><?= htmlspecialchars($penghuni['nama_penghuni']) ?></td>
                    <td><?= htmlspecialchars($penghuni['tanggal_masuk']) ?></td>
                    <td>Rp <?= number_format($penghuni['biaya_bulanan'], 0, ',', '.') ?></td>
                    <td>
                        <!-- Tombol Edit 
                             Link menuju edit.php?id=... agar cocok dengan $_GET['id'] di edit.php -->
                        <a href="edit.php?id=<?= $penghuni['id_penghuni'] ?>"
                           class="btn btn-warning btn-sm">
                            <i class="bi bi-pencil"></i> Edit
                        </a>

                        <!-- Tombol Hapus (Soft Delete)
                             Link ke delete_form.php?id_penghuni=... 
                             (sesuai script hapus Anda) -->
                        <a href="delete_form.php?id_penghuni=<?= $penghuni['id_penghuni'] ?>"
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Yakin ingin menghapus (soft delete)?');">
                            <i class="bi bi-trash"></i> Hapus
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" class="text-center">
                        Belum ada data penghuni.
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
