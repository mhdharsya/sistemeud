<?php
ob_start(); // Mulai output buffering
require_once '../../config/database.php';
include '../../includes/header.php';

$status = null;
$message = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $nomor_kamar = $_POST['nomor_kamar'];
        $nama_penghuni = $_POST['nama_penghuni'];
        $tanggal_masuk = $_POST['tanggal_masuk'];
        $biaya_bulanan = $_POST['biaya_bulanan'];

        // Cek apakah nomor kamar sudah ada
        $check_sql = "SELECT COUNT(*) FROM penghuni WHERE nomor_kamar = ? AND status = 1";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->execute([$nomor_kamar]);
        if ($check_stmt->fetchColumn() > 0) {
            throw new Exception("Nomor kamar sudah digunakan!");
        }

        // Insert data (status=1 untuk penghuni aktif)
        $sql = "INSERT INTO penghuni (nomor_kamar, nama_penghuni, tanggal_masuk, biaya_bulanan, status)
                VALUES (?, ?, ?, ?, 1)";
        
        $stmt = $conn->prepare($sql);
        $stmt->execute([$nomor_kamar, $nama_penghuni, $tanggal_masuk, $biaya_bulanan]);

        $status = 'success';
        $message = 'Data penghuni berhasil ditambahkan!';
    } catch (Exception $e) {
        $status = 'error';
        $message = $e->getMessage();
    }
}
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">Tambah Penghuni Baru</h5>
    </div>
    <div class="card-body">
        <form action="" method="POST" class="needs-validation" novalidate>
            <div class="mb-3">
                <label for="nomor_kamar" class="form-label">Nomor Kamar</label>
                <input type="text" class="form-control" name="nomor_kamar" required>
                <div class="invalid-feedback">
                    Harap masukkan nomor kamar
                </div>
            </div>

            <div class="mb-3">
                <label for="nama_penghuni" class="form-label">Nama Penghuni</label>
                <input type="text" class="form-control" name="nama_penghuni" required>
                <div class="invalid-feedback">
                    Harap masukkan nama penghuni
                </div>
            </div>

            <div class="mb-3">
                <label for="tanggal_masuk" class="form-label">Tanggal Masuk</label>
                <input type="date" class="form-control" name="tanggal_masuk" 
                       value="<?= date('Y-m-d') ?>" required>
                <div class="invalid-feedback">
                    Harap pilih tanggal masuk
                </div>
            </div>

            <div class="mb-3">
                <label for="biaya_bulanan" class="form-label">Biaya Bulanan</label>
                <input type="number" class="form-control" name="biaya_bulanan" required>
                <div class="invalid-feedback">
                    Harap masukkan biaya bulanan
                </div>
            </div>

            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="list.php" class="btn btn-secondary">Kembali</a>
            </div>
        </form>
    </div>
</div>

<!-- Tambahkan SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    // Form validation
    (function () {
        'use strict';
        var forms = document.querySelectorAll('.needs-validation');
        Array.prototype.slice.call(forms)
            .forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
    })();

    // SweetAlert Notifikasi
    <?php if ($status === 'success'): ?>
        Swal.fire({
            icon: 'success',
            title: 'Berhasil!',
            text: '<?= $message ?>',
            confirmButtonText: 'OK',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'list.php'; // Redirect ke halaman list
            }
        });
    <?php elseif ($status === 'error'): ?>
        Swal.fire({
            icon: 'error',
            title: 'Gagal!',
            text: '<?= $message ?>',
            confirmButtonText: 'Coba Lagi',
        });
    <?php endif; ?>
</script>

<?php 
include '../../includes/footer.php'; 
ob_end_flush(); // Hentikan output buffering dan kirim output
?>
