<?php
require_once '../../config/database.php';
require '../../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Alignment;

// Ambil parameter dari URL
$type = $_GET['type'] ?? 'bulanan';
$bulan = $_GET['bulan'] ?? date('F');
$tahun = $_GET['tahun'] ?? date('Y');

// Apakah user memilih "Semua Bulan" (khusus untuk laporan keuangan)
$isSemuaBulan = ($bulan === 'Semua Bulan');
// Nama bulan untuk penamaan file
$namaBulan = $isSemuaBulan ? 'AllMonths' : $bulan;

// Buat objek Spreadsheet
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// (Tambahan) tentukan awal dan akhir tahun
$start_of_year = "$tahun-01-01";
$end_of_year   = "$tahun-12-31";

/**
 * LAPORAN BULANAN (type = 'bulanan')
 */
if ($type === 'bulanan') {
    // Konversi nama bulan ke angka
    $bulan_list = [
        'Januari' => '01', 'Februari' => '02', 'Maret' => '03', 'April' => '04',
        'Mei' => '05', 'Juni' => '06', 'Juli' => '07', 'Agustus' => '08',
        'September' => '09', 'Oktober' => '10', 'November' => '11', 'Desember' => '12'
    ];
    $tanggal_filter = "$tahun-" . $bulan_list[$bulan] . "-01";

    // Judul
    $sheet->setCellValue('A1', 'LAPORAN PEMBAYARAN KOS');
    $sheet->setCellValue('A2', 'BULAN ' . strtoupper($bulan) . ' ' . $tahun);

    // Header tabel
    $sheet->setCellValue('A4', 'No. Kamar');
    $sheet->setCellValue('B4', 'Nama Penghuni');
    $sheet->setCellValue('C4', 'Biaya Bulanan');
    $sheet->setCellValue('D4', 'Tanggal Bayar');
    $sheet->setCellValue('E4', 'Jumlah Bayar');
    $sheet->setCellValue('F4', 'Status');
    $sheet->setCellValue('G4', 'Kekurangan');

    // Query data
    $sql = "SELECT ph.nomor_kamar, ph.nama_penghuni, ph.biaya_bulanan,
                   p.tanggal_pembayaran, p.jumlah_pembayaran,
                   CASE 
                       WHEN p.id_pembayaran IS NULL THEN 'Belum Bayar'
                       ELSE p.status_pembayaran
                   END AS status
            FROM penghuni ph
            LEFT JOIN pembayaran p 
                   ON ph.id_penghuni = p.id_penghuni 
                  AND p.bulan = ? 
                  AND p.tahun = ?
            WHERE ph.tanggal_masuk <= LAST_DAY(?)
            ORDER BY ph.nomor_kamar";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$bulan, $tahun, $tanggal_filter]);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($data)) {
        $sheet->setCellValue('A5', 'Tidak ada data untuk bulan ini');
    } else {
        $row = 5;
        $total_seharusnya = 0;
        $total_diterima = 0;
        $total_kurang = 0;

        foreach ($data as $item) {
            // Hitung kekurangan
            $kekurangan = 0;
            if ($item['status'] === 'Belum Bayar') {
                $kekurangan = $item['biaya_bulanan'];
            } elseif ($item['status'] === 'Belum Lunas') {
                $kekurangan = $item['biaya_bulanan'] - $item['jumlah_pembayaran'];
            }

            $sheet->setCellValue('A' . $row, $item['nomor_kamar']);
            $sheet->setCellValue('B' . $row, $item['nama_penghuni']);
            $sheet->setCellValue('C' . $row, $item['biaya_bulanan']);
            $sheet->setCellValue('D' . $row,
                $item['tanggal_pembayaran']
                    ? date('d/m/Y', strtotime($item['tanggal_pembayaran']))
                    : '-'
            );
            $sheet->setCellValue('E' . $row, $item['jumlah_pembayaran'] ?? 0);
            $sheet->setCellValue('F' . $row, $item['status']);
            $sheet->setCellValue('G' . $row, $kekurangan);

            $total_seharusnya += $item['biaya_bulanan'];
            $total_diterima += $item['jumlah_pembayaran'] ?? 0;
            $total_kurang += $kekurangan;
            $row++;
        }

        // Ringkasan
        $row += 2;
        $sheet->setCellValue('B' . $row, 'Total Seharusnya:');
        $sheet->setCellValue('C' . $row, $total_seharusnya);

        $row++;
        $sheet->setCellValue('B' . $row, 'Total Diterima:');
        $sheet->setCellValue('C' . $row, $total_diterima);

        $row++;
        $sheet->setCellValue('B' . $row, 'Total Kekurangan:');
        $sheet->setCellValue('C' . $row, $total_kurang);

        // Styling border + font
        $styleArray = [
            'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                ],
            ],
        ];

        $sheet->getStyle('A1:G2')->getFont()->setBold(true);
        $sheet->getStyle('A4:G4')->getFont()->setBold(true);
        $sheet->getStyle('A4:G' . $row)->applyFromArray($styleArray);

        // Lebar kolom
        $sheet->getColumnDimension('A')->setWidth(15);
        $sheet->getColumnDimension('B')->setWidth(30);
        $sheet->getColumnDimension('C')->setWidth(15);
        $sheet->getColumnDimension('D')->setWidth(15);
        $sheet->getColumnDimension('E')->setWidth(15);
        $sheet->getColumnDimension('F')->setWidth(15);
        $sheet->getColumnDimension('G')->setWidth(15);
    }
}

/**
 * LAPORAN TAHUNAN (type = 'tahunan')
 */
else if ($type === 'tahunan') {
    $sheet->setCellValue('A1', 'LAPORAN PEMBAYARAN KOS TAHUNAN');
    $sheet->setCellValue('A2', 'TAHUN ' . $tahun);

    // Header kolom
    $sheet->setCellValue('A4', 'No. Kamar');
    $sheet->setCellValue('B4', 'Nama Penghuni');

    // Buat header bulan
    $bulan_list = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];
    $col = 'C';
    foreach ($bulan_list as $b) {
        $sheet->setCellValue($col . '4', $b);
        $col++;
    }
    // Kolom Total
    $sheet->setCellValue($col . '4', 'Total');

    // Query menyesuaikan tahunan.php
    $sql = "
        SELECT
            ph.nomor_kamar,
            ph.nama_penghuni,
            ph.tanggal_masuk,
            ph.tanggal_keluar,

            IF(
                ph.tanggal_masuk <= LAST_DAY('$tahun-01-31')
                AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-01-01'),
                COALESCE(MAX(IF(p.bulan = 'Januari', p.status_pembayaran, NULL)), 'Belum Bayar'),
                '-'
            ) AS januari,

            IF(
                ph.tanggal_masuk <= LAST_DAY('$tahun-02-28')
                AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-02-01'),
                COALESCE(MAX(IF(p.bulan = 'Februari', p.status_pembayaran, NULL)), 'Belum Bayar'),
                '-'
            ) AS februari,

            IF(
                ph.tanggal_masuk <= LAST_DAY('$tahun-03-31')
                AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-03-01'),
                COALESCE(MAX(IF(p.bulan = 'Maret', p.status_pembayaran, NULL)), 'Belum Bayar'),
                '-'
            ) AS maret,

            IF(
                ph.tanggal_masuk <= LAST_DAY('$tahun-04-30')
                AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-04-01'),
                COALESCE(MAX(IF(p.bulan = 'April', p.status_pembayaran, NULL)), 'Belum Bayar'),
                '-'
            ) AS april,

            IF(
                ph.tanggal_masuk <= LAST_DAY('$tahun-05-31')
                AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-05-01'),
                COALESCE(MAX(IF(p.bulan = 'Mei', p.status_pembayaran, NULL)), 'Belum Bayar'),
                '-'
            ) AS mei,

            IF(
                ph.tanggal_masuk <= LAST_DAY('$tahun-06-30')
                AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-06-01'),
                COALESCE(MAX(IF(p.bulan = 'Juni', p.status_pembayaran, NULL)), 'Belum Bayar'),
                '-'
            ) AS juni,

            IF(
                ph.tanggal_masuk <= LAST_DAY('$tahun-07-31')
                AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-07-01'),
                COALESCE(MAX(IF(p.bulan = 'Juli', p.status_pembayaran, NULL)), 'Belum Bayar'),
                '-'
            ) AS juli,

            IF(
                ph.tanggal_masuk <= LAST_DAY('$tahun-08-31')
                AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-08-01'),
                COALESCE(MAX(IF(p.bulan = 'Agustus', p.status_pembayaran, NULL)), 'Belum Bayar'),
                '-'
            ) AS agustus,

            IF(
                ph.tanggal_masuk <= LAST_DAY('$tahun-09-30')
                AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-09-01'),
                COALESCE(MAX(IF(p.bulan = 'September', p.status_pembayaran, NULL)), 'Belum Bayar'),
                '-'
            ) AS september,

            IF(
                ph.tanggal_masuk <= LAST_DAY('$tahun-10-31')
                AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-10-01'),
                COALESCE(MAX(IF(p.bulan = 'Oktober', p.status_pembayaran, NULL)), 'Belum Bayar'),
                '-'
            ) AS oktober,

            IF(
                ph.tanggal_masuk <= LAST_DAY('$tahun-11-30')
                AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-11-01'),
                COALESCE(MAX(IF(p.bulan = 'November', p.status_pembayaran, NULL)), 'Belum Bayar'),
                '-'
            ) AS november,

            IF(
                ph.tanggal_masuk <= LAST_DAY('$tahun-12-31')
                AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-12-01'),
                COALESCE(MAX(IF(p.bulan = 'Desember', p.status_pembayaran, NULL)), 'Belum Bayar'),
                '-'
            ) AS desember,

            COUNT(DISTINCT CASE WHEN p.status_pembayaran = 'Lunas' THEN p.id_pembayaran END) AS total_pembayaran

        FROM penghuni ph
        LEFT JOIN pembayaran p
               ON ph.id_penghuni = p.id_penghuni
              AND p.tahun = ?
        WHERE
            ph.tanggal_masuk <= ?
            AND (
                ph.tanggal_keluar IS NULL
                OR ph.tanggal_keluar >= ?
            )
        GROUP BY ph.id_penghuni
        ORDER BY ph.nomor_kamar
    ";

    $stmt = $conn->prepare($sql);
    $stmt->execute([$tahun, $end_of_year, $start_of_year]);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Isi data
    $row = 5;
    foreach ($data as $item) {
        $sheet->setCellValue('A' . $row, $item['nomor_kamar']);
        $sheet->setCellValue('B' . $row, $item['nama_penghuni']);

        // Loop 12 bulan
        $bulan_keys = [
            'januari','februari','maret','april','mei','juni',
            'juli','agustus','september','oktober','november','desember'
        ];

        $col = 'C';
        foreach ($bulan_keys as $key) {
            $status = $item[$key] ?: '-';  // kalau null jadikan '-'

            // Set nilai cell
            $sheet->setCellValue($col . $row, $status);

            // Pewarnaan sel sama seperti di web:
            // Lunas=green, Belum Bayar=red, Belum Lunas=yellow, -=grey
            switch ($status) {
                case 'Lunas':
                    $color = '28A745'; // hijau
                    break;
                case 'Belum Bayar':
                    $color = 'DC3545'; // merah
                    break;
                case 'Belum Lunas':
                    $color = 'FFC107'; // kuning
                    break;
                case '-':
                    $color = '6C757D'; // abu-abu
                    break;
                default:
                    $color = 'FFFFFF'; // fallback putih
                    break;
            }

            $sheet->getStyle($col . $row)->getFill()
                  ->setFillType(Fill::FILL_SOLID)
                  ->getStartColor()->setRGB($color);

            $col++;
        }

        // Kolom Total (misalnya x/12)
        $sheet->setCellValue($col . $row, $item['total_pembayaran'] . '/12');
        $row++;
    }

    // Styling border dan heading
    $lastCol = $col;
    $styleArray = [
        'borders' => [
            'allBorders' => [
                'borderStyle' => Border::BORDER_THIN,
            ],
        ],
    ];

    $sheet->getStyle('A1:' . $lastCol . '2')->getFont()->setBold(true);
    $sheet->getStyle('A4:' . $lastCol . '4')->getFont()->setBold(true);
    // Terapkan border
    $sheet->getStyle('A4:' . $lastCol . ($row-1))->applyFromArray($styleArray);

    // Atur lebar kolom
    $sheet->getColumnDimension('A')->setWidth(15);
    $sheet->getColumnDimension('B')->setWidth(30);
    for ($i = 'C'; $i <= $lastCol; $i++) {
        $sheet->getColumnDimension($i)->setWidth(12);
    }
}

/**
 * LAPORAN KEUANGAN (type = 'keuangan')
 */
else if ($type === 'keuangan') {
    // Judul
    $sheet->setCellValue('A1', 'LAPORAN KEUANGAN KOS');
    if ($isSemuaBulan) {
        $sheet->setCellValue('A2', 'PERIODE: SEMUA BULAN ' . $tahun);
    } else {
        $sheet->setCellValue('A2', 'PERIODE: ' . strtoupper($bulan) . ' ' . $tahun);
    }
    $sheet->mergeCells('A1:G1');
    $sheet->mergeCells('A2:G2');

    // --- UANG MASUK ---
    if ($isSemuaBulan) {
        $sql_masuk = "
            SELECT p.*, ph.nomor_kamar, ph.nama_penghuni
            FROM pembayaran p
            JOIN penghuni ph ON p.id_penghuni = ph.id_penghuni
            WHERE p.tahun = ?
            ORDER BY p.tanggal_pembayaran
        ";
        $stmt_masuk = $conn->prepare($sql_masuk);
        $stmt_masuk->execute([$tahun]);
    } else {
        $sql_masuk = "
            SELECT p.*, ph.nomor_kamar, ph.nama_penghuni
            FROM pembayaran p
            JOIN penghuni ph ON p.id_penghuni = ph.id_penghuni
            WHERE p.bulan = ?
              AND p.tahun = ?
            ORDER BY p.tanggal_pembayaran
        ";
        $stmt_masuk = $conn->prepare($sql_masuk);
        $stmt_masuk->execute([$bulan, $tahun]);
    }
    $uang_masuk = $stmt_masuk->fetchAll(PDO::FETCH_ASSOC);

    // --- UANG KELUAR ---
    if ($isSemuaBulan) {
        $sql_keluar = "
            SELECT po.*, ko.nama_kategori, ko.periode
            FROM pembayaran_operasional po
            JOIN kategori_operasional ko ON po.id_kategori = ko.id_kategori
            WHERE po.tahun = ?
            ORDER BY po.tanggal_pembayaran
        ";
        $stmt_keluar = $conn->prepare($sql_keluar);
        $stmt_keluar->execute([$tahun]);
    } else {
        $sql_keluar = "
            SELECT po.*, ko.nama_kategori, ko.periode
            FROM pembayaran_operasional po
            JOIN kategori_operasional ko ON po.id_kategori = ko.id_kategori
            WHERE (po.bulan = ? OR ko.periode = 'Tahunan')
              AND po.tahun = ?
            ORDER BY po.tanggal_pembayaran
        ";
        $stmt_keluar = $conn->prepare($sql_keluar);
        $stmt_keluar->execute([$bulan, $tahun]);
    }
    $uang_keluar = $stmt_keluar->fetchAll(PDO::FETCH_ASSOC);

    // Styling judul
    $styleTitle = [
        'font' => ['bold' => true],
        'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
    ];
    $sheet->getStyle('A1:A2')->applyFromArray($styleTitle);

    // ------------------ BAGIAN UANG MASUK ------------------
    $row = 4;
    $sheet->setCellValue('A' . $row, 'UANG MASUK');
    $sheet->mergeCells('A'.$row.':G'.$row);
    $sheet->getStyle('A'.$row)->applyFromArray($styleTitle);

    $row++;
    // Header
    $headersMasuk = ['Tanggal', 'No. Kamar', 'Nama Penghuni', 'Bulan', 'Jumlah', 'Status'];
    $col = 'A';
    foreach ($headersMasuk as $header) {
        $sheet->setCellValue($col . $row, $header);
        $col++;
    }

    $row++;
    $total_masuk = 0;
    foreach ($uang_masuk as $masuk) {
        $sheet->setCellValue('A' . $row, date('d/m/Y', strtotime($masuk['tanggal_pembayaran'])));
        $sheet->setCellValue('B' . $row, $masuk['nomor_kamar']);
        $sheet->setCellValue('C' . $row, $masuk['nama_penghuni']);
        $sheet->setCellValue('D' . $row, $masuk['bulan']);
        $sheet->setCellValue('E' . $row, $masuk['jumlah_pembayaran']);
        $sheet->setCellValue('F' . $row, $masuk['status_pembayaran']);

        $total_masuk += $masuk['jumlah_pembayaran'];
        $row++;
    }

    // Total Uang Masuk
    $row++;
    $sheet->setCellValue('C' . $row, 'Total Uang Masuk');
    $sheet->setCellValue('E' . $row, $total_masuk);
    $sheet->getStyle('C'.$row.':E'.$row)->getFont()->setBold(true);

    // ------------------ BAGIAN UANG KELUAR ------------------
    $row += 2;
    $sheet->setCellValue('A' . $row, 'UANG KELUAR');
    $sheet->mergeCells('A'.$row.':G'.$row);
    $sheet->getStyle('A'.$row)->applyFromArray($styleTitle);

    $row++;
    $headersKeluar = ['Tanggal', 'Kategori', 'Periode', 'Nominal', 'Keterangan'];
    $col = 'A';
    foreach ($headersKeluar as $header) {
        $sheet->setCellValue($col . $row, $header);
        $col++;
    }

    $row++;
    $total_keluar = 0;
    foreach ($uang_keluar as $keluar) {
        $sheet->setCellValue('A' . $row, date('d/m/Y', strtotime($keluar['tanggal_pembayaran'])));
        $sheet->setCellValue('B' . $row, $keluar['nama_kategori']);
        $sheet->setCellValue('C' . $row,
            ($keluar['periode'] === 'Tahunan')
                ? "Tahunan ({$keluar['tahun']})"
                : "Bulanan ({$keluar['bulan']} {$keluar['tahun']})"
        );
        $sheet->setCellValue('D' . $row, $keluar['nominal']);
        $sheet->setCellValue('E' . $row, $keluar['keterangan'] ?? '-');

        $total_keluar += $keluar['nominal'];
        $row++;
    }

    // Total Uang Keluar
    $row++;
    $sheet->setCellValue('C' . $row, 'Total Uang Keluar');
    $sheet->setCellValue('D' . $row, $total_keluar);
    $sheet->getStyle('C'.$row.':D'.$row)->getFont()->setBold(true);

    // ------------------ RINGKASAN ------------------
    $row += 2;
    $sheet->setCellValue('A' . $row, 'RINGKASAN');
    $sheet->mergeCells('A'.$row.':G'.$row);
    $sheet->getStyle('A'.$row)->applyFromArray($styleTitle);

    $row++;
    $sheet->setCellValue('C' . $row, 'Total Uang Masuk');
    $sheet->setCellValue('D' . $row, $total_masuk);

    $row++;
    $sheet->setCellValue('C' . $row, 'Total Uang Keluar');
    $sheet->setCellValue('D' . $row, $total_keluar);

    $row++;
    $sheet->setCellValue('C' . $row, 'Saldo');
    $sheet->setCellValue('D' . $row, $total_masuk - $total_keluar);
    $sheet->getStyle('C'.$row.':D'.$row)->getFont()->setBold(true);

    // Atur lebar kolom
    $sheet->getColumnDimension('A')->setWidth(15);
    $sheet->getColumnDimension('B')->setWidth(15);
    $sheet->getColumnDimension('C')->setWidth(25);
    $sheet->getColumnDimension('D')->setWidth(15);
    $sheet->getColumnDimension('E')->setWidth(15);
    $sheet->getColumnDimension('F')->setWidth(15);
    $sheet->getColumnDimension('G')->setWidth(20);

    // Format angka (kolom E untuk Uang Masuk)
    $lastRow = $row;
    $sheet->getStyle('E5:E'.$lastRow)->getNumberFormat()->setFormatCode('#,##0');

    // Border
    $styleBorder = [
        'borders' => [
            'allBorders' => [
                'borderStyle' => Border::BORDER_THIN,
            ],
        ],
    ];
    $sheet->getStyle('A4:G'.$lastRow)->applyFromArray($styleBorder);
}

// Bersihkan buffer sebelum output
if (ob_get_contents()) {
    ob_end_clean();
}

// SET HEADER UNTUK DOWNLOAD
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="Laporan_' . $type . '_' . $namaBulan . '_' . $tahun . '.xlsx"');
header('Cache-Control: max-age=0');

// Generate file Excel
$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
