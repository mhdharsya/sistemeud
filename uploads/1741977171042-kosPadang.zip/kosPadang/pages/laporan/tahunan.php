<?php
// tahunan.php
require_once '../../config/database.php';
include '../../includes/header.php';

// 1. Ambil tahun dari GET, default ke tahun saat ini
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');

// Tentukan awal & akhir tahun dalam format YYYY-mm-dd
$start_of_year = $tahun . '-01-01';
$end_of_year   = $tahun . '-12-31';

// ------------------------------------------------------------
// 2. QUERY UTAMA: Menampilkan status pembayaran per bulan
// ------------------------------------------------------------
$sql = "
    SELECT
        ph.id_penghuni,
        ph.nomor_kamar,
        ph.nama_penghuni,

        -- Januari
        IF(
            ph.tanggal_masuk <= LAST_DAY('$tahun-01-31')
            AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-01-01'),
            COALESCE(MAX(IF(p.bulan = 'Januari', p.status_pembayaran, NULL)), 'Belum Bayar'),
            '-'
        ) AS januari,

        -- Februari
        IF(
            ph.tanggal_masuk <= LAST_DAY('$tahun-02-28')
            AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-02-01'),
            COALESCE(MAX(IF(p.bulan = 'Februari', p.status_pembayaran, NULL)), 'Belum Bayar'),
            '-'
        ) AS februari,

        -- Maret
        IF(
            ph.tanggal_masuk <= LAST_DAY('$tahun-03-31')
            AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-03-01'),
            COALESCE(MAX(IF(p.bulan = 'Maret', p.status_pembayaran, NULL)), 'Belum Bayar'),
            '-'
        ) AS maret,

        -- April
        IF(
            ph.tanggal_masuk <= LAST_DAY('$tahun-04-30')
            AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-04-01'),
            COALESCE(MAX(IF(p.bulan = 'April', p.status_pembayaran, NULL)), 'Belum Bayar'),
            '-'
        ) AS april,

        -- Mei
        IF(
            ph.tanggal_masuk <= LAST_DAY('$tahun-05-31')
            AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-05-01'),
            COALESCE(MAX(IF(p.bulan = 'Mei', p.status_pembayaran, NULL)), 'Belum Bayar'),
            '-'
        ) AS mei,

        -- Juni
        IF(
            ph.tanggal_masuk <= LAST_DAY('$tahun-06-30')
            AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-06-01'),
            COALESCE(MAX(IF(p.bulan = 'Juni', p.status_pembayaran, NULL)), 'Belum Bayar'),
            '-'
        ) AS juni,

        -- Juli
        IF(
            ph.tanggal_masuk <= LAST_DAY('$tahun-07-31')
            AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-07-01'),
            COALESCE(MAX(IF(p.bulan = 'Juli', p.status_pembayaran, NULL)), 'Belum Bayar'),
            '-'
        ) AS juli,

        -- Agustus
        IF(
            ph.tanggal_masuk <= LAST_DAY('$tahun-08-31')
            AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-08-01'),
            COALESCE(MAX(IF(p.bulan = 'Agustus', p.status_pembayaran, NULL)), 'Belum Bayar'),
            '-'
        ) AS agustus,

        -- September
        IF(
            ph.tanggal_masuk <= LAST_DAY('$tahun-09-30')
            AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-09-01'),
            COALESCE(MAX(IF(p.bulan = 'September', p.status_pembayaran, NULL)), 'Belum Bayar'),
            '-'
        ) AS september,

        -- Oktober
        IF(
            ph.tanggal_masuk <= LAST_DAY('$tahun-10-31')
            AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-10-01'),
            COALESCE(MAX(IF(p.bulan = 'Oktober', p.status_pembayaran, NULL)), 'Belum Bayar'),
            '-'
        ) AS oktober,

        -- November
        IF(
            ph.tanggal_masuk <= LAST_DAY('$tahun-11-30')
            AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-11-01'),
            COALESCE(MAX(IF(p.bulan = 'November', p.status_pembayaran, NULL)), 'Belum Bayar'),
            '-'
        ) AS november,

        -- Desember
        IF(
            ph.tanggal_masuk <= LAST_DAY('$tahun-12-31')
            AND (ph.tanggal_keluar IS NULL OR ph.tanggal_keluar >= '$tahun-12-01'),
            COALESCE(MAX(IF(p.bulan = 'Desember', p.status_pembayaran, NULL)), 'Belum Bayar'),
            '-'
        ) AS desember,

        -- Contoh: total berapa kali 'Lunas'
        COUNT(DISTINCT CASE WHEN p.status_pembayaran = 'Lunas' THEN p.id_pembayaran END) as total_pembayaran

    FROM penghuni ph
    LEFT JOIN pembayaran p 
        ON ph.id_penghuni = p.id_penghuni
       AND p.tahun = :tahun

    WHERE
        ph.tanggal_masuk <= :end_of_year
        AND (
            ph.tanggal_keluar IS NULL
            OR ph.tanggal_keluar >= :start_of_year
        )

    GROUP BY ph.id_penghuni
    ORDER BY ph.nomor_kamar
";

// --- DEBUG OPSIONAL: Menampilkan query & parameter sebelum execute
// var_dump($sql);
// var_dump([':tahun'=>$tahun, ':start_of_year'=>$start_of_year, ':end_of_year'=>$end_of_year]);
// die();

// Jalankan query utama
$stmt = $conn->prepare($sql);
$stmt->execute([
    ':tahun'         => $tahun,
    ':start_of_year' => $start_of_year,
    ':end_of_year'   => $end_of_year
]);
$laporan_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ------------------------------------------------------------
// 3. QUERY SUMMARY: Total seharusnya & total diterima
// ------------------------------------------------------------
$sql_summary = "
    SELECT 
        SUM(
            CASE
                WHEN YEAR(ph.tanggal_masuk) < :tahun THEN ph.biaya_bulanan * 12
                WHEN YEAR(ph.tanggal_masuk) = :tahun THEN ph.biaya_bulanan * (12 - MONTH(ph.tanggal_masuk) + 1)
                ELSE 0
            END
        ) as total_seharusnya,
        SUM(p.jumlah_pembayaran) as total_diterima
    FROM penghuni ph
    LEFT JOIN pembayaran p 
        ON ph.id_penghuni = p.id_penghuni
       AND p.tahun = :tahun
    WHERE
        ph.tanggal_masuk <= :end_of_year
        AND (
            ph.tanggal_keluar IS NULL
            OR ph.tanggal_keluar >= :start_of_year
        )
";
$stmt_sum = $conn->prepare($sql_summary);
// --- DEBUG OPSIONAL
// var_dump($sql_summary);
// var_dump([':tahun'=>$tahun, ':start_of_year'=>$start_of_year, ':end_of_year'=>$end_of_year]);
// die();

$total_seharusnya = $summary['total_seharusnya'] ?? 0;
$total_diterima   = $summary['total_diterima']   ?? 0;
$total_kurang     = $total_seharusnya - $total_diterima;
?>

<!-- Bagian HTML Laporan Tahunan -->
<div class="card">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Laporan Tahunan <?= htmlspecialchars($tahun) ?></h5>
            <div>
                <button onclick="window.print()" class="btn btn-secondary me-2">
                    <i class="bi bi-printer"></i> Print
                </button>
                <a href="download.php?type=tahunan&tahun=<?= $tahun ?>" class="btn btn-success">
                    <i class="bi bi-download"></i> Download Excel
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <!-- Filter Form -->
        <form action="" method="GET" class="mb-4">
            <div class="row g-2">
                <div class="col-md-4">
                    <select name="tahun" class="form-select">
                        <?php
                        $tahun_sekarang = date('Y');
                        for ($th = $tahun_sekarang - 1; $th <= $tahun_sekarang + 1; $th++): ?>
                            <option value="<?= $th ?>" <?= ($tahun == $th ? 'selected' : '') ?>>
                                <?= $th ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">Tampilkan</button>
                </div>
            </div>
        </form>

        <!-- Summary Cards
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card bg-light">
                    <div class="card-body">
                        <h6 class="card-title">Total Seharusnya</h6>
                        <h4 class="mb-0">
                            Rp <?= number_format($total_seharusnya, 0, ',', '.') ?>
                        </h4>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <h6 class="card-title">Total Diterima</h6>
                        <h4 class="mb-0">
                            Rp <?= number_format($total_diterima, 0, ',', '.') ?>
                        </h4>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-warning">
                    <div class="card-body">
                        <h6 class="card-title">Total Kekurangan</h6>
                        <h4 class="mb-0">
                            Rp <?= number_format($total_kurang, 0, ',', '.') ?>
                        </h4>
                    </div>
                </div>
            </div>
        </div> -->

        <!-- Tabel Detail Laporan Tahunan -->
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="table-light">
                    <tr>
                        <th>No. Kamar</th>
                        <th>Nama Penghuni</th>
                        <th>Jan</th>
                        <th>Feb</th>
                        <th>Mar</th>
                        <th>Apr</th>
                        <th>Mei</th>
                        <th>Jun</th>
                        <th>Jul</th>
                        <th>Agu</th>
                        <th>Sep</th>
                        <th>Okt</th>
                        <th>Nov</th>
                        <th>Des</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($laporan_data) > 0): ?>
                        <?php foreach ($laporan_data as $row): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['nomor_kamar']) ?></td>
                                <td><?= htmlspecialchars($row['nama_penghuni']) ?></td>
                                
                                <?php
                                // Kolom bulan
                                $bulan_list = [
                                    'januari','februari','maret','april','mei','juni',
                                    'juli','agustus','september','oktober','november','desember'
                                ];

                                foreach ($bulan_list as $bln) {
                                    $status = $row[$bln];
                                    // Pilih style
                                    if ($status === 'Lunas') {
                                        $cls = 'bg-success text-white';
                                        $symbol = '✓';
                                    } elseif ($status === 'Belum Bayar') {
                                        $cls = 'bg-danger text-white';
                                        $symbol = '✗';
                                    } elseif ($status === 'Belum Lunas') {
                                        $cls = 'bg-warning text-dark';
                                        $symbol = '!';
                                    } elseif ($status === '-') {
                                        $cls = 'bg-secondary text-white';
                                        $symbol = '-';
                                    } else {
                                        // fallback
                                        $cls = 'bg-secondary text-white';
                                        $symbol = $status;
                                    }
                                    echo "<td class='$cls text-center'>$symbol</td>";
                                }
                                ?>
                                <td class="text-center"><strong><?= $row['total_pembayaran'] ?>/12</strong></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="15" class="text-center">Tidak ada data</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
