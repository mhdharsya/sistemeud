<?php
// laporan_bulanan.php
require_once '../../config/database.php';
include '../../includes/header.php';

// Get filter parameters
$bulan = isset($_GET['bulan']) ? $_GET['bulan'] : date('F');
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');

// Konversi nama bulan ke angka
$bulan_list_map = [
    'Januari' => '01', 'Februari' => '02', 'Maret' => '03', 'April' => '04',
    'Mei' => '05', 'Juni' => '06', 'Juli' => '07', 'Agustus' => '08',
    'September' => '09', 'Oktober' => '10', 'November' => '11', 'Desember' => '12'
];

$bulan_numeric = $bulan_list_map[$bulan];
$start_of_month = "$tahun-$bulan_numeric-01";
$end_of_month   = date("Y-m-t", strtotime($start_of_month)); // tgl terakhir bulan

// Query untuk data laporan bulanan
$sql = "
SELECT 
    ph.nomor_kamar, 
    ph.nama_penghuni, 
    ph.biaya_bulanan,
    p.tanggal_pembayaran, 
    p.jumlah_pembayaran, 
    p.status_pembayaran,
    CASE 
        WHEN p.id_pembayaran IS NULL THEN 'Belum Bayar'
        ELSE p.status_pembayaran
    END AS status
FROM penghuni ph
LEFT JOIN pembayaran p 
    ON ph.id_penghuni = p.id_penghuni
    AND p.bulan = :bulan
    AND p.tahun = :tahun
WHERE
    ph.tanggal_masuk <= :end_of_month
    AND (
        ph.tanggal_keluar IS NULL
        OR ph.tanggal_keluar >= :start_of_month
    )
ORDER BY ph.nomor_kamar
";

$stmt = $conn->prepare($sql);
$stmt->execute([
    ':bulan' => $bulan,
    ':tahun' => $tahun,
    ':end_of_month' => $end_of_month,
    ':start_of_month' => $start_of_month
]);
$laporan_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Hitung summary
$total_seharusnya = 0;
$total_diterima = 0;
$total_kurang = 0;
$total_lunas = 0;
$total_belum_lunas = 0;
$total_belum_bayar = 0;

foreach ($laporan_data as $data) {
    $total_seharusnya += $data['biaya_bulanan'];
    $total_diterima   += $data['jumlah_pembayaran'] ?? 0;
    
    if ($data['status'] === 'Lunas') {
        $total_lunas++;
    } elseif ($data['status'] === 'Belum Lunas') {
        $total_belum_lunas++;
        $total_kurang += ($data['biaya_bulanan'] - $data['jumlah_pembayaran']);
    } else {
        // 'Belum Bayar'
        $total_belum_bayar++;
        $total_kurang += $data['biaya_bulanan'];
    }
}
?>

<div class="card">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Laporan Pembayaran Bulanan</h5>
            <div>
                <button onclick="window.print()" class="btn btn-secondary me-2">
                    <i class="bi bi-printer"></i> Print
                </button>
                <a href="download.php?type=bulanan&bulan=<?= $bulan ?>&tahun=<?= $tahun ?>" 
                   class="btn btn-success">
                    <i class="bi bi-download"></i> Download Excel
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <!-- Filter Form -->
        <form action="" method="GET" class="mb-4">
            <div class="row g-3">
                <div class="col-md-4">
                    <select name="bulan" class="form-select">
                        <?php
                        $all_bulan = [
                            'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
                            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
                        ];
                        foreach ($all_bulan as $b): ?>
                            <option value="<?= $b ?>" <?= ($bulan === $b ? 'selected' : '') ?>>
                                <?= $b ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <select name="tahun" class="form-select">
                        <?php
                        $tahun_sekarang = date('Y');
                        for ($t = $tahun_sekarang - 1; $t <= $tahun_sekarang + 1; $t++): ?>
                            <option value="<?= $t ?>" <?= ($tahun == $t ? 'selected' : '') ?>>
                                <?= $t ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary w-100">Tampilkan</button>
                </div>
            </div>
        </form>

        <!-- Summary Cards -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card bg-light">
                    <div class="card-body">
                        <h6 class="card-title">Total Seharusnya</h6>
                        <h4 class="mb-0">Rp <?= number_format($total_seharusnya, 0, ',', '.') ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <h6 class="card-title">Total Diterima</h6>
                        <h4 class="mb-0">Rp <?= number_format($total_diterima, 0, ',', '.') ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-warning">
                    <div class="card-body">
                        <h6 class="card-title">Total Kekurangan</h6>
                        <h4 class="mb-0">Rp <?= number_format($total_kurang, 0, ',', '.') ?></h4>
                    </div>
                </div>
            </div>
        </div>

        <!-- Status Summary -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card bg-success text-white">
                    <div class="card-body text-center">
                        <h3 class="mb-0"><?= $total_lunas ?></h3>
                        <p class="mb-0">Lunas</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-warning">
                    <div class="card-body text-center">
                        <h3 class="mb-0"><?= $total_belum_lunas ?></h3>
                        <p class="mb-0">Belum Lunas</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-danger text-white">
                    <div class="card-body text-center">
                        <h3 class="mb-0"><?= $total_belum_bayar ?></h3>
                        <p class="mb-0">Belum Bayar</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Detailed Report Table -->
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>No. Kamar</th>
                        <th>Nama Penghuni</th>
                        <th>Biaya Bulanan</th>
                        <th>Tanggal Bayar</th>
                        <th>Jumlah Bayar</th>
                        <th>Status</th>
                        <th>Kekurangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($laporan_data as $data): 
                        $kekurangan = 0;
                        if ($data['status'] === 'Belum Bayar') {
                            $kekurangan = $data['biaya_bulanan'];
                        } elseif ($data['status'] === 'Belum Lunas') {
                            $kekurangan = $data['biaya_bulanan'] - $data['jumlah_pembayaran'];
                        }
                    ?>
                        <tr>
                            <td><?= htmlspecialchars($data['nomor_kamar']) ?></td>
                            <td><?= htmlspecialchars($data['nama_penghuni']) ?></td>
                            <td>Rp <?= number_format($data['biaya_bulanan'], 0, ',', '.') ?></td>
                            <td>
                                <?= $data['tanggal_pembayaran']
                                    ? date('d/m/Y', strtotime($data['tanggal_pembayaran']))
                                    : '-' ?>
                            </td>
                            <td>Rp <?= number_format($data['jumlah_pembayaran'] ?? 0, 0, ',', '.') ?></td>
                            <td>
                                <span class="badge bg-<?= 
                                    $data['status'] === 'Lunas' ? 'success' : 
                                    ($data['status'] === 'Belum Lunas' ? 'warning' : 'danger') 
                                ?>">
                                    <?= $data['status'] ?>
                                </span>
                            </td>
                            <td>Rp <?= number_format($kekurangan, 0, ',', '.') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
