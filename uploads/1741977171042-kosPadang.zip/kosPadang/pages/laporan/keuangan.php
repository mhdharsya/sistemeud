<?php
require_once '../../config/database.php';
include '../../includes/header.php';

// 1. Dapatkan parameter filter dari form (bulan, tahun).
$bulan = isset($_GET['bulan']) ? $_GET['bulan'] : date('F');  // Misal default bulan ini
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');  // Misal default tahun ini

/**
 * Siapkan daftar bulan, dengan menambahkan "Semua Bulan" di urutan paling atas
 * (atau boleh di bagian akhir, terserah preferensi Anda).
 */
$bulan_list = [
    'Semua Bulan',
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
];

/**
 * 2. Cek apakah user memilih "Semua Bulan".
 *    Kita gunakan variabel boolean untuk memudahkan penulisan query.
 */
$filterSemuaBulan = ($bulan === 'Semua Bulan');

/**
 * 3. Hitung uang masuk (pembayaran kos)
 *    - Jika semua bulan: filter hanya berdasarkan tahun
 *    - Jika bulan spesifik: filter berdasarkan bulan & tahun
 */
if ($filterSemuaBulan) {
    // Semua bulan: SUM untuk semua bulan di tahun terpilih
    $sql_masuk = "
        SELECT SUM(p.jumlah_pembayaran) AS total_masuk
        FROM pembayaran p
        WHERE p.tahun = ?
    ";
    $stmt_masuk = $conn->prepare($sql_masuk);
    $stmt_masuk->execute([$tahun]);
} else {
    // Bulan spesifik
    $sql_masuk = "
        SELECT SUM(p.jumlah_pembayaran) AS total_masuk
        FROM pembayaran p 
        WHERE p.bulan = ? 
          AND p.tahun = ?
    ";
    $stmt_masuk = $conn->prepare($sql_masuk);
    $stmt_masuk->execute([$bulan, $tahun]);
}
$uang_masuk = $stmt_masuk->fetch(PDO::FETCH_ASSOC)['total_masuk'] ?? 0;

/**
 * 4. Hitung uang keluar (pembayaran operasional)
 *    - Jika semua bulan: filter hanya berdasarkan tahun
 *    - Jika bulan spesifik: filter berdasarkan bulan & tahun
 */
if ($filterSemuaBulan) {
    // Semua bulan
    $sql_keluar = "
        SELECT SUM(po.nominal) AS total_keluar
        FROM pembayaran_operasional po
        WHERE po.tahun = ?
    ";
    $stmt_keluar = $conn->prepare($sql_keluar);
    $stmt_keluar->execute([$tahun]);
} else {
    // Bulan spesifik
    $sql_keluar = "
        SELECT SUM(po.nominal) AS total_keluar
        FROM pembayaran_operasional po
        WHERE (po.bulan = ? OR po.bulan IS NULL)
          AND po.tahun = ?
    ";
    $stmt_keluar = $conn->prepare($sql_keluar);
    $stmt_keluar->execute([$bulan, $tahun]);
}
$uang_keluar = $stmt_keluar->fetch(PDO::FETCH_ASSOC)['total_keluar'] ?? 0;

/**
 * 5. Ambil detail uang masuk (list pembayaran kos)
 */
if ($filterSemuaBulan) {
    $sql_detail_masuk = "
        SELECT p.*, ph.nomor_kamar, ph.nama_penghuni
        FROM pembayaran p
        JOIN penghuni ph ON p.id_penghuni = ph.id_penghuni
        WHERE p.tahun = ?
        ORDER BY p.tanggal_pembayaran
    ";
    $stmt_detail_masuk = $conn->prepare($sql_detail_masuk);
    $stmt_detail_masuk->execute([$tahun]);
} else {
    $sql_detail_masuk = "
        SELECT p.*, ph.nomor_kamar, ph.nama_penghuni
        FROM pembayaran p
        JOIN penghuni ph ON p.id_penghuni = ph.id_penghuni
        WHERE p.bulan = ? 
          AND p.tahun = ?
        ORDER BY p.tanggal_pembayaran
    ";
    $stmt_detail_masuk = $conn->prepare($sql_detail_masuk);
    $stmt_detail_masuk->execute([$bulan, $tahun]);
}
$detail_masuk = $stmt_detail_masuk->fetchAll(PDO::FETCH_ASSOC);

/**
 * 6. Ambil detail uang keluar (list pembayaran operasional)
 *    - Perhatikan juga kolom `ko.periode`.
 */
if ($filterSemuaBulan) {
    $sql_detail_keluar = "
        SELECT po.*, ko.nama_kategori, ko.periode
        FROM pembayaran_operasional po
        JOIN kategori_operasional ko ON po.id_kategori = ko.id_kategori
        WHERE po.tahun = ?
        ORDER BY po.tanggal_pembayaran
    ";
    $stmt_detail_keluar = $conn->prepare($sql_detail_keluar);
    $stmt_detail_keluar->execute([$tahun]);
} else {
    $sql_detail_keluar = "
        SELECT po.*, ko.nama_kategori, ko.periode
        FROM pembayaran_operasional po
        JOIN kategori_operasional ko ON po.id_kategori = ko.id_kategori
        WHERE (po.bulan = ? OR ko.periode = 'Tahunan')
          AND po.tahun = ?
        ORDER BY po.tanggal_pembayaran
    ";
    $stmt_detail_keluar = $conn->prepare($sql_detail_keluar);
    $stmt_detail_keluar->execute([$bulan, $tahun]);
}
$detail_keluar = $stmt_detail_keluar->fetchAll(PDO::FETCH_ASSOC);

/**
 * 7. Hitung saldo
 */
$saldo = $uang_masuk - $uang_keluar;
?>

<div class="card">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Laporan Keuangan</h5>
            <div>
                <button onclick="window.print()" class="btn btn-secondary me-2">
                    <i class="bi bi-printer"></i> Print
                </button>
                <a href="download.php?type=keuangan&bulan=<?= $bulan ?>&tahun=<?= $tahun ?>" 
                   class="btn btn-success">
                    <i class="bi bi-download"></i> Download Excel
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <!-- Filter Form -->
        <form action="" method="GET" class="mb-4">
            <div class="row g-3">
                <div class="col-md-4">
                    <!-- Pilihan Bulan (termasuk 'Semua Bulan') -->
                    <select name="bulan" class="form-select">
                        <?php foreach ($bulan_list as $b) { ?>
                            <option value="<?= $b ?>" <?= ($bulan === $b) ? 'selected' : '' ?>>
                                <?= $b ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <!-- Pilihan Tahun -->
                    <select name="tahun" class="form-select">
                        <?php
                        $tahun_sekarang = date('Y');
                        // Silakan sesuaikan range tahun sesuai kebutuhan
                        for ($t = $tahun_sekarang - 1; $t <= $tahun_sekarang + 1; $t++) { ?>
                            <option value="<?= $t ?>" <?= ($tahun == $t) ? 'selected' : '' ?>>
                                <?= $t ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary w-100">Tampilkan</button>
                </div>
            </div>
        </form>

        <!-- Summary Cards -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <h6 class="card-title">Total Uang Masuk</h6>
                        <h4 class="mb-0">Rp <?= number_format($uang_masuk, 0, ',', '.') ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-danger text-white">
                    <div class="card-body">
                        <h6 class="card-title">Total Uang Keluar</h6>
                        <h4 class="mb-0">Rp <?= number_format($uang_keluar, 0, ',', '.') ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card <?= $saldo >= 0 ? 'bg-primary' : 'bg-warning' ?> text-white">
                    <div class="card-body">
                        <h6 class="card-title">Saldo</h6>
                        <h4 class="mb-0">Rp <?= number_format($saldo, 0, ',', '.') ?></h4>
                    </div>
                </div>
            </div>
        </div>

        <!-- Detail Uang Masuk -->
        <div class="card mb-4">
            <div class="card-header bg-success text-white">
                <h6 class="card-title mb-0">Detail Uang Masuk</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>No. Kamar</th>
                                <th>Nama Penghuni</th>
                                <th>Jumlah</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($detail_masuk)) { ?>
                                <tr>
                                    <td colspan="5" class="text-center">Tidak ada data uang masuk</td>
                                </tr>
                            <?php } else { ?>
                                <?php foreach ($detail_masuk as $masuk) { ?>
                                    <tr>
                                        <td><?= date('d/m/Y', strtotime($masuk['tanggal_pembayaran'])) ?></td>
                                        <td><?= htmlspecialchars($masuk['nomor_kamar']) ?></td>
                                        <td><?= htmlspecialchars($masuk['nama_penghuni']) ?></td>
                                        <td>Rp <?= number_format($masuk['jumlah_pembayaran'], 0, ',', '.') ?></td>
                                        <td>
                                            <span class="badge bg-<?= $masuk['status_pembayaran'] === 'Lunas' ? 'success' : 'warning' ?>">
                                                <?= $masuk['status_pembayaran'] ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php } ?>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Detail Uang Keluar -->
        <div class="card">
            <div class="card-header bg-danger text-white">
                <h6 class="card-title mb-0">Detail Uang Keluar</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Kategori</th>
                                <th>Periode</th>
                                <th>Nominal</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($detail_keluar)) { ?>
                                <tr>
                                    <td colspan="5" class="text-center">Tidak ada data uang keluar</td>
                                </tr>
                            <?php } else { ?>
                                <?php foreach ($detail_keluar as $keluar) { ?>
                                    <tr>
                                        <td><?= date('d/m/Y', strtotime($keluar['tanggal_pembayaran'])) ?></td>
                                        <td><?= htmlspecialchars($keluar['nama_kategori']) ?></td>
                                        <td>
                                            <!-- Tampilkan "Tahunan" jika ko.periode = 'Tahunan', 
                                                 atau Bulanan (X 20XX) jika tidak -->
                                            <?php if ($keluar['periode'] === 'Tahunan') { ?>
                                                Tahunan (<?= $keluar['tahun'] ?>)
                                            <?php } else { ?>
                                                Bulanan (<?= $keluar['bulan'] ?> <?= $keluar['tahun'] ?>)
                                            <?php } ?>
                                        </td>
                                        <td>Rp <?= number_format($keluar['nominal'], 0, ',', '.') ?></td>
                                        <td><?= htmlspecialchars($keluar['keterangan'] ?? '-') ?></td>
                                    </tr>
                                <?php } ?>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
