<?php
require_once '../../config/database.php';
ob_start(); // Mulai output buffering
include '../../includes/header.php';

// Debugging error PHP
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Get kategori list
$sql_kategori = "SELECT * FROM kategori_operasional WHERE nama_kategori != 'Bagi Hasil Pemilik Gedung' ORDER BY nama_kategori";
$stmt_kategori = $conn->query($sql_kategori);
$kategori_list = $stmt_kategori->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $id_kategori = $_POST['id_kategori'];
        $tanggal_pembayaran = $_POST['tanggal_pembayaran'];
        $nominal = $_POST['nominal'];
        $bulan = $_POST['bulan'];
        $tahun = $_POST['tahun'];
        $keterangan = $_POST['keterangan'];

        // Cek periode kategori
        $sql_check = "SELECT periode FROM kategori_operasional WHERE id_kategori = ?";
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->execute([$id_kategori]);
        $kategori = $stmt_check->fetch();

        // Handle file upload
        $bukti_pembayaran = '';
        if (isset($_FILES['bukti_pembayaran']) && $_FILES['bukti_pembayaran']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../../assets/uploads/bukti_operasional/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            $file_extension = pathinfo($_FILES['bukti_pembayaran']['name'], PATHINFO_EXTENSION);
            $file_name = uniqid() . '.' . $file_extension;
            $upload_path = $upload_dir . $file_name;

            if (move_uploaded_file($_FILES['bukti_pembayaran']['tmp_name'], $upload_path)) {
                $bukti_pembayaran = $file_name;
            }
        }

        // Cek pembayaran tahunan
        if ($kategori['periode'] === 'Tahunan') {
            $check_sql = "SELECT COUNT(*) FROM pembayaran_operasional 
                         WHERE id_kategori = ? AND tahun = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->execute([$id_kategori, $tahun]);
            if ($check_stmt->fetchColumn() > 0) {
                throw new Exception("Pembayaran tahunan untuk kategori ini di tahun $tahun sudah ada!");
            }
        }

        // Insert data
        $sql = "INSERT INTO pembayaran_operasional 
                (id_kategori, tanggal_pembayaran, bulan, tahun, nominal, bukti_pembayaran, keterangan) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            $id_kategori,
            $tanggal_pembayaran,
            $kategori['periode'] === 'Tahunan' ? NULL : $bulan,
            $tahun,
            $nominal,
            $bukti_pembayaran,
            $keterangan
        ]);

        // Redirect ke halaman operasional/list.php
        header('Location: list.php?status=success&message=Pembayaran berhasil ditambahkan');
        exit();
    } catch(Exception $e) {
        $error_message = $e->getMessage();
    }
}

ob_end_flush(); // Kirim output buffering
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">Tambah Pembayaran Operasional</h5>
    </div>
    <div class="card-body">
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger">
                <?= htmlspecialchars($error_message) ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST" enctype="multipart/form-data" onsubmit="return validateForm()">
            <div class="mb-3">
                <label for="id_kategori" class="form-label">Kategori Pembayaran</label>
                <select class="form-select" name="id_kategori" id="id_kategori" required>
                    <option value="">Pilih Kategori</option>
                    <?php foreach ($kategori_list as $kategori): ?>
                        <option value="<?= $kategori['id_kategori'] ?>" 
                                data-periode="<?= $kategori['periode'] ?>">
                            <?= htmlspecialchars($kategori['nama_kategori']) ?> 
                            (<?= $kategori['periode'] ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="tanggal_pembayaran" class="form-label">Tanggal Pembayaran</label>
                <input type="date" class="form-control" name="tanggal_pembayaran" 
                       value="<?= date('Y-m-d') ?>" required>
            </div>

            <div class="row">
                <div class="col-md-6" id="bulan_container">
                    <div class="mb-3">
                        <label for="bulan" class="form-label">Bulan</label>
                        <select class="form-select" name="bulan" id="bulan">
                            <?php
                            $bulan_list = [
                                'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
                                'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
                            ];
                            foreach ($bulan_list as $b): ?>
                                <option value="<?= $b ?>" <?= date('F') === $b ? 'selected' : '' ?>>
                                    <?= $b ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="tahun" class="form-label">Tahun</label>
                        <select class="form-select" name="tahun" required>
                            <?php
                            $tahun_sekarang = date('Y');
                            for ($t = $tahun_sekarang - 1; $t <= $tahun_sekarang + 2; $t++): ?>
                                <option value="<?= $t ?>" <?= $tahun_sekarang === $t ? 'selected' : '' ?>>
                                    <?= $t ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="mb-3">
                <label for="nominal" class="form-label">Nominal Pembayaran</label>
                <input type="number" class="form-control" name="nominal" required>
            </div>

            <div class="mb-3">
                <label for="bukti_pembayaran" class="form-label">Bukti Pembayaran</label>
                <input type="file" class="form-control" name="bukti_pembayaran" 
                       accept="image/*">
                <small class="text-muted">Upload gambar bukti pembayaran (JPG, PNG)</small>
            </div>

            <div class="mb-3">
                <label for="keterangan" class="form-label">Keterangan (opsional)</label>
                <textarea class="form-control" name="keterangan" rows="3"></textarea>
            </div>

            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-primary">Simpan Pembayaran</button>
                <a href="list.php" class="btn btn-secondary">Kembali</a>
            </div>
        </form>
    </div>
</div>

<script>
// Script untuk mengelola tampilan form berdasarkan periode
document.getElementById('id_kategori').addEventListener('change', function() {
    const selectedOption = this.options[this.selectedIndex];
    const periode = selectedOption.getAttribute('data-periode');
    const bulanContainer = document.getElementById('bulan_container');
    const bulanSelect = document.getElementById('bulan');
    
    if (periode === 'Tahunan') {
        bulanContainer.style.display = 'none';
        bulanSelect.removeAttribute('required');
    } else {
        bulanContainer.style.display = 'block';
        bulanSelect.setAttribute('required', 'required');
    }
});

// Fungsi validasi form
function validateForm() {
    const kategori = document.getElementById('id_kategori');
    const nominal = document.getElementsByName('nominal')[0];
    const bukti = document.getElementsByName('bukti_pembayaran')[0];

    if (!kategori.value) {
        alert('Silakan pilih kategori pembayaran');
        return false;
    }

    if (!nominal.value || nominal.value <= 0) {
        alert('Nominal pembayaran harus lebih dari 0');
        return false;
    }

    if (!bukti.value) {
        alert('Silakan upload bukti pembayaran');
        return false;
    }

    return true;
}
</script>

<?php include '../../includes/footer.php'; ?>