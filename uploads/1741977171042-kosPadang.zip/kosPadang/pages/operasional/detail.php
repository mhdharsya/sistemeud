<?php
require_once '../../config/database.php';
include '../../includes/header.php';

$id_pembayaran = isset($_GET['id']) ? $_GET['id'] : 0;

// Get payment detail
$sql = "SELECT po.*, ko.nama_kategori, ko.periode
        FROM pembayaran_operasional po
        JOIN kategori_operasional ko ON po.id_kategori = ko.id_kategori
        WHERE po.id_pembayaran_ops = ?";

$stmt = $conn->prepare($sql);
$stmt->execute([$id_pembayaran]);
$pembayaran = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$pembayaran) {
    echo "<div class='alert alert-danger'>Data pembayaran tidak ditemukan</div>";
    exit;
}
?>

<div class="card">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Detail Pembayaran Operasional</h5>
            <div>
                <button onclick="window.print()" class="btn btn-secondary me-2">
                    <i class="bi bi-printer"></i> Print
                </button>
                <a href="list.php" class="btn btn-primary">
                    <i class="bi bi-arrow-left"></i> Kembali
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <div class="card mb-3">
                    <div class="card-body">
                        <h6 class="card-subtitle mb-3 text-muted">Informasi Pembayaran</h6>
                        <table class="table table-borderless">
                            <tr>
                                <td width="40%">Kategori</td>
                                <td>: <?= htmlspecialchars($pembayaran['nama_kategori']) ?></td>
                            </tr>
                            <tr>
                                <td>Jenis Periode</td>
                                <td>: <?= htmlspecialchars($pembayaran['periode']) ?></td>
                            </tr>
                            <tr>
                                <td>Periode</td>
                                <td>: 
                                    <?php if ($pembayaran['periode'] === 'Tahunan'): ?>
                                        Tahun <?= $pembayaran['tahun'] ?>
                                    <?php else: ?>
                                        <?= $pembayaran['bulan'] ?> <?= $pembayaran['tahun'] ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td>Tanggal Pembayaran</td>
                                <td>: <?= date('d/m/Y', strtotime($pembayaran['tanggal_pembayaran'])) ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card mb-3">
                    <div class="card-body">
                        <h6 class="card-subtitle mb-3 text-muted">Rincian Pembayaran</h6>
                        <table class="table table-borderless">
                            <tr>
                                <td width="40%">Nominal</td>
                                <td>: Rp <?= number_format($pembayaran['nominal'], 0, ',', '.') ?></td>
                            </tr>
                            <tr>
                                <td>Waktu Input</td>
                                <td>: <?= date('d/m/Y H:i:s', strtotime($pembayaran['created_at'])) ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Keterangan -->
        <?php if ($pembayaran['keterangan']): ?>
        <div class="card mb-3">
            <div class="card-body">
                <h6 class="card-subtitle mb-3 text-muted">Keterangan</h6>
                <p class="mb-0"><?= nl2br(htmlspecialchars($pembayaran['keterangan'])) ?></p>
            </div>
        </div>
        <?php endif; ?>

        <!-- Bukti Pembayaran -->
        <div class="card">
            <div class="card-body">
                <h6 class="card-subtitle mb-3 text-muted">Bukti Pembayaran</h6>
                <div class="text-center">
                    <img src="../../assets/uploads/bukti_operasional/<?= $pembayaran['bukti_pembayaran'] ?>" 
                         class="img-fluid" style="max-height: 500px;" alt="Tidak Ada Bukti Pembayaran">
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Print Styles -->
<style media="print">
    .no-print {
        display: none !important;
    }
    
    .card {
        border: none !important;
        box-shadow: none !important;
    }
    
    .card-body {
        padding: 0 !important;
    }
    
    img {
        max-width: 100% !important;
        height: auto !important;
    }
</style>

<?php include '../../includes/footer.php'; ?>