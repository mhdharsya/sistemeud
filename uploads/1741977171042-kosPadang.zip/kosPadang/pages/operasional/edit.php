<?php
require_once '../../config/database.php';
include '../../includes/header.php';

// Ambil ID Pembayaran
$id_pembayaran_ops = isset($_GET['id']) ? $_GET['id'] : null;

if (!$id_pembayaran_ops) {
    echo "ID tidak ditemukan.";
    exit;
}

// Ambil data pembayaran operasional
$sql = "SELECT * FROM pembayaran_operasional WHERE id_pembayaran_ops = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$id_pembayaran_ops]);
$operasional = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$operasional) {
    echo "Data pembayaran operasional tidak ditemukan.";
    exit;
}

// Update data pembayaran operasional
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal_pembayaran = $_POST['tanggal_pembayaran'];
    $id_kategori = $_POST['id_kategori'];
    $bulan = $_POST['bulan'];
    $tahun = $_POST['tahun'];
    $nominal = $_POST['nominal'];
    $keterangan = $_POST['keterangan'];

    $sql_update = "UPDATE pembayaran_operasional 
                   SET tanggal_pembayaran = ?, id_kategori = ?, bulan = ?, tahun = ?, nominal = ?, keterangan = ? 
                   WHERE id_pembayaran_ops = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->execute([$tanggal_pembayaran, $id_kategori, $bulan, $tahun, $nominal, $keterangan, $id_pembayaran_ops]);

    echo "<script>alert('Data berhasil diperbarui!'); window.location='list.php';</script>";
    exit;
}

// Ambil daftar kategori operasional
$sql_kategori = "SELECT * FROM kategori_operasional";
$stmt_kategori = $conn->query($sql_kategori);
$kategori_list = $stmt_kategori->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title">Edit Pembayaran Operasional</h5>
    </div>
    <div class="card-body">
        <form action="" method="POST">
            <!-- Tanggal -->
            <div class="mb-3">
                <label for="tanggal_pembayaran" class="form-label">Tanggal Pembayaran</label>
                <input type="date" name="tanggal_pembayaran" id="tanggal_pembayaran" 
                       class="form-control" value="<?= htmlspecialchars($operasional['tanggal_pembayaran']) ?>" required>
            </div>

            <!-- Kategori -->
            <div class="mb-3">
                <label for="id_kategori" class="form-label">Kategori</label>
                <select name="id_kategori" id="id_kategori" class="form-select" required>
                    <?php foreach ($kategori_list as $kategori): ?>
                        <option value="<?= $kategori['id_kategori'] ?>" 
                                <?= $operasional['id_kategori'] == $kategori['id_kategori'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($kategori['nama_kategori']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Bulan -->
            <div class="mb-3">
                <label for="bulan" class="form-label">Bulan</label>
                <select name="bulan" id="bulan" class="form-select">
                    <?php
                    $bulan_list = [
                        'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
                        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
                    ];
                    foreach ($bulan_list as $b): ?>
                        <option value="<?= $b ?>" <?= $operasional['bulan'] === $b ? 'selected' : '' ?>>
                            <?= $b ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Tahun -->
            <div class="mb-3">
                <label for="tahun" class="form-label">Tahun</label>
                <input type="number" name="tahun" id="tahun" 
                       class="form-control" value="<?= htmlspecialchars($operasional['tahun']) ?>" required>
            </div>

            <!-- Nominal -->
            <div class="mb-3">
                <label for="nominal" class="form-label">Nominal</label>
                <input type="number" name="nominal" id="nominal" 
                       class="form-control" value="<?= htmlspecialchars($operasional['nominal']) ?>" required>
            </div>

            <!-- Keterangan -->
            <div class="mb-3">
                <label for="keterangan" class="form-label">Keterangan</label>
                <textarea name="keterangan" id="keterangan" class="form-control" rows="3"><?= htmlspecialchars($operasional['keterangan']) ?></textarea>
            </div>

            <!-- Tombol -->
            <button type="submit" class="btn btn-success">Simpan Perubahan</button>
            <a href="list.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
