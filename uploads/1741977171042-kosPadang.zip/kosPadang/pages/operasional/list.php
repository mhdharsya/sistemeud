<?php
require_once '../../config/database.php';
include '../../includes/header.php';

// Get filter parameters
$bulan = isset($_GET['bulan']) ? $_GET['bulan'] : date('F');
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');

// Get operasional payments data
$sql = "SELECT po.*, ko.nama_kategori, ko.periode
        FROM pembayaran_operasional po
        JOIN kategori_operasional ko ON po.id_kategori = ko.id_kategori
        WHERE (po.bulan = ? OR ko.periode = 'Tahunan') AND po.tahun = ?
        ORDER BY po.tanggal_pembayaran DESC";

$stmt = $conn->prepare($sql);
$stmt->execute([$bulan, $tahun]);
$operasional_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate total
$total_operasional = 0;
foreach ($operasional_data as $data) {
    $total_operasional += $data['nominal'];
}
?>

<div class="card">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Data Pembayaran Operasional</h5>
            <a href="tambah.php" class="btn btn-primary">
                <i class="bi bi-plus-circle"></i> Tambah Pembayaran
            </a>
        </div>
    </div>
    <div class="card-body">
        <!-- Filter Form -->
        <form action="" method="GET" class="mb-4">
            <div class="row g-3">
                <div class="col-md-4">
                    <select name="bulan" class="form-select">
                        <?php
                        $bulan_list = [
                            'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
                            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
                        ];
                        foreach ($bulan_list as $b) { ?>
                            <option value="<?= $b ?>" <?= $bulan === $b ? 'selected' : '' ?>>
                                <?= $b ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <select name="tahun" class="form-select">
                        <?php
                        $tahun_sekarang = date('Y');
                        for ($t = $tahun_sekarang - 2; $t <= $tahun_sekarang; $t++) { ?>
                            <option value="<?= $t ?>" <?= $tahun == $t ? 'selected' : '' ?>>
                                <?= $t ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary w-100">Filter</button>
                </div>
            </div>
        </form>

        <!-- Total Card -->
        <div class="card bg-light mb-4">
            <div class="card-body">
                <h6 class="card-title">Total Pengeluaran Operasional</h6>
                <h4 class="mb-0">Rp <?= number_format($total_operasional, 0, ',', '.') ?></h4>
            </div>
        </div>

        <!-- Data Table -->
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Kategori</th>
                        <th>Periode</th>
                        <th>Nominal</th>
                        <th>Keterangan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($operasional_data)) { ?>
                        <tr>
                            <td colspan="6" class="text-center">Tidak ada data pembayaran</td>
                        </tr>
                    <?php } else { ?>
                        <?php foreach ($operasional_data as $data) { ?>
                            <tr>
                                <td><?= date('d/m/Y', strtotime($data['tanggal_pembayaran'])) ?></td>
                                <td><?= htmlspecialchars($data['nama_kategori']) ?></td>
                                <td>
                                    <?php if ($data['periode'] === 'Tahunan') { ?>
                                        Tahunan (<?= $data['tahun'] ?>)
                                    <?php } else { ?>
                                        Bulanan (<?= $data['bulan'] ?> <?= $data['tahun'] ?>)
                                    <?php } ?>
                                </td>
                                <td>Rp <?= number_format($data['nominal'], 0, ',', '.') ?></td>
                                <td><?= htmlspecialchars($data['keterangan'] ?? '-') ?></td>
                                <td>
                                    <a href="detail.php?id=<?= $data['id_pembayaran_ops'] ?>" 
                                       class="btn btn-sm btn-info">
                                        <i class="bi bi-eye"></i> Detail
                                    </a>
                                    <a href="edit.php?id=<?= $data['id_pembayaran_ops'] ?>" 
                                    class="btn btn-sm btn-warning">
                                        <i class="bi bi-pencil"></i> Edit
                                    </a>
                                </td>
                            </tr>
                        <?php } ?>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>