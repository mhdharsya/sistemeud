<?php
require_once '../../config/database.php';
include '../../includes/header.php';

// Ambil filter bulan dan tahun dari request
$bulan = isset($_GET['bulan']) ? $_GET['bulan'] : '';
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');

// Query data bagi hasil
$sql = "SELECT po.*, ko.nama_kategori 
        FROM pembayaran_operasional po
        JOIN kategori_operasional ko ON po.id_kategori = ko.id_kategori
        WHERE ko.nama_kategori = 'Bagi Hasil Pemilik Gedung'";

$params = [];

// Tambahkan filter bulan jika ada
if (!empty($bulan)) {
    $sql .= " AND po.bulan = ?";
    $params[] = $bulan;
}

// Tambahkan filter tahun jika ada
if (!empty($tahun)) {
    $sql .= " AND po.tahun = ?";
    $params[] = $tahun;
}

$sql .= " ORDER BY po.tanggal_pembayaran DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$bagi_hasil_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">Data Bagi Hasil</h5>
    </div>
    <div class="card-body">
        <!-- Filter Form -->
        <form method="GET" class="row g-3 mb-4">
            <div class="col-md-4">
                <select name="bulan" class="form-select">
                    <option value="">Semua Bulan</option>
                    <?php
                    $bulan_list = [
                        'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
                        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
                    ];
                    foreach ($bulan_list as $b) : ?>
                        <option value="<?= $b ?>" <?= $b === $bulan ? 'selected' : '' ?>><?= $b ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <select name="tahun" class="form-select">
                    <?php
                    $tahun_sekarang = date('Y');
                    for ($t = $tahun_sekarang - 2; $t <= $tahun_sekarang; $t++) : ?>
                        <option value="<?= $t ?>" <?= $t == $tahun ? 'selected' : '' ?>><?= $t ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary w-100">Filter</button>
            </div>
        </form>

        <!-- Data Table -->
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Bulan</th>
                        <th>Tahun</th>
                        <th>Nominal</th>
                        <th>Bukti Pembayaran</th>
                        <th>Keterangan</th>
                        <th>Tanggal Input</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($bagi_hasil_data)) : ?>
                        <tr>
                            <td colspan="6" class="text-center">Tidak ada data bagi hasil</td>
                        </tr>
                    <?php else : ?>
                        <?php foreach ($bagi_hasil_data as $data) : ?>
                            <tr>
                                <td><?= htmlspecialchars($data['bulan']) ?></td>
                                <td><?= htmlspecialchars($data['tahun']) ?></td>
                                <td>Rp <?= number_format($data['nominal'], 0, ',', '.') ?></td>
                                <td>
                                    <?php if (!empty($data['bukti_pembayaran'])) : ?>
                                        <a href="../../assets/uploads/bukti_operasional/<?= htmlspecialchars($data['bukti_pembayaran']) ?>" target="_blank">
                                            Lihat Bukti
                                        </a>
                                    <?php else : ?>
                                        Tidak ada
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($data['keterangan']) ?: '-' ?></td>
                                <td><?= date('d/m/Y H:i:s', strtotime($data['created_at'])) ?></td>
                                <td>
                                    <a href="edit.php?id=<?= $data['id_pembayaran_ops'] ?>" 
                                    class="btn btn-sm btn-warning">
                                        <i class="bi bi-pencil"></i> Edit
                                    </a>
                                </td>

                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
