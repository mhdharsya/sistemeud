<?php
require_once '../../config/database.php';
include '../../includes/header.php';

// Ambil ID Pembayaran Bagi Hasil
$id_pembayaran_ops = isset($_GET['id']) ? $_GET['id'] : null;

if (!$id_pembayaran_ops) {
    echo "ID tidak ditemukan.";
    exit;
}

// Ambil data bagi hasil berdasarkan ID
$sql = "SELECT * FROM pembayaran_operasional WHERE id_pembayaran_ops = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$id_pembayaran_ops]);
$bagi_hasil = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$bagi_hasil) {
    echo "Data bagi hasil tidak ditemukan.";
    exit;
}

// Proses update data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bulan = $_POST['bulan'];
    $tahun = $_POST['tahun'];
    $nominal = $_POST['nominal'];
    $keterangan = $_POST['keterangan'];
    $bukti_pembayaran = $bagi_hasil['bukti_pembayaran']; // Default bukti pembayaran lama

    // Cek jika ada file baru yang di-upload
    if (!empty($_FILES['bukti_pembayaran']['name'])) {
        $upload_dir = '../../assets/uploads/bukti_operasional/';
        $file_name = time() . '_' . $_FILES['bukti_pembayaran']['name'];
        $file_tmp = $_FILES['bukti_pembayaran']['tmp_name'];
        move_uploaded_file($file_tmp, $upload_dir . $file_name);
        $bukti_pembayaran = $file_name;
    }

    $sql_update = "UPDATE pembayaran_operasional 
                   SET bulan = ?, tahun = ?, nominal = ?, keterangan = ?, bukti_pembayaran = ?
                   WHERE id_pembayaran_ops = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->execute([$bulan, $tahun, $nominal, $keterangan, $bukti_pembayaran, $id_pembayaran_ops]);

    echo "<script>alert('Data berhasil diperbarui!'); window.location='list.php';</script>";
    exit;
}
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title">Edit Data Bagi Hasil</h5>
    </div>
    <div class="card-body">
        <form action="" method="POST" enctype="multipart/form-data">
            <!-- Bulan -->
            <div class="mb-3">
                <label for="bulan" class="form-label">Bulan</label>
                <select name="bulan" id="bulan" class="form-select" required>
                    <?php
                    $bulan_list = [
                        'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
                        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
                    ];
                    foreach ($bulan_list as $b): ?>
                        <option value="<?= $b ?>" <?= $bagi_hasil['bulan'] === $b ? 'selected' : '' ?>>
                            <?= $b ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Tahun -->
            <div class="mb-3">
                <label for="tahun" class="form-label">Tahun</label>
                <input type="number" name="tahun" id="tahun" 
                       class="form-control" value="<?= htmlspecialchars($bagi_hasil['tahun']) ?>" required>
            </div>

            <!-- Nominal -->
            <div class="mb-3">
                <label for="nominal" class="form-label">Nominal</label>
                <input type="number" name="nominal" id="nominal" 
                       class="form-control" value="<?= htmlspecialchars($bagi_hasil['nominal']) ?>" required>
            </div>

            <!-- Keterangan -->
            <div class="mb-3">
                <label for="keterangan" class="form-label">Keterangan</label>
                <textarea name="keterangan" id="keterangan" 
                          class="form-control" rows="3"><?= htmlspecialchars($bagi_hasil['keterangan']) ?></textarea>
            </div>

            <!-- Bukti Pembayaran -->
            <div class="mb-3">
                <label for="bukti_pembayaran" class="form-label">Bukti Pembayaran</label>
                <?php if (!empty($bagi_hasil['bukti_pembayaran'])): ?>
                    <p><a href="../../assets/uploads/bukti_operasional/<?= htmlspecialchars($bagi_hasil['bukti_pembayaran']) ?>" target="_blank">
                        Lihat Bukti
                    </a></p>
                <?php endif; ?>
                <input type="file" name="bukti_pembayaran" id="bukti_pembayaran" class="form-control">
            </div>

            <!-- Tombol -->
            <button type="submit" class="btn btn-success">Simpan Perubahan</button>
            <a href="list.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
