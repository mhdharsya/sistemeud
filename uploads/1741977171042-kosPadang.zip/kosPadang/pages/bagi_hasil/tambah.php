<?php
require_once '../../config/database.php';
ob_start(); // Memulai output buffering untuk menghindari output sebelum header
include '../../includes/header.php';

// Debugging error PHP
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $bulan = $_POST['bulan'];
        $tahun = $_POST['tahun'];
        $nominal = $_POST['nominal'];
        $keterangan = $_POST['keterangan'];

        // Handle file upload
        $bukti_pembayaran = '';
        if (isset($_FILES['bukti_pembayaran']) && $_FILES['bukti_pembayaran']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../../assets/uploads/bukti_operasional/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            $file_extension = pathinfo($_FILES['bukti_pembayaran']['name'], PATHINFO_EXTENSION);
            $file_name = uniqid() . '.' . $file_extension;
            $upload_path = $upload_dir . $file_name;

            if (move_uploaded_file($_FILES['bukti_pembayaran']['tmp_name'], $upload_path)) {
                $bukti_pembayaran = $file_name;
            }
        }

        // Insert data ke tabel `pembayaran_operasional`
        $sql = "INSERT INTO pembayaran_operasional 
                (id_kategori, tanggal_pembayaran, bulan, tahun, nominal, bukti_pembayaran, keterangan) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";

        // Gunakan ID kategori khusus untuk "Bagi Hasil"
        $id_kategori = 6; // Sesuaikan ID kategori sesuai database Anda
        $tanggal_pembayaran = date('Y-m-d'); // Gunakan tanggal hari ini

        $stmt = $conn->prepare($sql);
        $stmt->execute([
            $id_kategori,
            $tanggal_pembayaran,
            $bulan,
            $tahun,
            $nominal,
            $bukti_pembayaran,
            $keterangan
        ]);

        // Redirect ke halaman list dengan status sukses
        header('Location: list.php?status=success&message=Data Bagi Hasil berhasil ditambahkan');
        exit();
    } catch (Exception $e) {
        $error_message = $e->getMessage();
    }
}

ob_end_flush(); // Mengakhiri output buffering
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">Tambah Data Bagi Hasil</h5>
    </div>
    <div class="card-body">
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger">
                <?= htmlspecialchars($error_message) ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="bulan" class="form-label">Bulan</label>
                        <select name="bulan" class="form-select" required>
                            <?php
                            $bulan_list = [
                                'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
                                'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
                            ];
                            foreach ($bulan_list as $b): ?>
                                <option value="<?= $b ?>" <?= date('F') === $b ? 'selected' : '' ?>>
                                    <?= $b ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="tahun" class="form-label">Tahun</label>
                        <select name="tahun" class="form-select" required>
                            <?php
                            $tahun_sekarang = date('Y');
                            for ($tahun = $tahun_sekarang - 1; $tahun <= $tahun_sekarang + 2; $tahun++): ?>
                                <option value="<?= $tahun ?>" <?= $tahun_sekarang == $tahun ? 'selected' : '' ?>>
                                    <?= $tahun ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="mb-3">
                <label for="nominal" class="form-label">Nominal</label>
                <input type="number" name="nominal" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="bukti_pembayaran" class="form-label">Bukti Pembayaran</label>
                <input type="file" name="bukti_pembayaran" class="form-control" accept="image/*">
                <small class="text-muted">Upload gambar bukti pembayaran (JPG, PNG)</small>
            </div>

            <div class="mb-3">
                <label for="keterangan" class="form-label">Keterangan</label>
                <textarea name="keterangan" class="form-control" rows="3"></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
