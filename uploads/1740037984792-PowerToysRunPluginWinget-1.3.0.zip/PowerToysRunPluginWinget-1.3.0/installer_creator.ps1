# Create installer with 7zip SFX


# 7zip command to create sfx archive and specify extract location
$cmd = "7z a -sfx7z.sfx -oC:\Users\Public\Documents\

