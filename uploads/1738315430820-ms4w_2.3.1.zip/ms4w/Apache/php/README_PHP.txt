php.exe and php.ini are located in /ms4w/Apache/cgi-bin





