SDE Notes
=========

As of MapServer 5.0 (including betas and release candidates), the following 
applies:

Steps to Enable SDE 9.1 and 9.2 Support in MS4W's MapServer
***********************************************************

1. Make sure the ArcSDE SDK dlls for your SDE version are available on 
   your machine (the same machine that you are running MS4W on).
   
   Here are some more specific 'rules' in terms of the ArcSDE SDK:
   
     - If you have to connect to both ArcSDE X.1 and X.2 servers, use 
       the X.2 version of the ArcSDE SDK.  You can usually connect to 
       a X.1 version server with X.2 version client DLLs without ill effects.
     - To connect to X.2 servers, you *must* use X.2 versions of the 
       ArcSDE SDK.
     - Do not use both the X.1 and X.2 versions of the plugins in the 
       same MapServer map if you have to connect to both X.1 and X.2 
       version servers.  Just use X.2. 

2. Modify your SDE layer in your mapfile to use the CONNECTIONTYPE PLUGIN
   parameter and point to the appropriate plugin using the PLUGIN parameter:
   
   Example#1: SDE 9.1 layer
   
     LAYER
       ...
       #CONNECTIONTYPE SDE       
       CONNECTIONTYPE PLUGIN
       CONNECTION "your server parameters"  
       PLUGIN "c:/ms4w/apache/specialplugins/msplugin_sde_91.dll"  
       DATA "your data parameters"
       ...
     END # layer
   
   Example#2: SDE 9.2 layer
   
     LAYER
       ...
       #CONNECTIONTYPE SDE       
       CONNECTIONTYPE PLUGIN
       CONNECTION "your server parameters"  
       PLUGIN "c:/ms4w/apache/specialplugins/msplugin_sde_92.dll"  
       DATA "your data parameters"
       ...
     END # layer  
     
   See the ArcSDE section of MapServer's Vector Data Access doc for help with
   the SDE CONNECTION and DATA parameters: http://mapserver.gis.umn.edu/docs/reference/vector_data/arcsde

3. Move the ogr_SDE.dll and gdal_SDE.dll plugin files up from 
   /ms4w/gdalplugins/ignored/sde-x/ into /ms4w/gdalplugins/
   
   If this is successful, executing the following at the
   commandline (after setting /ms4w/setenv.bat) 
   "ogrinfo --formats" and "gdalinfo --formats" should list 
   the SDE drivers.   
   
4. Restart Apache to be safe.



