<?php
  if (dl( "php_mapscript.".PHP_SHLIB_SUFFIX ))
  phpinfo();

?>
