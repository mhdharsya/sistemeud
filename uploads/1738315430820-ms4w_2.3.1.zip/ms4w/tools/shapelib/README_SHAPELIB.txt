shapelib for MS4W Build Notes
=============================

Source
------

  http://shapelib.maptools.org/ (thanks FrankW and other contributors)

Version
-------

  shapelib-1.2.10

Execution
---------

  Before running the shapelib utilities, you must set the appropriate PATH 
  values by executing the /ms4w/setenv.bat script.
  
Utility Documentation
---------------------

  http://shapelib.maptools.org/shapelib-tools.html

Build
-----

  compiled for win32 by jmckenna
