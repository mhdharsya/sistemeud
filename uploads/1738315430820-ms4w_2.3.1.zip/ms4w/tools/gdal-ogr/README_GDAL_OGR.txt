gdal-ogr-utils
--------------

* To run the gdal/ogr utils at a command prompt, you must have the /ms4w/Apache/cgi-bin 
  directory included in your PATH.

       * execute /ms4w/setenv.bat at a command prompt to include this directory in 
         your path, or set it in your Environment Variables on your machine.
  
* some data formats require supporting files, so you must have /ms4w/gdaldata
  in your PATH as well.
  
       * executing /ms4w/setenv.bat at a command prompt will add this directory to your 
         path, or you can set the Environment Variable yourself.

* for usage documentation, see: OGR  - http://www.gdal.org/ogr/ogr_utilities.html
                                GDAL - http://www.gdal.org/gdal_utilities.html