mapserv-utils
-------------

* To run the mapserv utils, you must have the /ms4w/Apache/cgi-bin directory
  included in your PATH.

  * run /ms4w/setenv.bat to include this directory in your path,
    or set it in your Environment Variables on your machine

* see http://mapserver.gis.umn.edu/docs/reference/utilityreference/ 
  for usage documentation.