               AVC - Arc/Info Vector Coverage Read Library
               -------------------------------------------

Please see the file "avce00.html" for the documentation.  

The latest version of this documentation and of the whole package can
be obtained from http://avce00.maptools.org/

Version: 2.0.0

Maintainer: Daniel Morissette, dmorissette@mapgears.com
