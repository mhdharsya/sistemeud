shp2tile for MS4W Build Notes
=============================

Source
------

  http://imaptools.com/?tab=4 (thanks Stephen Woodbridge)

Version
-------

  shp2tile-1.14

Execution
---------

  Before running shp2tile, you must set the appropriate PATH values by executing
  the /ms4w/setenv.bat script.
  
Release Documentation
---------------------

  see README_shp2tile_release.txt
  
Build
-----

  compiled for win32 by jmckenna
