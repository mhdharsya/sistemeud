demtools for MS4W Build Notes
=============================

Source
------

  http://www.perrygeo.net/wordpress/?p=7 (thanks Matt Perry and other contributors)

Version
-------

  SVN from 10/19/07

Execution
---------

  Before running the utilities, you must set the appropriate PATH 
  values by executing the /ms4w/setenv.bat script.

Build
-----

  compiled for win32 by jmckenna
