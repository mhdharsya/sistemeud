To execute the utilities in the Tools folder, in your command window first
execute \ms4w\setenv